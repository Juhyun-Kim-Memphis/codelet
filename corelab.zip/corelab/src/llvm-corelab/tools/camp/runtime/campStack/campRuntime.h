#ifndef CORELAB_CAMP_RUNTIME_H
#define CORELAB_CAMP_RUNTIME_H
#include <inttypes.h>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

#define STK_MAX_SIZE 16
#define STK_MAX_SIZE_DIV_BY_8 2
#define CNTX_STACK_BUF_SIZE 1024 //128

#if STK_MAX_SIZE == 32
typedef uint64_t IterRelation;
#elif STK_MAX_SIZE == 16
typedef uint32_t IterRelation;
#else /* X != 2 and X != 1*/
#endif 

typedef uint16_t CntxID;
typedef uint16_t InstrID;
typedef uint32_t CampID;
typedef uint64_t DepID;

// ==== STACK APPROACH ====
typedef uint32_t DependenceID; //srcInstID->dstInstID
typedef typename std::vector<CntxID> ContextStack;

typedef union IterStack{
	uint8_t i8[STK_MAX_SIZE];
	uint64_t i64[STK_MAX_SIZE_DIV_BY_8];
} IterStack; //16byte

typedef struct ContextIterStack{
	IterStack iterStack;
	ContextStack *ctxStack;
} ContextIterStack; //24byte

// for Load History Element
typedef std::map<InstrID, std::map<ContextStack, IterStack>> LoadHistoryMap;

// for Store History Element
typedef struct StoreHistoryElem {
	// CampID campID;
	InstrID instID; //2byte
	uint16_t padding[3]; //6byte
	ContextIterStack ctxIterStack; //24
} StoreHistoryElem; //32byte

typedef struct HistoryElem {
	LoadHistoryMap *pLoadMap; //8
	StoreHistoryElem storeElem; //32
	//40
	uint64_t padding[3]; //24byte
} HistoryElem; //64


#define SAMPLING_THRESHOLD 5
typedef std::map<CampID, uint8_t> CampIDCounterMap; //for sampling




//=========================================//
// ==== STACK APPROACH ====
//=========================================//
// typedef uint32_t DependenceID; //srcInstID->dstInstID
// typedef typename std::vector<CntxID> ContextStack;
class DepContextInfo {
	public:
		DepContextInfo(ContextStack src, ContextStack dst): srcContext(src), dstContext(dst){}

		// bool operator==(const DepContextInfo& rhs) const {
		// 	if((srcContext.size() == rhs.srcContext.size())&&(dstContext.size() == rhs.dstContext.size())){
		// 		return (std::equal(srcContext.begin(), srcContext.end(), rhs.srcContext.begin())&&std::equal(dstContext.begin(), dstContext.end(), rhs.dstContext.begin()));
		// 	}
		// 	else
		// 		return false;
		// }

		bool operator==(const DepContextInfo& rhs) const {
			return (srcContext==rhs.srcContext)&&(dstContext==rhs.dstContext);
		}

		bool operator<(const DepContextInfo& rhs) const {
			if(srcContext<rhs.srcContext)
				return true;
			else if(srcContext==rhs.srcContext){
				if(dstContext<rhs.dstContext)
					return true;
				else 
					return false;
			}
			else
				return false;
		}

		// void updateIterRel(IterRelation in){depIter = in;}

		ContextStack srcContext;
		ContextStack dstContext;
		// IterRelation depIter;
};
//=========================================//

// Initializer/Finalizer
extern "C" void campInitialize (size_t ldrCnt, size_t strCnt, size_t callCnt,
		size_t loopCnt, size_t maxLoopDepth);

extern "C" void campFinalize ();
		
// Memory Event
extern "C" void campLoadInstr (void* addr, InstrID instrID);
extern "C" void campStoreInstr (void* addr, InstrID instrID);
		
// Normal Context Event
extern "C" void campLoopBegin (CntxID cntxID);
extern "C" void campLoopNext ();
extern "C" void campLoopEnd (CntxID cntxID);

extern "C" void campCallSiteBegin (CntxID cntxID);
extern "C" void campCallSiteEnd  (CntxID cntxID);


extern "C" void* campMalloc (size_t size);
extern "C" void* campCalloc (size_t num, size_t size);
extern "C" void* campRealloc (void* addr, size_t size);
extern "C" void campFree (void* addr);

extern "C" void campDisableCtxtChange();
extern "C" void campEnableCtxtChange();

// For debug
// extern "C" void dumpStoreHistoryTable();
// extern "C" void dumpLoadHistoryTable();
extern "C" void dumpDependenceTable();



#endif
//CORELAB_CAMP_RUNTIME_H
