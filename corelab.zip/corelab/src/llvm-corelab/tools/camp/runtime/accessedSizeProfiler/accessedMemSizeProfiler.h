#ifndef CORELAB_CAMP_ACCESSED_MEM_SIZE_PROFILER_H
#define CORELAB_CAMP_ACCESSED_MEM_SIZE_PROFILER_H
#include <inttypes.h>
#include <set>

typedef uint16_t CntxID;
typedef uint16_t InstrID;
typedef uint32_t CampID;

// Initializer/Finalizer
extern "C" void amspInitialize (size_t ldrCnt, size_t strCnt, size_t callCnt,
		size_t loopCnt, size_t maxLoopDepth);

extern "C" void amspFinalize ();
		
// Memory Event
extern "C" void amspLoadInstr (void* addr, InstrID instrID);
extern "C" void amspStoreInstr (void* addr, int16_t size, InstrID instrID);
		
// Normal Context Event
extern "C" void amspLoopBegin (CntxID cntxID);
extern "C" void amspLoopEnd (CntxID cntxID);

extern "C" void amspCallSiteBegin (CntxID cntxID);
extern "C" void amspCallSiteEnd  (CntxID cntxID);


// extern "C" void* amspMalloc (size_t size);
// extern "C" void* amspCalloc (size_t num, size_t size);
// extern "C" void* amspRealloc (void* addr, size_t size);
// extern "C" void amspFree (void* addr);

extern "C" void amspDisableCtxtChange();
extern "C" void amspEnableCtxtChange();


#endif //CORELAB_CAMP_ACCESSED_MEM_SIZE_PROFILER_H
