#include <iostream>
#include <stdio.h>
#include <fstream>

#include "accessedMemSizeProfiler.h"
#include "ShadowMemory.hpp"

#define MAX_LINE_SIZE 4096

using namespace std;

inline void mark(uint8_t *saddr, uint16_t size);
void readFourFiles();

struct sigaction ShadowMemoryManager::segvAction; //Page Fault hooking mechanism
std::set<void*> *ShadowMemoryManager::shadowPageSet;

static CntxID currentCtx;
static uint16_t disableCxtChange; // enabled when 0

static std::set<CampID> *srcCampIDSetOfCtxtSensitive_In;
static std::set<CampID> *srcCampIDSetOfCtxtSensitive_Out;
static std::set<InstrID> *srcInstrIDSetOfCtxtIgnorant_In;
static std::set<InstrID> *srcInstrIDSetOfCtxtIgnorant_Out;

// Initializer/Finalizer
extern "C"
void amspInitialize (size_t ldrCnt, size_t strCnt, size_t callCnt, size_t loopCnt, size_t maxLoopDepth) {
	disableCxtChange = 0;
	currentCtx = 0;
	
	srcCampIDSetOfCtxtSensitive_In = new std::set<CampID>;
	srcCampIDSetOfCtxtSensitive_Out = new std::set<CampID>;
	srcInstrIDSetOfCtxtIgnorant_In = new std::set<InstrID>;
	srcInstrIDSetOfCtxtIgnorant_Out = new std::set<InstrID>;

	readFourFiles();
	ShadowMemoryManager::initialize();

	// std::cout<<"amspInitialize!!!!!!!!!!!! \n";
	printf("\n [amspInitialize]======= \n");
}

extern "C"
void amspFinalize () {
	// std::cout<<"amspFinalize!!!!!!!!!!!! \n";
	printf("\n\n[amspFinalize]====== \n");
	std::set<void*> &setShadowPage = *ShadowMemoryManager::shadowPageSet;

	int sum = 0;
	for(void *pageStart : setShadowPage){
		int usage = countMarkedBytesInPage(pageStart);
		sum += usage;
		// printf("%p: usage size: %d, \n", pageStart, usage);
	}

	printf("\n[amsp Result] total Usage: %d \n", sum);


}

// Normal Context Event
extern "C"
void amspLoopBegin (CntxID cntxID) {
	if(disableCxtChange != 0) return;
	currentCtx += cntxID;
}

extern "C"
void amspLoopEnd (CntxID cntxID) {
	if(disableCxtChange!= 0) return;
	currentCtx -= cntxID;
}

extern "C"
void amspCallSiteBegin (CntxID cntxID) {
	if(disableCxtChange == 0)
	currentCtx += cntxID;
}

extern "C"
void amspCallSiteEnd  (CntxID cntxID) {
	if(disableCxtChange == 0)
	currentCtx -= cntxID;
}

 
extern "C"
void amspStoreInstr (void* addr, int16_t size, InstrID instrID) {
	CampID campID = currentCtx << 16 | instrID;

	#ifdef CAMP_AMSP_CS_IN
	if(srcCampIDSetOfCtxtSensitive_In->find(campID) != srcCampIDSetOfCtxtSensitive_In->end()){
		uint8_t *saddr = (uint8_t *)GET_SHADOW_ADDR(addr);
		// printf("s: %d, id: %d, %p\n", size, instrID, saddr);
		mark(saddr, size);
	}
	#endif //CAMP_AMSP_CS_IN
	
	#ifdef CAMP_AMSP_CS_OUT
	if(srcCampIDSetOfCtxtSensitive_Out->find(campID) != srcCampIDSetOfCtxtSensitive_Out->end()){
		uint8_t *saddr = (uint8_t *)GET_SHADOW_ADDR(addr);
		// printf("s: %d, id: %d, %p\n", size, instrID, saddr);
		mark(saddr, size);
	}
	#endif //CAMP_AMSP_CS_OUT
	
	#ifdef CAMP_AMSP_CI_IN
	if(srcInstrIDSetOfCtxtIgnorant_In->find(instrID) != srcInstrIDSetOfCtxtIgnorant_In->end()){
		uint8_t *saddr = (uint8_t *)GET_SHADOW_ADDR(addr);
		// printf("s: %d, id: %d, %p\n", size, instrID, saddr);
		mark(saddr, size);
	}
	#endif //CAMP_AMSP_CI_IN

	#ifdef CAMP_AMSP_CI_OUT
	if(srcInstrIDSetOfCtxtIgnorant_Out->find(instrID) != srcInstrIDSetOfCtxtIgnorant_Out->end()){
		uint8_t *saddr = (uint8_t *)GET_SHADOW_ADDR(addr);
		// printf("s: %d, id: %d, %p\n", size, instrID, saddr);
		mark(saddr, size);
	}
	#endif //CAMP_AMSP_CI_OUT
}

extern "C" void amspDisableCtxtChange(){
	disableCxtChange++;
}

extern "C" void amspEnableCtxtChange(){
	disableCxtChange--;
}

void readFourFiles(){
	// ========================================================== //
	// Read the Store Instruction List (InstrID, CampID) that need to be inspected.
	// ========================================================== //
	char line[MAX_LINE_SIZE];

	// Src_CampIDList_CS_InEdge.data
	std::ifstream Src_CampIDList_CS_InEdge ("Src_CampIDList_CS_InEdge.data", std::ifstream::binary);
	assert(Src_CampIDList_CS_InEdge);
	Src_CampIDList_CS_InEdge.getline(line, MAX_LINE_SIZE);
	string Src_CampIDList_CS_InEdge_startMsg("$$$$$ Context-Sensitive [IN Edge] Src-CampID $$$$$");
	assert(Src_CampIDList_CS_InEdge_startMsg.compare(line) == 0);
	Src_CampIDList_CS_InEdge.getline(line, MAX_LINE_SIZE);
	unsigned nCampID_Src_InEdge = (unsigned)(atoi(line));
	for (int i = 0; i < nCampID_Src_InEdge; ++i){
		Src_CampIDList_CS_InEdge.getline(line, MAX_LINE_SIZE);
		CampID campID = (CampID)(atoi(line));
		srcCampIDSetOfCtxtSensitive_In->insert(campID);
	}
	Src_CampIDList_CS_InEdge.getline(line, MAX_LINE_SIZE);
	string Src_CampIDList_CS_InEdge_endMsg("$$$$$ Context-Sensitive [IN Edge] Src-CampID END $$$$$");
	assert(Src_CampIDList_CS_InEdge_endMsg.compare(line) == 0);
	Src_CampIDList_CS_InEdge.close();

	// Src_CampIDList_CS_OutEdge.data
	std::ifstream Src_CampIDList_CS_OutEdge ("Src_CampIDList_CS_OutEdge.data", std::ifstream::binary);
	assert(Src_CampIDList_CS_OutEdge);
	Src_CampIDList_CS_OutEdge.getline(line, MAX_LINE_SIZE);
	string Src_CampIDList_CS_OutEdge_startMsg("$$$$$ Context-Sensitive [Out Edge] Src-CampID $$$$$");
	assert(Src_CampIDList_CS_OutEdge_startMsg.compare(line) == 0);
	Src_CampIDList_CS_OutEdge.getline(line, MAX_LINE_SIZE);
	unsigned nCampID_Src_OutEdge = (unsigned)(atoi(line));
	for (int i = 0; i < nCampID_Src_OutEdge; ++i){
		Src_CampIDList_CS_OutEdge.getline(line, MAX_LINE_SIZE);
		CampID campID = (CampID)(atoi(line));
		srcCampIDSetOfCtxtSensitive_Out->insert(campID);
	}
	Src_CampIDList_CS_OutEdge.getline(line, MAX_LINE_SIZE);
	string Src_CampIDList_CS_OutEdge_endMsg("$$$$$ Context-Sensitive [Out Edge] Src-CampID END $$$$$");
	assert(Src_CampIDList_CS_OutEdge_endMsg.compare(line) == 0);
	Src_CampIDList_CS_OutEdge.close();

	// Src_InstIDList_CI_InEdge.data
	std::ifstream Src_InstIDList_CI_InEdge ("Src_InstIDList_CI_InEdge.data", std::ifstream::binary);
	assert(Src_InstIDList_CI_InEdge);
	Src_InstIDList_CI_InEdge.getline(line, MAX_LINE_SIZE);
	string Src_InstIDList_CI_InEdge_startMsg("$$$$$ Context-Ignorant [IN Edge] Src-InstrID $$$$$");
	assert(Src_InstIDList_CI_InEdge_startMsg.compare(line) == 0);
	Src_InstIDList_CI_InEdge.getline(line, MAX_LINE_SIZE);
	unsigned nInstrID_Src_InEdge = (unsigned)(atoi(line));
	for (int i = 0; i < nInstrID_Src_InEdge; ++i){
		Src_InstIDList_CI_InEdge.getline(line, MAX_LINE_SIZE);
		InstrID instrID = (InstrID)(atoi(line));
		srcInstrIDSetOfCtxtIgnorant_In->insert(instrID);
	}
	Src_InstIDList_CI_InEdge.getline(line, MAX_LINE_SIZE);
	string Src_InstIDList_CI_InEdge_endMsg("$$$$$ Context-Ignorant [IN Edge] Src-InstrID END $$$$$");
	assert(Src_InstIDList_CI_InEdge_endMsg.compare(line) == 0);
	Src_InstIDList_CI_InEdge.close();

	// Src_InstIDList_CI_OutEdge.data
	std::ifstream Src_InstIDList_CI_OutEdge ("Src_InstIDList_CI_OutEdge.data", std::ifstream::binary);
	assert(Src_InstIDList_CI_OutEdge);
	Src_InstIDList_CI_OutEdge.getline(line, MAX_LINE_SIZE);
	string Src_InstIDList_CI_OutEdge_startMsg("$$$$$ Context-Ignorant [Out Edge] Src-InstrID $$$$$");
	assert(Src_InstIDList_CI_OutEdge_startMsg.compare(line) == 0);
	Src_InstIDList_CI_OutEdge.getline(line, MAX_LINE_SIZE);
	unsigned nInstrID_Src_OutEdge = (unsigned)(atoi(line));
	for (int i = 0; i < nInstrID_Src_OutEdge; ++i){
		Src_InstIDList_CI_OutEdge.getline(line, MAX_LINE_SIZE);
		InstrID instrID = (InstrID)(atoi(line));
		srcInstrIDSetOfCtxtIgnorant_Out->insert(instrID);
	}
	Src_InstIDList_CI_OutEdge.getline(line, MAX_LINE_SIZE);
	string Src_InstIDList_CI_OutEdge_endMsg("$$$$$ Context-Ignorant [Out Edge] Src-InstrID END $$$$$");
	assert(Src_InstIDList_CI_OutEdge_endMsg.compare(line) == 0);
	Src_InstIDList_CI_OutEdge.close();

	// errs()<<"nCampID_Src_InEdge: "<<srcCampIDSetOfCtxtSensitive_In.size()<<"\n";
	printf("nCampID_Src_InEdge: %lu \n", srcCampIDSetOfCtxtSensitive_In->size());
	// errs()<<"nCampID_Src_OutEdge: "<<srcCampIDSetOfCtxtSensitive_Out.size()<<"\n";
	printf("nCampID_Src_OutEdge: %lu \n", srcCampIDSetOfCtxtSensitive_Out->size());
	// errs()<<"nInstrID_Src_InEdge: "<<srcInstrIDSetOfCtxtIgnorant_In.size()<<"\n";
	printf("nInstrID_Src_InEdge: %lu \n", srcInstrIDSetOfCtxtIgnorant_In->size());
	// errs()<<"nInstrID_Src_OutEdge: "<<srcInstrIDSetOfCtxtIgnorant_Out.size()<<"\n";
	printf("nInstrID_Src_OutEdge: %lu \n", srcInstrIDSetOfCtxtIgnorant_Out->size());
}

inline void mark(uint8_t *saddr, uint16_t size){
	if(size == 4){
		*saddr=1;
		*(saddr+1)=1;
		*(saddr+2)=1;
		*(saddr+3)=1;
	}
	else if(size == 8){
		*saddr=1;
		*(saddr+1)=1;
		*(saddr+2)=1;
		*(saddr+3)=1;
		*(saddr+4)=1;
		*(saddr+5)=1;
		*(saddr+6)=1;
		*(saddr+7)=1;
	}
	else{
		for (int16_t i = 0; i < size; ++i)
			*(saddr+i)=1;
	}
}