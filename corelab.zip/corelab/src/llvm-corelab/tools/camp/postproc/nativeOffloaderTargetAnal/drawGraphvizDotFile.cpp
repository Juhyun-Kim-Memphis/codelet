#include "../campPostProc/PostProcess.hpp"
#include "IdentifyTargetCampID.hpp"
#include <set>
#include <list>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <iostream>
#include <fstream>
#include <algorithm>

using namespace corelab;

typedef std::string FunctionName;
void contextTreeDumpToDOT(std::string path, corelab::ContextTree *root,
				std::set<FunctionName> &insideFunSet, std::set<LoopID> &insideLoopSet,
				std::vector<std::unordered_set<corelab::UniqueContextID>> &ucIDSetLi, std::vector<Dependence *> &depList,
				std::unordered_map <InstrID, std::vector< UniqueContextID >> &instIDtoUcID){

	// Initialize
	std::unordered_map<ContextIgnorantDependence, std::set< Dependence * > > ciDepList;
	std::unordered_map<ContextIgnorantDependence, std::set< Dependence * > > pluralDepList;
	std::unordered_map<ContextIgnorantDependence, std::vector< DependenceSimplified > > ciRedEdges;
	std::set<UniqueContextID> pluralUcIDSet;
	std::set<UniqueContextID> homelessInsiderUcIDSet;

	// ############################################################################################ //
	// ## Construct Context Ignorant Dependence List out of Context Sensitive Dependence List. #### //
	// ############################################################################################ //
	
	for(Dependence *d : depList){
		ContextIgnorantDependence ciDep(d->instrIDsrc, d->instrIDdst);
		ciDepList[ciDep].insert(d);
	}

	//identify plural dependence 
	for(auto e : ciDepList){
		if(e.second.size() > 1){
			pluralDepList.insert(std::make_pair(e.first, e.second));
			for(Dependence *d : e.second){
				pluralUcIDSet.insert(d->ucIDsrc);
				pluralUcIDSet.insert(d->ucIDdst);
			}
		}
	}

	// amplify!
	unsigned nAmplifiedCIDep = 0;
	for(auto e: ciDepList){

		for(UniqueContextID srcUCID : instIDtoUcID[e.first.instrIDsrc]){
			for(UniqueContextID dstUCID : instIDtoUcID[e.first.instrIDdst]){
				DependenceSimplified dep(srcUCID, dstUCID, e.first.instrIDsrc, e.first.instrIDdst);
				ciRedEdges[e.first].push_back(dep);
				// nAmplifiedCIDep++;

			}
		}
		// if(ciRedEdges[e.first].empty())
		// 	std::cout<<" THIS IS SUSPICIOUS"<< instIDtoUcID[e.first.instrIDsrc].size() << ", "<<instIDtoUcID[e.first.instrIDdst].size()<< "\n";
	}
	
	for(auto e: ciRedEdges)
		nAmplifiedCIDep += e.second.size();	

	std::cout<<"size of CS DepList "<< depList.size()<<"\n";
	std::cout<<"size of CI DepList "<< ciDepList.size()<<"\n";
	std::cout<<"size of Plural DepList "<< pluralDepList.size()<<"\n";
	std::cout<<"size of ciRedEdges "<< ciRedEdges.size() << ", total: "<< nAmplifiedCIDep <<"\n";

	// ################################################################################# //
	// ############################## ciRedEdges compute ############################### //
	// ################################################################################# //
	unsigned diffCount=0;
	for(Dependence *d: depList){
		ContextIgnorantDependence ciDep(d->instrIDsrc, d->instrIDdst);
		DependenceSimplified sd(d->ucIDsrc, d->ucIDdst, d->instrIDsrc, d->instrIDdst);
		int size_before = ciRedEdges[ciDep].size();
		auto iend = std::remove(ciRedEdges[ciDep].begin(), ciRedEdges[ciDep].end(), sd);
		ciRedEdges[ciDep].assign(ciRedEdges[ciDep].begin(), iend);
		int size_after = ciRedEdges[ciDep].size();
		int diff = size_before - size_after;
		if(diff == 0){
			diffCount++;
			// std::cout<<"before : "<<size_before<<", after"<<size_after<<"\n";
			// std::cout<<"ucIDsrc: "<<d->ucIDsrc<<", ucIDdst: "<< d->ucIDdst<<", instrIDsrc: "<< d->instrIDsrc<<", instrIDdst: "<< d->instrIDdst<<"\n";
		}
	}

	unsigned nCIRedDep = 0;
	for(auto e: ciRedEdges)
		nCIRedDep += e.second.size();	

	std::cout<<"size of ciRedEdges "<< ciRedEdges.size() << ", redTotal: "<< nCIRedDep <<", diffCount :"<<diffCount<<"\n";

	// // ################################################################################# //
	// // ############################## Draw Context Tree ################################ //
	// // ################################################################################# //
	// std::ofstream outfile(path, std::ios::out | std::ofstream::binary);
	// outfile<<"digraph G {\n";

	// std::list<ContextTree *> searchQueue;
	// searchQueue.push_back(root);
	// while(!searchQueue.empty()){
	// 	ContextTree *node = searchQueue.front();
	// 	searchQueue.pop_front();

	// 	UniqueContextID ucid = node->getUCID();
	// 	bool inSubTree = std::any_of(ucIDSetLi.begin(), ucIDSetLi.end(), [ucid](std::unordered_set<UniqueContextID> set){return set.find(ucid)!=set.end();});
	// 	bool isPlural = pluralUcIDSet.find(ucid) != pluralUcIDSet.end();

	// 	bool otherCS_IsInSubTree = false;
	// 	if( !inSubTree )
	// 		otherCS_IsInSubTree = node->isCallSiteNode()? (insideFunSet.find(node->getFunName()) != insideFunSet.end()) 
	// 													: (insideLoopSet.find(node->getLoopID()) != insideLoopSet.end());

	// 	if(otherCS_IsInSubTree) //homeless insider
	// 		homelessInsiderUcIDSet.insert(ucid);

	// 	outfile << ucid;
	// 	if(node->isCallSiteNode()){

	// 		outfile << " [shape=box, style=filled,"
	// 				<<(inSubTree?"fillcolor = \"orange\",":(otherCS_IsInSubTree?"fillcolor = \"red\",":"fillcolor = \"gray\","))
	// 				<<(isPlural ? " color = \"blue\"," : "")
	// 				<<" label=\""<<node->getFunName()<<"\"];\n";
	// 	}
	// 	else
	// 		outfile << " [shape=circle, style=filled,"
	// 				<<(inSubTree?"fillcolor = \"orange\",":(otherCS_IsInSubTree?"fillcolor = \"red\",":"fillcolor = \"gray\","))
	// 				<<(isPlural ? " color = \"blue\"," : "")
	// 				<<" label=\""<<node->getLoopID()<<"\"];\n";

	// 	if( node->getUCID() != 0 ) //exclude root
	// 		outfile<<node->getParent()->getUCID()<<" -> "<< ucid <<";\n";

	// 	for(ContextTree *c : node->children)
	// 		searchQueue.push_back(c);
	// }

	//draw depedence (general)
	// for(Dependence *d: depList){
	// 	if(d->instrIDdst == 2056)
	// 		std::cout<<"2056 src instID:"<<d->instrIDsrc<<"\n";
	// 	if(d->instrIDdst == 2062)
	// 		std::cout<<"2062 src instID:"<<d->instrIDsrc<<"\n";
	// 	if(d->instrIDdst == 2064)
	// 		std::cout<<"2064 src instID:"<<d->instrIDsrc<<"\n";
	// 	if(d->instrIDsrc == 2055)
	// 		std::cout<<"2055 dst instID:"<<d->instrIDdst<<"\n";
	// 	// outfile<<d->ucIDsrc<<" -> "<< d->ucIDdst <<" [style=\"bold\", color=\"green\"];\n"; 
	// }

	// // ############################################################################################################# //
	// // Count False Positive Dep that only appears inside the target subTree ######################################## //
	// // This case conservatively assumes callsite of (target) inside function can exist outside. (afraid of homeless) //
	// // ############################################################################################################# //
	// unsigned nFPdep = 0;
	// //code moved to (nFPdep++;)

	// unsigned nRedEdges = 0;
	// unsigned nGreenEdges = 0;
	// unsigned nPinkEdges = 0;

	// // ################################################################################################################################ //
	// // Draw the Dependence related to homeless Insider ################################################################################ //
	// // This can be either false positive or false negative depending on whether we conservatively consider callsite of inside function. //
	// // ################################################################################################################################ //
	// outfile << " edge [style=\"bold\", color=\"red\"];\n";
	// for(Dependence *d: depList){
	// 	bool isSrcHomelessInsider = homelessInsiderUcIDSet.find(d->ucIDsrc) != homelessInsiderUcIDSet.end();
	// 	bool isDstHomelessInsider = homelessInsiderUcIDSet.find(d->ucIDdst) != homelessInsiderUcIDSet.end();
	// 	bool isSrcInSubTree = std::any_of(ucIDSetLi.begin(), ucIDSetLi.end(), [d](std::unordered_set<UniqueContextID> set){return set.find(d->ucIDsrc)!=set.end();});
	// 	bool isDstInSubTree = std::any_of(ucIDSetLi.begin(), ucIDSetLi.end(), [d](std::unordered_set<UniqueContextID> set){return set.find(d->ucIDdst)!=set.end();});

	// 	if(isSrcHomelessInsider && isDstHomelessInsider){
	// 		outfile<<d->ucIDsrc<<" -> "<< d->ucIDdst <<" [style=\"bold\", color=\"pink\"];\n"; //FP when CS-conservative CI
	// 		nFPdep++;
	// 		nPinkEdges++;
	// 	}
	// 	else if(isSrcHomelessInsider != isDstHomelessInsider){ //XOR
	// 		if(isSrcInSubTree != isDstInSubTree){ //logically, same with (isSrcInSubTree || isDstInSubTree)
	// 			outfile<<d->ucIDsrc<<" -> "<< d->ucIDdst <<" [style=\"bold\", color=\"green\"];\n"; //TP when CS-conservative CI
	// 			nGreenEdges++;
	// 		}
	// 		else{
	// 			outfile<<d->ucIDsrc<<" -> "<< d->ucIDdst <<" [style=\"bold\", color=\"red\"];\n"; //FP when CI
	// 			nFPdep++;
	// 			nRedEdges++;
	// 		}
	// 	}

	// 	if(isSrcInSubTree && isDstInSubTree){
	// 		nFPdep++;
	// 	}
	// }

	// // ####################################################################################### //
	// // Draw the potential false negative dependence (FN if Context-Ingorant) ################# //
	// // This is related to plural. ############################################################ //
	// // ####################################################################################### //
	// unsigned nFNdep = 0;
	// outfile << " edge [style=\"dotted\", color=\"blue\"];\n";
	// for(auto e : pluralDepList){
	// 	for(Dependence *d : e.second){
	// 		// outfile<<d->ucIDsrc<<" -> "<< d->ucIDdst <<";\n"; //FN when CI (because of plural)
	// 		nFNdep++;
	// 	}
	// 	nFNdep--;
	// }

	// // ############################ //
	// // Statistic ################## //
	// // ############################ //
	// std::cout<<"# of False Negative Deps: "<< nFNdep<<"\n";
	// std::cout<<"# of False Positive Deps: "<< nFPdep<<"\n";
	// std::cout<<"# of homeless insider UCID: "<< homelessInsiderUcIDSet.size() <<"\n";
	// std::cout<<"# of plural UCID: "<< pluralUcIDSet.size() <<"\n";
	// std::cout<<"# of Red Deps: "<< nRedEdges<<"\n";
	// std::cout<<"# of Green Deps: "<< nGreenEdges<<"\n";
	// std::cout<<"# of Pink Deps: "<< nPinkEdges<<"\n";

	// outfile<<"}";
	// outfile.close();

	// //******************************************************************************************************************//
	// //************************************************ CI anal Start ***************************************************//
	// //******************************************************************************************************************//

	// // ##################################################################### //
	// // ####################### identify all InstrID belongs to target ################### //
	// // ##################################################################### //

	// IdentifyTargetInstID *targetAnalyzer_CSIgorant = new IdentifyTargetInstID(&depList, &ucIDSetLi);
	// std::unordered_set<InstrID> instrIDSet = targetAnalyzer_CSIgorant->getInstrIDSet();
	// std::cout<<"insider InstrID Set Size: "<< instrIDSet.size()<<"\n";
	
	// //##########################
	// // ############ Context-Ignorant Ins Outs for Native Offloader target
	// //##########################
	// std::unordered_set<Dependence *> ciInDeps;
	// std::unordered_set<Dependence *> ciOutDeps;
	// for(Dependence *d : depList){
	// 	bool isSrcIn = instrIDSet.find(d->instrIDsrc) != instrIDSet.end();
	// 	bool isDstIn = instrIDSet.find(d->instrIDdst) != instrIDSet.end();
	// 	bool hasSrcBeenOut = homelessInsiderUcIDSet.find(d->ucIDsrc) != homelessInsiderUcIDSet.end();
	// 	bool hasDstBeenOut = homelessInsiderUcIDSet.find(d->ucIDdst) != homelessInsiderUcIDSet.end();
		
	// 	// TODO is it OK?
	// 	// CallSite aware conservative decison
	// 	// if(isSrcIn && isDstIn){ 
	// 	// 	ciInDeps.insert(d);
	// 	// 	ciOutDeps.insert(d);
	// 	// }
	// 	if(isDstIn && ((!isSrcIn) || hasSrcBeenOut))
	// 		ciInDeps.insert(d); //in
	// 	if(isSrcIn && ((!isDstIn) || hasDstBeenOut))
	// 		ciOutDeps.insert(d); //out
	// }

	// // record src InstrID of In Edges of Context Ignorant case.
	// std::set<InstrID> srcInstrIDSetOfCtxtIgnorant_In;
	// for(Dependence *d : ciInDeps)
	// 	srcInstrIDSetOfCtxtIgnorant_In.insert(d->instrIDsrc);
	// std::ofstream outfile_srcInstID_CI_InEdge("Src_InstIDList_CI_InEdge.data", std::ios::out | std::ofstream::binary);
	// if(outfile_srcInstID_CI_InEdge.is_open()){
	// 	outfile_srcInstID_CI_InEdge<<"$$$$$ Context-Ignorant [IN Edge] Src-InstrID $$$$$\n";
	// 	outfile_srcInstID_CI_InEdge<<srcInstrIDSetOfCtxtIgnorant_In.size()<<"\n";
	// 	for(auto id: srcInstrIDSetOfCtxtIgnorant_In){
	// 		outfile_srcInstID_CI_InEdge<<id<<"\n";
	// 	}
	// 	outfile_srcInstID_CI_InEdge<<"$$$$$ Context-Ignorant [IN Edge] Src-InstrID END $$$$$\n";
	// }
	// outfile_srcInstID_CI_InEdge.close();

	// // record src InstrID of Out Edges of Context Ignorant case.
	// std::set<InstrID> srcInstrIDSetOfCtxtIgnorant_Out;
	// for(Dependence *d : ciOutDeps)
	// 	srcInstrIDSetOfCtxtIgnorant_Out.insert(d->instrIDsrc);
	// std::ofstream outfile_srcInstID_CI_OutEdge("Src_InstIDList_CI_OutEdge.data", std::ios::out | std::ofstream::binary);
	// if(outfile_srcInstID_CI_OutEdge.is_open()){
	// 	outfile_srcInstID_CI_OutEdge<<"$$$$$ Context-Ignorant [Out Edge] Src-InstrID $$$$$\n";
	// 	outfile_srcInstID_CI_OutEdge<<srcInstrIDSetOfCtxtIgnorant_Out.size()<<"\n";
	// 	for(auto id: srcInstrIDSetOfCtxtIgnorant_Out){
	// 		outfile_srcInstID_CI_OutEdge<<id<<"\n";
	// 	}
	// 	outfile_srcInstID_CI_OutEdge<<"$$$$$ Context-Ignorant [Out Edge] Src-InstrID END $$$$$\n";
	// }
	// outfile_srcInstID_CI_OutEdge.close();

	// std::cout<<"Context-Ignorant \n";
	// cout<< "(nIns: "<<ciInDeps.size()<<", nOuts: "<<ciOutDeps.size()<<")\n";


	//******************************************************************************************************************//
	//************************************************ CI anal Done ****************************************************//
	//******************************************************************************************************************//
	
}