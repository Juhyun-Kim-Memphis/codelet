#include <iostream>
#include <fstream>
#include <assert.h>
#include <stdlib.h>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
#include <set>
#include <list>

#include "../campPostProc/PostProcess.hpp"
#include "IdentifyTargetCampID.hpp"

#define MAX_LINE_SIZE 4096

using namespace std;
using namespace corelab;

typedef std::string FunctionName;
void contextTreeDumpToDOT(std::string path, corelab::ContextTree *root,
				std::set<FunctionName> &insideFunSet, std::set<LoopID> &insideLoopSet,
				std::vector<std::unordered_set<corelab::UniqueContextID>> &ucIDSetLi, std::vector<Dependence *> &depList,
				std::unordered_map <InstrID, std::vector< UniqueContextID >> &instIDtoUcID);

void contextTreeDumpToDOT_CASEANAL(std::string path, corelab::ContextTree *root,
				std::set<FunctionName> &insideFunSet, std::set<LoopID> &insideLoopSet,
				std::vector<std::unordered_set<corelab::UniqueContextID>> &ucIDSetLi, std::vector<Dependence *> &depList,
				std::unordered_map <InstrID, std::vector< UniqueContextID >> &instIDtoUcID);




int main(int argc, char** argv){
	char line[MAX_LINE_SIZE];

	//################ read NativeOffloaderTargetFuncList
	std::ifstream notfl_fp ("NativeOffloaderTargetFuncList.data", std::ifstream::binary);
	assert(notfl_fp);
	notfl_fp.getline(line, MAX_LINE_SIZE);
	string notfl_fp_startMsg("$$$$$ NativeOffloaderTargetFuncList START $$$$$");
	assert(notfl_fp_startMsg.compare(line) == 0);
	notfl_fp.getline(line, MAX_LINE_SIZE); //assume one target for now (16/5/15)
	string natoff_target(line);
	notfl_fp.close();
	//################ read NativeOffloaderTargetFuncList END

	unsigned nNode = 0;
	unsigned cnt = 0;

	std::ifstream fpCtxTree ("ContextTree.data", std::ifstream::binary);
	assert(fpCtxTree);

	fpCtxTree.getline(line, MAX_LINE_SIZE);
	string startMsg("$$$$$ CONTEXT TREE IN PREORDER $$$$$");
	assert(startMsg.compare(line) == 0);
	fpCtxTree.getline(line, MAX_LINE_SIZE);
	nNode = (unsigned)(atoi(line));

	std::unordered_map<UniqueContextID, ContextTreeNode *> ucIDMap;
	std::unordered_map<LoopID, std::vector<UniqueContextID>> loopMap;

	char ucIDStr[64];
	char locIDStr[64];
	char kind[4];
	char funName[64];
	char loopIDStr[64];
	char tmp[128];

	//add root (main)
	fpCtxTree>>ucIDStr;
	fpCtxTree>>locIDStr;
	fpCtxTree>>kind;
	fpCtxTree>>tmp;
	fpCtxTree>>funName;
	assert(strcmp(kind, "CS") == 0 && strcmp(funName, "main") == 0);
	ContextTree *root = new ContextTree(true, NULL, 0, 0);
	root->setFunName(funName);
	ucIDMap[0] = root;

	//read ContextTree.data
	for (int i = 0; i < nNode-1; ++i){
		fpCtxTree>>ucIDStr;
		fpCtxTree>>locIDStr;
		UniqueContextID ucID = (UniqueContextID)(atoi(ucIDStr));
		LocalContextID locID = (LocalContextID)(atoi(locIDStr));
		ContextTree *curParent = ucIDMap[ ucID - locID ];

		fpCtxTree>>kind;
		if(strcmp(kind, "CS") == 0){
			fpCtxTree>>tmp; // recursive Fun? or normal?
			fpCtxTree>>funName;
			ContextTree *node = new ContextTree(true, curParent, ucID, (LocalContextID)(atoi(locIDStr)));
			node->setFunName(funName);
			curParent->addChild(node);
			ucIDMap[ucID] = node;
		}
		else if(strcmp(kind, "L") == 0){
			fpCtxTree>>loopIDStr;
			fpCtxTree>>tmp; // loop name;
			ContextTree *node = new ContextTree(false, curParent, ucID, (LocalContextID)(atoi(locIDStr)));
			LoopID loopID = (LoopID)(atoi(loopIDStr));
			node->setLoopID(loopID);
			curParent->addChild(node);

			ucIDMap[ucID] = node;
			loopMap[loopID].push_back(ucID);
		}
		else
			assert(0 &&"WTF?");
	}

	fpCtxTree.getline(line, MAX_LINE_SIZE); // for last char "\n" of last element Node
	fpCtxTree.getline(line, MAX_LINE_SIZE);
	string endMsg("$$$$$ CONTEXT TREE END $$$$$");
	assert(endMsg.compare(line) == 0);
	fpCtxTree.close();

	// ##################################################################### //
	// ####################### read CAMP_instIDtoUcID.data ################# //
	// ##################################################################### //
	std::unordered_map <InstrID, std::vector< UniqueContextID >> instIDtoUcID;

	std::ifstream fp_instIDtoUcID ("CAMP_instIDtoUcID.data", std::ifstream::binary);
	assert(fp_instIDtoUcID);
	fp_instIDtoUcID.getline(line, MAX_LINE_SIZE);
	string fp_instIDtoUcID_startMsg("$$$$$ CAMP InstID to UCID START $$$$$");
	assert(fp_instIDtoUcID_startMsg.compare(line) == 0);
	fp_instIDtoUcID.getline(line, MAX_LINE_SIZE); //assume one target for now (16/5/15)
	unsigned instIDtoUcID_MapSize = (unsigned)(atoi(line));
	for (int i = 0; i < instIDtoUcID_MapSize; ++i){
		fp_instIDtoUcID.getline(line, MAX_LINE_SIZE);
		InstrID instID=0;
		int vsize = 0;
		if(sscanf (line,"InstrID: %hd, vector's size: %d",&instID,&vsize) != 2) assert(0 && "ERROR: read fail 2");
		assert(vsize != 0);
		for (int j = 0; j < vsize; ++j){
			fp_instIDtoUcID.getline(line, MAX_LINE_SIZE);
			UniqueContextID ucid = (UniqueContextID)(atoi(line));
			instIDtoUcID[instID].push_back(ucid);
		}
	}
	string fp_instIDtoUcID_endMsg("$$$$$ CAMP InstID to UCID END $$$$$");
	fp_instIDtoUcID.close();

	// std::cout<<" totalSize: "<<instIDtoUcID.size()<<"\n";
	// for(auto e: instIDtoUcID){
	// 	std::cout<<" >>InstrID: "<<e.first<<", size:"<< e.second.size()<<"\n";
	// 	for(auto id: e.second){
	// 		std::cout<<".. "<<id<<"\n";
	// 	}
	// }

	// ##################################################################### //
	// ####################### read DependenceTable.data ################### //
	// ##################################################################### //
	std::ifstream fpDepTb ("DependenceTable.real.data", std::ifstream::binary);
	assert(fpDepTb);

	std::unordered_map<DepKey, std::vector<Dependence *>> depMap;
	std::vector<Dependence *> depList;

	char depStr[128];
	while(fpDepTb >> depStr){ // Attempt read into depStr, return false if it fails
		uint32_t campIDsrc=0;
		uint32_t campIDdst=0;
		uint32_t iterRel=0;
		if(sscanf (depStr,"%x>%x:%x",&campIDsrc,&campIDdst, &iterRel) != 3) assert(0 && "ERROR: read fail");
		Dependence *newDep = new Dependence(campIDsrc>>16, campIDdst>>16, campIDsrc & 0xffff, campIDdst & 0xffff);
		newDep->addIterRel(iterRel);

		depList.push_back(newDep);
		depMap[newDep->getDepKey()].push_back(newDep);
	}
	cout<<"DependenceTable.data =>(# deps : "<<depList.size()<<", # of edges to distinct ctxt: "<<depMap.size()<<")\n";
	// cout<<depList.size()<<"\t"<<depMap.size()<<"\n";
	fpDepTb.close();

	
	for(Dependence *dep : depList){
		
		std::list<ContextTreeNode *> cxtStksrc;
		std::list<ContextTreeNode *> cxtStkdst;
		ucIDMap[dep->ucIDsrc]->getContextStack(&cxtStksrc); assert(!cxtStksrc.empty());
		ucIDMap[dep->ucIDdst]->getContextStack(&cxtStkdst); assert(!cxtStkdst.empty());
		std::list<ContextTreeNode *> cxtStkLoop;
		// cout<<"~~ "<<cxtStksrc.front()->getUCID()<<", "<<cxtStksrc.size()<<", "<<cxtStkdst.size()<<";;;";
		while(cxtStksrc.front()->getUCID() == cxtStkdst.front()->getUCID() && !cxtStkdst.empty() && !cxtStksrc.empty()){
			assert(cxtStksrc.front() == cxtStkdst.front());
			if(cxtStksrc.front()->isCallSite == false)
				cxtStkLoop.push_back(cxtStksrc.front()); //only push loop node
			cxtStksrc.pop_front();
			cxtStkdst.pop_front();
			if(cxtStksrc.empty() || cxtStkdst.empty())
				break;
		}
		if(cxtStkLoop.empty() == false){
			if(dep->iterRel[cxtStkLoop.size()-1] == X){
				uint32_t iterRel=0xaaaaaaaa;//means it's inter (or both)
				dep->addIterRel(iterRel);
			}
			if(dep->iterRel[cxtStkLoop.size()-1] == M){
				uint32_t iterRel=0xffffffff;//means it's inter (or both)
				dep->addIterRel(iterRel);
			}
		}
		cxtStksrc.clear();
		cxtStkdst.clear();
	}
	

	//******************************************************************************************************************//
	//************************************************ CS anal Start ***************************************************//
	//******************************************************************************************************************//

	// ##################################################################### //
	// ####################### identify all campID belongs to target ################### //
	// ##################################################################### //
	IdentifyTargetCampID *targetAnalyzer = new IdentifyTargetCampID(natoff_target, root);
	std::vector<std::unordered_set<UniqueContextID>> ucIDSetLi = targetAnalyzer->getUcIDSetList();
	// for(auto e : ucIDSetLi){
	// 	std::cout<<"insider ucID Set Size: "<< e.size()<<"\n";
	// 	// for(auto eUcID: e)
	// 	// 	std::cout<<"> "<< eUcID<<"\n";
	// }

	//##########################
	// ############ Context-Sensitive Ins Outs for Native Offloader target
	//##########################
	int invoIdx = 0;
	std::vector<std::unordered_set<Dependence *>> csInDeps;
	std::vector<std::unordered_set<Dependence *>> csOutDeps;
	for(auto ucIDSet : ucIDSetLi){
		std::unordered_set<Dependence *> newSetIn;
		std::unordered_set<Dependence *> newSetOut;
		csInDeps.push_back(newSetIn);
		csOutDeps.push_back(newSetOut);
		for(Dependence *d : depList){
			bool isSrcIn = ucIDSet.find(d->ucIDsrc) != ucIDSet.end();
			bool isDstIn = ucIDSet.find(d->ucIDdst) != ucIDSet.end();
			if(isSrcIn != isDstIn){ //XOR
				if(isDstIn && !(isSrcIn))
					csInDeps[invoIdx].insert(d);
				if(isSrcIn && !(isDstIn))
					csOutDeps[invoIdx].insert(d);
			}
		}
		invoIdx++;
	}

	// ######################
	// ##### record src CampID of In Edges of Context Sensitive case.
	// ######################
	std::set<CampID> srcCampIDSetOfCtxtSensitive_In;
	for(std::unordered_set<Dependence *> set : csInDeps)
		for(Dependence *d : set)
			srcCampIDSetOfCtxtSensitive_In.insert(d->ucIDsrc << 16 | d->instrIDsrc);

	std::ofstream outfile_srcCampID_CS_InEdge("Src_CampIDList_CS_InEdge.data", std::ios::out | std::ofstream::binary);
	if(outfile_srcCampID_CS_InEdge.is_open()){
		outfile_srcCampID_CS_InEdge<<"$$$$$ Context-Sensitive [IN Edge] Src-CampID $$$$$\n";
		outfile_srcCampID_CS_InEdge<<srcCampIDSetOfCtxtSensitive_In.size()<<"\n";
		for(CampID id: srcCampIDSetOfCtxtSensitive_In){
			outfile_srcCampID_CS_InEdge<<id<<"\n";
		}
		outfile_srcCampID_CS_InEdge<<"$$$$$ Context-Sensitive [IN Edge] Src-CampID END $$$$$\n";
	}
	outfile_srcCampID_CS_InEdge.close();

	// ######################
	// ##### record src CampID of Out Edges of Context Sensitive case.
	// ######################
	std::set<CampID> srcCampIDSetOfCtxtSensitive_Out;
	for(std::unordered_set<Dependence *> set : csOutDeps)
		for(Dependence *d : set)
			srcCampIDSetOfCtxtSensitive_Out.insert(d->ucIDsrc << 16 | d->instrIDsrc);

	std::ofstream outfile_srcCampID_CS_OutEdge("Src_CampIDList_CS_OutEdge.data", std::ios::out | std::ofstream::binary);
	if(outfile_srcCampID_CS_OutEdge.is_open()){
		outfile_srcCampID_CS_OutEdge<<"$$$$$ Context-Sensitive [Out Edge] Src-CampID $$$$$\n";
		outfile_srcCampID_CS_OutEdge<<srcCampIDSetOfCtxtSensitive_Out.size()<<"\n";
		for(CampID id: srcCampIDSetOfCtxtSensitive_Out){
			outfile_srcCampID_CS_OutEdge<<id<<"\n";
		}
		outfile_srcCampID_CS_OutEdge<<"$$$$$ Context-Sensitive [Out Edge] Src-CampID END $$$$$\n";
	}
	outfile_srcCampID_CS_OutEdge.close();


	std::cout<<"Context-Sensitive \n";
	for (int i = 0; i < csInDeps.size(); ++i)
		cout<<"<"<<i<<">: (nIns: "<<csInDeps[i].size()<<", nOuts: "<<csOutDeps[i].size()<<")\n";

	//******************************************************************************************************************//
	//************************************************ CS anal Done ****************************************************//
	//******************************************************************************************************************//

	// ##################################################################### //
	// ####################### Refine instIDtoUcID for Recursive Case ###### //
	// ##################################################################### //
	for(Dependence *d : depList){
		if(find(instIDtoUcID[d->instrIDsrc].begin(), instIDtoUcID[d->instrIDsrc].end(), d->ucIDsrc) == instIDtoUcID[d->instrIDsrc].end())
			instIDtoUcID[d->instrIDsrc].push_back(d->ucIDsrc);
		if(find(instIDtoUcID[d->instrIDdst].begin(), instIDtoUcID[d->instrIDdst].end(), d->ucIDdst) == instIDtoUcID[d->instrIDdst].end())
			instIDtoUcID[d->instrIDdst].push_back(d->ucIDdst);
	}


	// ##################################################################### //
	// ####################### False Positive Dependence Analysis (FPDA) ################### //
	// ##################################################################### //
	std::set<FunctionName> insideFunSet = targetAnalyzer->getInsideFunSet();
	std::set<LoopID> insideLoopSet = targetAnalyzer->getInsideLoopSet();
	
	// for(auto e : insideFunSet)
	// 	cout<<" inside: "<<e<<"\n";
	std::string dotFile("ContextTree_TargetAware.dot");
	// contextTreeDumpToDOT(dotFile, root, insideFunSet, insideLoopSet, ucIDSetLi, depList, instIDtoUcID);

	std::string dotFile2("ContextTree_CaseAnal.dot");
	contextTreeDumpToDOT_CASEANAL(dotFile2, root, insideFunSet, insideLoopSet, ucIDSetLi, depList, instIDtoUcID);
}

