#include "../campPostProc/PostProcess.hpp"
#include "IdentifyTargetCampID.hpp"
#include <set>
#include <list>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <iostream>
#include <fstream>
#include <algorithm>

using namespace corelab;

typedef std::string FunctionName;
void contextTreeDumpToDOT_CASEANAL(std::string path, corelab::ContextTree *root,
				std::set<FunctionName> &insideFunSet, std::set<LoopID> &insideLoopSet,
				std::vector<std::unordered_set<corelab::UniqueContextID>> &ucIDSetLi, std::vector<Dependence *> &depList,
				std::unordered_map <InstrID, std::vector< UniqueContextID >> &instIDtoUcID){
	
	// ################################################################################# //
	// ################ read case anal data file
	std::set<InstrID> loadInstIDs;
	std::set<InstrID> storeInstIDs;
	std::set<InstrID> unionInstIDs;
	std::ifstream fpCaseAnalLoad ("CAMP_CASE_ANAL_load.data", std::ifstream::binary);
	assert(fpCaseAnalLoad);
	int inputLine1 = 0;
	while(fpCaseAnalLoad>>inputLine1){
		// std::cout<<"read "<<inputLine1<<"\n";
		loadInstIDs.insert(inputLine1);
	}
	fpCaseAnalLoad.close();
	std::ifstream fpCaseAnalStore ("CAMP_CASE_ANAL_store.data", std::ifstream::binary);
	assert(fpCaseAnalStore);
	int inputLine2 = 0;
	while(fpCaseAnalStore>>inputLine2){
		// std::cout<<"read "<<inputLine2<<"\n";
		storeInstIDs.insert(inputLine2);
	}
	fpCaseAnalStore.close();
	unionInstIDs.insert(loadInstIDs.begin(), loadInstIDs.end());
	unionInstIDs.insert(storeInstIDs.begin(), storeInstIDs.end());
	std::cout<<" # ldInstID: "<< loadInstIDs.size() <<", # stInstID: "<< storeInstIDs.size() <<", total: "<< unionInstIDs.size() <<"\n";
	// ################ read case anal data file END
	// ################################################################################# //

	std::unordered_map<ContextIgnorantDependence, std::set< Dependence * > > ciDepList;
	std::unordered_map<ContextIgnorantDependence, std::vector< DependenceSimplified > > ciRedEdges;
	std::vector< DependenceSimplified > ciRedEdgesSimplified;
	
	for(Dependence *d : depList){
		bool isSrcCase = unionInstIDs.find(d->instrIDsrc) != unionInstIDs.end();
		bool isDstCase = unionInstIDs.find(d->instrIDdst) != unionInstIDs.end();
		if(isSrcCase && isDstCase){
			ContextIgnorantDependence ciDep(d->instrIDsrc, d->instrIDdst);
			ciDepList[ciDep].insert(d);
		}
	}
	unsigned ciEdge = 0;
	for(auto e: ciDepList){
		for(UniqueContextID srcUCID : instIDtoUcID[e.first.instrIDsrc]){
			for(UniqueContextID dstUCID : instIDtoUcID[e.first.instrIDdst]){
				DependenceSimplified dep(srcUCID, dstUCID, e.first.instrIDsrc, e.first.instrIDdst);
				ciRedEdges[e.first].push_back(dep);
			}
		}
	}

	for(auto e : ciRedEdges) ciEdge += e.second.size();
	// std::cout<<" #: ciEdge: "<<ciEdge<<"\n";


	// ####################################################################################### //
	// Draw Edges ############################################################################ //
	// ####################################################################################### //
	std::ofstream outfile(path, std::ios::out | std::ofstream::binary);
	outfile<<"digraph G {\n";

	unsigned csEdgeDrawLimit = 4;
	unsigned csEdgeDrawn=0;
	std::set<std::pair<UniqueContextID, UniqueContextID>> drawnEdges;
	std::set<std::pair<InstrID, InstrID>> drawnEdgesInstID;
	std::set<std::pair<UniqueContextID, UniqueContextID>> csEdgeSet;
	unsigned csEdge=0;
	for(Dependence *d : depList){
		bool isSrcCase = unionInstIDs.find(d->instrIDsrc) != unionInstIDs.end();
		bool isDstCase = unionInstIDs.find(d->instrIDdst) != unionInstIDs.end();

		if(isSrcCase && isDstCase){
			csEdge++;
			csEdgeSet.insert(std::make_pair(d->ucIDsrc, d->ucIDdst));
			if(drawnEdges.find(std::make_pair(d->ucIDsrc, d->ucIDdst)) == drawnEdges.end()){
				if(d->ucIDsrc != d->ucIDdst) //self edges
				if(csEdgeDrawLimit >= csEdgeDrawn){// && csEdge%13==0

					drawnEdges.insert(std::make_pair(d->ucIDsrc, d->ucIDdst));
					drawnEdgesInstID.insert(std::make_pair(d->instrIDsrc, d->instrIDdst));
					outfile<<d->ucIDsrc<<" -> "<< d->ucIDdst <<" [style=\"bold\", color=\"blue\"];\n"; //FP when CI
					csEdgeDrawn++;
				}
			}
		}
	}
	std::cout<<" #: csEdge: ("<<csEdge<<", "<<csEdgeDrawn<<")\n";

	for(auto e: drawnEdgesInstID){
		for(UniqueContextID srcUCID : instIDtoUcID[e.first]){
			for(UniqueContextID dstUCID : instIDtoUcID[e.second]){
				DependenceSimplified dep(srcUCID, dstUCID, e.first, e.second);
				ciRedEdgesSimplified.push_back(dep);
			}
		}
	}

	unsigned ciEdgeDrawLimit = 20;
	unsigned ciEdgeDrawn=0;
	unsigned dsCnt=0;
	for(auto ds : ciRedEdgesSimplified){
		// These two condition is definitely true (see its generation code)
		// bool isSrcCase = unionInstIDs.find(d->instrIDsrc) != unionInstIDs.end();
		// bool isDstCase = unionInstIDs.find(d->instrIDdst) != unionInstIDs.end();
		if(drawnEdges.find(std::make_pair(ds.ucIDsrc, ds.ucIDdst)) == drawnEdges.end() 
		 && csEdgeSet.find(std::make_pair(ds.ucIDsrc, ds.ucIDdst)) == csEdgeSet.end()){
			if(ciEdgeDrawLimit >= ciEdgeDrawn && ((0<=dsCnt&&dsCnt<3) || (1760<=dsCnt&&dsCnt<1765) || (32380<=dsCnt&&dsCnt<32382))
			  ) //&& (dsCnt%2==0 || dsCnt%3==1)
			{
				drawnEdges.insert(std::make_pair(ds.ucIDsrc, ds.ucIDdst));
				// if(d->ucIDsrc != d->ucIDdst) //self edges
				outfile<<ds.ucIDsrc<<" -> "<< ds.ucIDdst <<" [style=\"dotted\", color=\"Red\"];\n"; //FP when CI
				ciEdgeDrawn++;	
			}
		}
		dsCnt++;
	}
	std::cout<<" #: ciEdge: ("<<ciEdge<<", "<<ciEdgeDrawn<<")\n";

	std::set<UniqueContextID> nodesShouldBeDrawn;
	for(auto e : drawnEdges){
		nodesShouldBeDrawn.insert(e.first);
		nodesShouldBeDrawn.insert(e.second);
	}

	// ################################################################################# //
	// ####################### Choose nodes to be drawn ################################ //
	// ################################################################################# //
	std::list<ContextTree *> searchQueueForChice;
	searchQueueForChice.push_back(root);

	while(!searchQueueForChice.empty()){
		ContextTree *node = searchQueueForChice.front();
		searchQueueForChice.pop_front();

		UniqueContextID ucid = node->getUCID();

		if(nodesShouldBeDrawn.find(ucid) != nodesShouldBeDrawn.end()){
			//up travere to root
			ContextTree *curNode = node->getParent();
			while(curNode != NULL){
				nodesShouldBeDrawn.insert(curNode->getUCID());
				curNode = curNode->getParent();
			}
		}

		for(ContextTree *c : node->children)
			searchQueueForChice.push_back(c);
	}

	// ################################################################################# //
	// ############################## Draw Context Tree ################################ //
	// ################################################################################# //

	std::list<ContextTree *> searchQueue;
	searchQueue.push_back(root);

	while(!searchQueue.empty()){
		ContextTree *node = searchQueue.front();
		searchQueue.pop_front();

		UniqueContextID ucid = node->getUCID();

		if(nodesShouldBeDrawn.find(ucid) != nodesShouldBeDrawn.end()){
			outfile << ucid;
			if(node->isCallSiteNode()){
				outfile << " [shape=box, style=filled," 
						<< "fillcolor = \"gray\","
						<< "label=\""<<node->getFunName()<<"\"];\n";
			}
			else{
				outfile << " [shape=circle, style=filled,"
						<< " fillcolor = \"gray\","
						<< " label=\""<<node->getLoopID()<<"\"];\n";
			}

			if( node->getUCID() != 0 ){ //exclude root
				outfile<<node->getParent()->getUCID()<<" -> "<< ucid <<";\n";
			}	
		}
		
		for(ContextTree *c : node->children)
			searchQueue.push_back(c);
	}
	
	outfile<<"}";
	outfile.close();

	// // draw depedence (general)
	// for(Dependence *d: depList){
	// 	if(d->instrIDdst == 2056)
	// 		std::cout<<"2056 src instID:"<<d->instrIDsrc<<"\n";
	// 	if(d->instrIDdst == 2062)
	// 		std::cout<<"2062 src instID:"<<d->instrIDsrc<<"\n";
	// 	if(d->instrIDdst == 2064)
	// 		std::cout<<"2064 src instID:"<<d->instrIDsrc<<"\n";
	// 	if(d->instrIDsrc == 2055)
	// 		std::cout<<"2055 dst instID:"<<d->instrIDdst<<"\n";
	// 	// outfile<<d->ucIDsrc<<" -> "<< d->ucIDdst <<" [style=\"bold\", color=\"green\"];\n"; 
	// }
}