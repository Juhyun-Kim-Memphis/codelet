#ifndef CORELAB_CAMP_IDENTIFY_TARGET_CAMP_ID_HPP
#define CORELAB_CAMP_IDENTIFY_TARGET_CAMP_ID_HPP

#include <inttypes.h>
#include <vector>
#include <list>
#include <cstring>
#include <set>
#include <unordered_set>
#include <map>

#include "../campPostProc/PostProcess.hpp"

namespace corelab
{
	using namespace std;
	class IdentifyTargetCampID{
		public:
			typedef std::unordered_set<UniqueContextID> UcIDSetForOneCallSiteOfTarget;
			typedef std::string FunctionName;

			IdentifyTargetCampID(std::string tar, ContextTree *r){
				target.assign(tar);
				root = r;
				csNodesOfTarget = getAllCallSiteNodesOfTarget(root);
				constructUcIDSetList();
			}

			std::vector<ContextTree *> &getCSNodesOfTarget(){return csNodesOfTarget;}
			std::vector<UcIDSetForOneCallSiteOfTarget> &getUcIDSetList(){return ucIDSetList;}

			//FPDA code
			std::set<FunctionName> &getInsideFunSet(){return insideFunSet;}
			std::set<LoopID> &getInsideLoopSet(){return insideLoopSet;}


		private:
			ContextTree *root;
			std::string target;

			std::vector<ContextTree *> csNodesOfTarget;
			std::vector<UcIDSetForOneCallSiteOfTarget> ucIDSetList;

			//irrelevant to this class, but for finding False Positive Dependence Analysis (FPDA)
			//Set of (Callee) Function that are called inside offloader Target (Functions whose callsite node has been in offloading target's Sub-tree)
			std::set<FunctionName> insideFunSet;
			std::set<LoopID> insideLoopSet;

			void constructUcIDSetList();
			std::vector<ContextTree *> getAllCallSiteNodesOfTarget(ContextTree *root);
	};

	class IdentifyTargetInstID{
		public:
			IdentifyTargetInstID(const std::vector<Dependence *> *depList_,
								 const std::vector<std::unordered_set<UniqueContextID>> *ucIDSet_){
				depList = depList_;
				ucIDSet = ucIDSet_;
				constructInstrIDSet();
			}

			std::unordered_set<InstrID> &getInstrIDSet(){return instrIDSet;}

		private:
			std::unordered_set<InstrID> instrIDSet;

			void constructInstrIDSet();
			const std::vector<Dependence *> *depList;
			const std::vector<std::unordered_set<UniqueContextID>> *ucIDSet;
	};


	//TODO:: original Dependence should inherit this.. but..
	class ContextIgnorantDependence {
		public:
			ContextIgnorantDependence(InstrID instrIDsrc_, InstrID instrIDdst_) : instrIDsrc(instrIDsrc_), instrIDdst(instrIDdst_) {}
			InstrID instrIDsrc;
			InstrID instrIDdst;

			bool operator==(const ContextIgnorantDependence &other) const{ 
				return (instrIDsrc == other.instrIDsrc && instrIDdst == other.instrIDdst);
			}
	};
}

namespace std {

	template <>
	struct hash<corelab::ContextIgnorantDependence>
	{
		std::size_t operator()(const corelab::ContextIgnorantDependence& k) const{
			return (std::hash<uint32_t>()(k.instrIDsrc) + (((uint32_t)(std::hash<uint32_t>()(k.instrIDdst))<<16) & 0xffff0000) );
		}
	};

}

#endif //CORELAB_CAMP_IDENTIFY_TARGET_CAMP_ID_HPP
