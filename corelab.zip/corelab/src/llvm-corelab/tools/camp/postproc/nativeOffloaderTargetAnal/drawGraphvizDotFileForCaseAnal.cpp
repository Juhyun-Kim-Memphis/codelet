#include "../campPostProc/PostProcess.hpp"
#include "IdentifyTargetCampID.hpp"
#include <set>
#include <list>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <iostream>
#include <fstream>
#include <algorithm>

using namespace corelab;

typedef std::string FunctionName;
void contextTreeDumpToDOT_CASEANAL(std::string path, corelab::ContextTree *root,
				std::set<FunctionName> &insideFunSet, std::set<LoopID> &insideLoopSet,
				std::vector<std::unordered_set<corelab::UniqueContextID>> &ucIDSetLi, std::vector<Dependence *> &depList,
				std::unordered_map <InstrID, std::vector< UniqueContextID >> &instIDtoUcID){
	
	// ################################################################################# //
	// ################ read case anal data file
	std::set<InstrID> loadInstIDs;
	std::set<InstrID> storeInstIDs;
	std::set<InstrID> unionInstIDs;
	std::ifstream fpCaseAnalLoad ("CAMP_CASE_ANAL_load.data", std::ifstream::binary);
	assert(fpCaseAnalLoad);
	int inputLine1 = 0;
	while(fpCaseAnalLoad>>inputLine1){
		// std::cout<<"read "<<inputLine1<<"\n";
		loadInstIDs.insert(inputLine1);
	}
	fpCaseAnalLoad.close();
	std::ifstream fpCaseAnalStore ("CAMP_CASE_ANAL_store.data", std::ifstream::binary);
	assert(fpCaseAnalStore);
	int inputLine2 = 0;
	while(fpCaseAnalStore>>inputLine2){
		// std::cout<<"read "<<inputLine2<<"\n";
		storeInstIDs.insert(inputLine2);
	}
	fpCaseAnalStore.close();
	unionInstIDs.insert(loadInstIDs.begin(), loadInstIDs.end());
	unionInstIDs.insert(storeInstIDs.begin(), storeInstIDs.end());
	std::cout<<" # ldInstID: "<< loadInstIDs.size() <<", # stInstID: "<< storeInstIDs.size() <<", total: "<< unionInstIDs.size() <<"\n";
	// ################ read case anal data file END
	// ################################################################################# //

	std::unordered_map<ContextIgnorantDependence, std::set< Dependence * > > ciDepList;
	std::unordered_map<ContextIgnorantDependence, std::vector< DependenceSimplified > > ciRedEdges;
	std::set<std::pair<UniqueContextID, UniqueContextID>> interDepAmongCSEdgeSet;
	std::set<std::pair<UniqueContextID, UniqueContextID>> mixDepAmongCSEdgeSet;
	
	unsigned csEdge = 0;
	for(Dependence *d : depList){
		bool isSrcCase = unionInstIDs.find(d->instrIDsrc) != unionInstIDs.end();
		bool isDstCase = unionInstIDs.find(d->instrIDdst) != unionInstIDs.end();
		if(isSrcCase && isDstCase){
			ContextIgnorantDependence ciDep(d->instrIDsrc, d->instrIDdst);
			ciDepList[ciDep].insert(d);

			//########################################## identify if it is inter-dep
			// std::cout<<"IterRel: {";
			bool isInter = true;
			for (int i = 0; i < 16; ++i){
				// std::cout<<(d->iterRel[i]==0?'N':d->iterRel[i]==1?'I':d->iterRel[i]==2?'X':'M')<<", ";
				isInter &= ((d->iterRel[i]==2) ? true : false);
			}
			if(isInter)
				interDepAmongCSEdgeSet.insert(make_pair(d->ucIDsrc, d->ucIDdst));

			bool ismix = true;
			for (int i = 0; i < 16; ++i){
				// std::cout<<(d->iterRel[i]==0?'N':d->iterRel[i]==1?'I':d->iterRel[i]==2?'X':'M')<<", ";
				ismix &= ((d->iterRel[i]==3) ? true : false);
			}
			if(ismix)
				mixDepAmongCSEdgeSet.insert(make_pair(d->ucIDsrc, d->ucIDdst));

			csEdge++;
			// std::cout<<"} "<<isInter<<"\n";

			// if(d->ucIDsrc == 757 && d->ucIDdst == 757){
			// 	d->printIterRel();
			// 	cout<<"\n";
			// 	cout<<" srcInstID: "<<d->instrIDsrc<<", dstInstID: "<<d->instrIDdst<<"\n";
			// }
		}
	}
	unsigned ciEdge = 0;
	for(auto e: ciDepList){
		for(UniqueContextID srcUCID : instIDtoUcID[e.first.instrIDsrc]){
			for(UniqueContextID dstUCID : instIDtoUcID[e.first.instrIDdst]){
				DependenceSimplified dep(srcUCID, dstUCID, e.first.instrIDsrc, e.first.instrIDdst);
				ciRedEdges[e.first].push_back(dep);
			}
		}
	}

	for(auto e : ciRedEdges) ciEdge += e.second.size();
	std::cout<<" #: ciEdge: "<<ciEdge<<", cs:"<< csEdge <<"\n";
	std::cout<<"~~~~ interDep total:"<<interDepAmongCSEdgeSet.size()<<", mix deps total:"<<mixDepAmongCSEdgeSet.size()<<"\n";

	// ####################################################################################### //
	// Choose relevant Edges ################################################################# //
	// ####################################################################################### //
	std::ofstream outfile(path, std::ios::out | std::ofstream::binary);
	outfile<<"digraph G {\n";

	std::set<std::pair<UniqueContextID, UniqueContextID>> csEdgeSet;
	std::vector< DependenceSimplified > ciRedEdgesSimplified;
	for(Dependence *d : depList){
		bool isSrcCase = unionInstIDs.find(d->instrIDsrc) != unionInstIDs.end();
		bool isDstCase = unionInstIDs.find(d->instrIDdst) != unionInstIDs.end();

		if(isSrcCase && isDstCase){
			csEdgeSet.insert(std::make_pair(d->ucIDsrc, d->ucIDdst));

			for(UniqueContextID srcUCID : instIDtoUcID[d->instrIDsrc]){
				for(UniqueContextID dstUCID : instIDtoUcID[d->instrIDdst]){
					DependenceSimplified dep(srcUCID, dstUCID, d->instrIDsrc, d->instrIDdst);
					ciRedEdgesSimplified.push_back(dep);
				}
			}
		}
	}
	std::cout<<" #: csEdge: ("<<csEdgeSet.size()<<", "<< 0 <<")\n";

	std::set<std::pair<UniqueContextID, UniqueContextID>> ciEdgeSet;
	for(auto ds : ciRedEdgesSimplified){
		// These two condition is definitely true (see its generation code)
		// bool isSrcCase = unionInstIDs.find(d->instrIDsrc) != unionInstIDs.end();
		// bool isDstCase = unionInstIDs.find(d->instrIDdst) != unionInstIDs.end();
		if(csEdgeSet.find(std::make_pair(ds.ucIDsrc, ds.ucIDdst)) == csEdgeSet.end()){
			ciEdgeSet.insert(std::make_pair(ds.ucIDsrc, ds.ucIDdst));
		}
	}
	std::cout<<" #: ciEdge: ("<<ciEdgeSet.size()<<", "<< 0 <<")\n";

	// ################################################################################# //
	// ####################### Choose nodes to be drawn ################################ //
	// ################################################################################# //
	std::list<ContextTree *> searchQueueForFindTheNode;
	searchQueueForFindTheNode.push_back(root);
	ContextTree *flush_block_node = NULL;

	while(!searchQueueForFindTheNode.empty()){
		ContextTree *node = searchQueueForFindTheNode.front();
		searchQueueForFindTheNode.pop_front();

		UniqueContextID ucid = node->getUCID();

		if(ucid == 598)//733
			flush_block_node = node;

		for(ContextTree *c : node->children)
			searchQueueForFindTheNode.push_back(c);
	}

	// ################################################################################# //
	// ############################## Draw Context Tree ################################ //
	// ################################################################################# //

	std::list<ContextTree *> searchQueue;
	searchQueue.push_back(flush_block_node);
	std::set<UniqueContextID> drawnNodes;

	while(!searchQueue.empty()){
		ContextTree *node = searchQueue.front();
		searchQueue.pop_front();

		UniqueContextID ucid = node->getUCID();

		if(
		ucid == 733 ||
		ucid == 734 ||
		ucid == 745 ||
		ucid == 746 ||
		ucid == 757 ||
		ucid == 768 ||
		ucid == 779 ||
		ucid == 790){
			outfile << ucid;
				if(node->isCallSiteNode()){
					outfile << " [shape=box, style=filled," 
							<< "fillcolor = \"gray\","
							<< "label=\""<<node->getFunName()<<"\"];\n";
				}
				else{
					outfile << " [shape=circle, style=filled,"
							<< " fillcolor = \"gray\","
							<< " label=\""<<node->getLoopID()<<"\"];\n";
				}
				drawnNodes.insert(ucid);

				if( node->getUCID() != 0 ){ //exclude root
					outfile<<node->getParent()->getUCID()<<" -> "<< ucid <<";\n";
				}
		}
		
		for(ContextTree *c : node->children)
			searchQueue.push_back(c);
	}

	// ####################################################################################### //
	// Draw relevant Edges ################################################################# //
	// ####################################################################################### //
	unsigned csEdgeDrawn=0;
	unsigned nInter=0;
	unsigned nIntra=0;
	unsigned nMix=0;
	for(auto p: csEdgeSet){
		bool srcDrawn = drawnNodes.find(p.first) != drawnNodes.end();
		bool dstDrawn = drawnNodes.find(p.second) != drawnNodes.end();
		if(srcDrawn && dstDrawn){
			bool isInter = interDepAmongCSEdgeSet.find(std::make_pair(p.first, p.second)) != interDepAmongCSEdgeSet.end();
			bool ismix = mixDepAmongCSEdgeSet.find(std::make_pair(p.first, p.second)) != mixDepAmongCSEdgeSet.end();

			outfile<<p.first<<" -> "<< p.second <<" [style=\""<<(isInter?"dotted":"")<<"\", color=\"blue\"];\n"; 
			csEdgeDrawn++;
			if(ismix) nMix++;
			else if(isInter) nInter++;
			else nIntra++;
		}
	}
	unsigned ciEdgeDrawn=0;
	for(auto p: ciEdgeSet){
		bool srcDrawn = drawnNodes.find(p.first) != drawnNodes.end();
		bool dstDrawn = drawnNodes.find(p.second) != drawnNodes.end();
		if(srcDrawn && dstDrawn){
			outfile<<p.first<<" -> "<< p.second <<" [style=\"\", color=\"Red\"];\n"; 
			ciEdgeDrawn++;
		}
	}

	cout<< "csEdgeDrawn: "<<csEdgeDrawn<<", ciEdgeDrawn: "
		<<ciEdgeDrawn<<", inter:"<<nInter<<", intra:"<<nIntra<<", mix:"<<nMix<<"\n";
	
	outfile<<"}";
	outfile.close();

	// // draw depedence (general)
	// for(Dependence *d: depList){
	// 	if(d->instrIDdst == 2056)
	// 		std::cout<<"2056 src instID:"<<d->instrIDsrc<<"\n";
	// 	if(d->instrIDdst == 2062)
	// 		std::cout<<"2062 src instID:"<<d->instrIDsrc<<"\n";
	// 	if(d->instrIDdst == 2064)
	// 		std::cout<<"2064 src instID:"<<d->instrIDsrc<<"\n";
	// 	if(d->instrIDsrc == 2055)
	// 		std::cout<<"2055 dst instID:"<<d->instrIDdst<<"\n";
	// 	// outfile<<d->ucIDsrc<<" -> "<< d->ucIDdst <<" [style=\"bold\", color=\"green\"];\n"; 
	// }
	
}