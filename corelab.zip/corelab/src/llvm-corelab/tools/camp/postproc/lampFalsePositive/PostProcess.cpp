#include <iostream>
#include <fstream>
#include <assert.h>
#include <stdlib.h>
#include <algorithm>
#include <unordered_map>
#include <map>
#include <unordered_set>

#include "PostProcess.hpp"

#define MAX_LINE_SIZE 4096

using namespace std;
using namespace corelab;

#define REGI_DEP_TEST

int main(int argc, char** argv){
	char line[MAX_LINE_SIZE];

	unsigned nNode = 0;
	unsigned cnt = 0;

	std::ifstream fpCtxTree ("ContextTree.data", std::ifstream::binary);
	assert(fpCtxTree);

	fpCtxTree.getline(line, MAX_LINE_SIZE);
	string startMsg("$$$$$ CONTEXT TREE IN PREORDER $$$$$");
	assert(startMsg.compare(line) == 0);
	fpCtxTree.getline(line, MAX_LINE_SIZE);
	nNode = (unsigned)(atoi(line));

	std::unordered_map<UniqueContextID, ContextTreeNode *> ucIDMap;
	std::unordered_map<LoopID, std::vector<UniqueContextID>> loopMap;

	char ucIDStr[64];
	char locIDStr[64];
	char kind[4];
	char funName[64];
	char loopIDStr[64];
	char tmp[128];

	//add root (main)
	fpCtxTree>>ucIDStr;
	fpCtxTree>>locIDStr;
	fpCtxTree>>kind;
	fpCtxTree>>tmp;
	fpCtxTree>>funName;
	assert(strcmp(kind, "CS") == 0 && strcmp(funName, "main") == 0);
	ContextTree *root = new ContextTree(true, NULL, 0, 0);
	root->setFunName(funName);
	ucIDMap[0] = root;

	//read ContextTree.data
	for (int i = 0; i < nNode-1; ++i){
		fpCtxTree>>ucIDStr;
		fpCtxTree>>locIDStr;
		UniqueContextID ucID = (UniqueContextID)(atoi(ucIDStr));
		LocalContextID locID = (LocalContextID)(atoi(locIDStr));
		ContextTree *curParent = ucIDMap[ ucID - locID ];

		fpCtxTree>>kind;
		if(strcmp(kind, "CS") == 0){
			fpCtxTree>>tmp; // recursive Fun? or normal?
			fpCtxTree>>funName;
			ContextTree *node = new ContextTree(true, curParent, ucID, (LocalContextID)(atoi(locIDStr)));
			node->setFunName(funName);
			curParent->addChild(node);
			ucIDMap[ucID] = node;
		}
		else if(strcmp(kind, "L") == 0){
			fpCtxTree>>loopIDStr;
			fpCtxTree>>tmp; // loop name;
			ContextTree *node = new ContextTree(false, curParent, ucID, (LocalContextID)(atoi(locIDStr)));
			LoopID loopID = (LoopID)(atoi(loopIDStr));
			node->setLoopID(loopID);
			curParent->addChild(node);

			ucIDMap[ucID] = node;
			loopMap[loopID].push_back(ucID);
		}
		else
			assert(0 &&"WTF?");
	}

	fpCtxTree.getline(line, MAX_LINE_SIZE); // for last char "\n" of last element Node
	fpCtxTree.getline(line, MAX_LINE_SIZE);
	string endMsg("$$$$$ CONTEXT TREE END $$$$$");
	assert(endMsg.compare(line) == 0);
	fpCtxTree.close();

	// ##################################################################### //
	// ####################### read DependenceTable.data ################### //
	// ##################################################################### //
	std::ifstream fpDepTb ("DependenceTable.real.data", std::ifstream::binary);
	assert(fpDepTb);

	std::unordered_map<DepKey, std::vector<Dependence *>> depMap;
	std::vector<Dependence *> depList;

	char depStr[128];
	while(fpDepTb >> depStr){ // Attempt read into depStr, return false if it fails
		uint32_t campIDsrc=0;
		uint32_t campIDdst=0;
		uint32_t iterRel=0;
		if(sscanf (depStr,"%x>%x:%x",&campIDsrc,&campIDdst, &iterRel) != 3) assert(0 && "ERROR: read fail");
		Dependence *newDep = new Dependence(campIDsrc>>16, campIDdst>>16, campIDsrc & 0xffff, campIDdst & 0xffff);
		newDep->addIterRel(iterRel);

		depList.push_back(newDep);
		depMap[newDep->getDepKey()].push_back(newDep);
	}
	cout<<"DependenceTable.data =>(# deps : "<<depList.size()<<", # of edges to distinct ctxt: "<<depMap.size()<<")\n";
	// cout<<depList.size()<<"\t"<<depMap.size()<<"\n";
	fpDepTb.close();

	// for(Dependence *dep : depList){
		
	// 	std::list<ContextTreeNode *> cxtStksrc;
	// 	std::list<ContextTreeNode *> cxtStkdst;
	// 	ucIDMap[dep->ucIDsrc]->getContextStack(&cxtStksrc); assert(!cxtStksrc.empty());
	// 	ucIDMap[dep->ucIDdst]->getContextStack(&cxtStkdst); assert(!cxtStkdst.empty());
	// 	std::list<ContextTreeNode *> cxtStkLoop;
	// 	// cout<<"~~ "<<cxtStksrc.front()->getUCID()<<", "<<cxtStksrc.size()<<", "<<cxtStkdst.size()<<";;;";
	// 	while(cxtStksrc.front()->getUCID() == cxtStkdst.front()->getUCID() && !cxtStkdst.empty() && !cxtStksrc.empty()){
	// 		assert(cxtStksrc.front() == cxtStkdst.front());
	// 		if(cxtStksrc.front()->isCallSite == false)
	// 			cxtStkLoop.push_back(cxtStksrc.front()); //only push loop node
	// 		cxtStksrc.pop_front();
	// 		cxtStkdst.pop_front();
	// 		if(cxtStksrc.empty() || cxtStkdst.empty())
	// 			break;
	// 	}
	// 	if(cxtStkLoop.empty() == false){
	// 		if(dep->iterRel[cxtStkLoop.size()-1] == X){
	// 			// uint32_t iterRel=0xaaaaaaaa;//means it's inter (or both)
	// 			// dep->addIterRel(iterRel);
	// 		}
	// 		if(dep->iterRel[cxtStkLoop.size()-1] == M){
	// 			// uint32_t iterRel=0xffffffff;//means it's inter (or both)
	// 			// dep->addIterRel(iterRel);
	// 		}
	// 	}
	// 	cxtStksrc.clear();
	// 	cxtStkdst.clear();
	// }
	//***********************************************************//
	// ##################################################################### //
	// ####################### read CAMP_instIDtoUcID.data ################# //
	// ##################################################################### //
	std::unordered_map <InstrID, std::vector< UniqueContextID >> instIDtoUcID;
	std::ifstream fp_instIDtoUcID ("CAMP_instIDtoUcID.data", std::ifstream::binary);
	assert(fp_instIDtoUcID);
	fp_instIDtoUcID.getline(line, MAX_LINE_SIZE);
	string fp_instIDtoUcID_startMsg("$$$$$ CAMP InstID to UCID START $$$$$");
	assert(fp_instIDtoUcID_startMsg.compare(line) == 0);
	fp_instIDtoUcID.getline(line, MAX_LINE_SIZE); //assume one target for now (16/5/15)
	unsigned instIDtoUcID_MapSize = (unsigned)(atoi(line));
	for (int i = 0; i < instIDtoUcID_MapSize; ++i){
		fp_instIDtoUcID.getline(line, MAX_LINE_SIZE);
		InstrID instID=0;
		int vsize = 0;
		if(sscanf (line,"InstrID: %hd, vector's size: %d",&instID,&vsize) != 2) assert(0 && "ERROR: read fail 2");
		assert(vsize != 0);
		for (int j = 0; j < vsize; ++j){
			fp_instIDtoUcID.getline(line, MAX_LINE_SIZE);
			UniqueContextID ucid = (UniqueContextID)(atoi(line));
			instIDtoUcID[instID].push_back(ucid);
		}
	}
	string fp_instIDtoUcID_endMsg("$$$$$ CAMP InstID to UCID END $$$$$");
	fp_instIDtoUcID.close();

	// std::cout<<" totalSize: "<<instIDtoUcID.size()<<"\n";
	// for(auto e: instIDtoUcID){
	// 	std::cout<<" >>InstrID: "<<e.first<<", size:"<< e.second.size()<<"\n";
	// 	for(auto id: e.second){
	// 		std::cout<<".. "<<id<<"\n";
	// 	}
	// }

	// ######################################################### //
	// ## make (Static Loop Stack ==> UCID list) mapping ####### //
	// ######################################################### //

	//TODO : Is this valid?
	std::map<std::vector<LoopID>, std::vector<UniqueContextID>> loopStackToUCIDlist;

	//traverse Context Tree
	std::cout<< " ucIDMap size:"<<ucIDMap.size()<<"\n";
	for(auto p : ucIDMap){
		UniqueContextID ucid = p.first;
		ContextTreeNode *node = p.second;
		ContextTreeNode *cur = p.second;

		std::vector<LoopID> loopStack;

		// if(node->isCallSiteNode()) continue;

		while(cur->getUCID() != 0){ //until we meet root
			if(!cur->isCallSiteNode()){
				loopStack.push_back(cur->getLoopID());
			}
			cur = cur->getParent();
		}
		assert(cur->getParent() == NULL);

		loopStackToUCIDlist[loopStack].push_back(ucid);
	}

	// for(auto p : loopStackToUCIDlist){
	// 	std::cout<<"[";
	// 	for(LoopID loopID : p.first){
	// 		std::cout<<loopID<<", ";
	// 	}
	// 	std::cout<<"] ==> (";
	// 	for(UniqueContextID ucid : p.second){
	// 		std::cout<<ucid<<", ";
	// 	}
	// 	std::cout<<")\n";
	// }

	// ######################################################### //
	// ############## make LAMP Dep ################### ####### //
	// ######################################################### //

	std::vector<LampDep> lampDepList;

	for(Dependence *d : depList){
		ContextTreeNode *srcNode = ucIDMap[d->ucIDsrc];
		ContextTreeNode *dstNode = ucIDMap[d->ucIDdst];

		std::vector<LoopID> srcLoopStack;
		while(srcNode->getUCID() != 0){
			if(!srcNode->isCallSiteNode()){
				srcLoopStack.push_back(srcNode->getLoopID());
			}
			srcNode = srcNode->getParent();
		}
		assert(srcNode->getParent() == NULL);

		std::vector<LoopID> dstLoopStack;
		while(dstNode->getUCID() != 0){
			if(!dstNode->isCallSiteNode()){
				dstLoopStack.push_back(dstNode->getLoopID());
			}
			dstNode = dstNode->getParent();
		}
		assert(dstNode->getParent() == NULL);

		// bool isMatched = false;
		// for(auto e : instIDtoUcID[d->instrIDsrc]){
		// 	isMatched = std::find(loopStackToUCIDlist[srcLoopStack].begin(), loopStackToUCIDlist[srcLoopStack].end(), e) != loopStackToUCIDlist[srcLoopStack].end();
		// 	if(isMatched) break;
		// }
		// // assert(isMatched);
		// if(isMatched == false){
		// 	std::cout<<"ERROR!! \n";
		// 	// assert(instIDtoUcID[d->instrIDsrc].size() != 0);
		// 	for(auto e2 : instIDtoUcID[d->instrIDsrc]){ std::cout<< e2 <<", "; } std::cout<<"\n";
		// 	for(auto e3 : loopStackToUCIDlist[srcLoopStack]){ std::cout<< e3 <<", "; } std::cout<<"\n";
		// 	std::cout << "ucid: "<<d->ucIDsrc<<"\n";
		// 	std::cout<<"@@@@--------------------\n";
		// }
		

		// d->printIterRel();
		LampDep lampDep(d->instrIDsrc, d->instrIDdst, srcLoopStack, dstLoopStack);
		lampDep.copyIterRel(d->iterRel);
		// lampDep.printIterRel();
		// std::cout<<"---\n";
		// exit(0);

		auto found = std::find(lampDepList.begin(), lampDepList.end(), lampDep);

		if(found == lampDepList.end()){
			lampDepList.push_back(lampDep);
		}
		else{
			// std::cout<<"FOUND\n";
		}
	}

	std::cout<<"size of lampDepList: "<<lampDepList.size()<<"\n";
	std::cout<<"size of CS depList: "<<depList.size()<<"\n";

	
	
	// ######################################################### //
	// ############## amplify ################### ####### //
	// ######################################################### //

	unsigned nAmplifiedLampDeps = 0;

	// std::vector<DependenceCS> amplifiedLampDeps;

	std::vector<UniqueContextID> allUCIDSet;
	for(auto p : ucIDMap){
		UniqueContextID ucid = p.first;
		allUCIDSet.push_back(ucid);
	}

	for(LampDep ld : lampDepList){

		//src amplify

		// assert(instIDtoUcID[ld.instrIDsrc].size() != 0);
		// assert(instIDtoUcID[ld.instrIDdst].size() != 0);
		// for(auto e1 : instIDtoUcID[ld.instrIDsrc]){ std::cout<< e1 <<", "; } std::cout<<"\n";
		// for(auto e2 : loopStackToUCIDlist[ld.srcLoopStack]){ std::cout<< e2 <<", "; } std::cout<<"\n";
		std::sort (instIDtoUcID[ld.instrIDsrc].begin(),instIDtoUcID[ld.instrIDsrc].end());
		std::sort (loopStackToUCIDlist[ld.srcLoopStack].begin(),loopStackToUCIDlist[ld.srcLoopStack].end());
		std::sort (instIDtoUcID[ld.instrIDdst].begin(),instIDtoUcID[ld.instrIDdst].end());
		std::sort (loopStackToUCIDlist[ld.dstLoopStack].begin(),loopStackToUCIDlist[ld.dstLoopStack].end());

		std::vector<UniqueContextID> srcIntersectionSet(instIDtoUcID[ld.instrIDsrc].size()+loopStackToUCIDlist[ld.srcLoopStack].size());
		std::vector<UniqueContextID> dstIntersectionSet(instIDtoUcID[ld.instrIDdst].size()+loopStackToUCIDlist[ld.dstLoopStack].size());

		auto itsrc = set_intersection(instIDtoUcID[ld.instrIDsrc].begin(), instIDtoUcID[ld.instrIDsrc].end(),
			loopStackToUCIDlist[ld.srcLoopStack].begin(),loopStackToUCIDlist[ld.srcLoopStack].end(), srcIntersectionSet.begin());
		srcIntersectionSet.resize(itsrc - srcIntersectionSet.begin());

		auto itdst = set_intersection(instIDtoUcID[ld.instrIDdst].begin(), instIDtoUcID[ld.instrIDdst].end(),
			loopStackToUCIDlist[ld.dstLoopStack].begin(),loopStackToUCIDlist[ld.dstLoopStack].end(), dstIntersectionSet.begin());
		dstIntersectionSet.resize(itdst - dstIntersectionSet.begin());

		// if(instIDtoUcID[ld.instrIDsrc].size() == 0)
		// 	srcIntersectionSet = loopStackToUCIDlist[ld.srcLoopStack];
		// if(instIDtoUcID[ld.instrIDdst].size() == 0)
		// 	dstIntersectionSet = loopStackToUCIDlist[ld.dstLoopStack];
		// if(srcIntersectionSet.size() == 0)
		// 	srcIntersectionSet = allUCIDSet;
		// if(dstIntersectionSet.size() == 0)
		// 	dstIntersectionSet = allUCIDSet;

		// assert((srcIntersectionSet.size()!=0) && (dstIntersectionSet.size()!=0));
		// if(!((dstIntersectionSet.size()!=0) && (srcIntersectionSet.size()!=0))){
		// 	std::cout<<"ld.srcLoopStack : ";
		// 	for(LoopID loopID : ld.srcLoopStack){ std::cout<<loopID<<", "; }
		// 	std::cout<<"\nld.dstLoopStack : ";
		// 	for(LoopID loopID : ld.dstLoopStack){ std::cout<<loopID<<", "; }
		// 	std::cout<<"===========\n";
		// 	std::cout<<"ucidList size :"<<loopStackToUCIDlist[ld.srcLoopStack].size()<<", "<<loopStackToUCIDlist[ld.dstLoopStack].size()<<"\n";
		// 	std::cout<<"@@@@@===========\n";
		// }

		for(auto srcUCID : srcIntersectionSet){
			for(auto dstUCID : dstIntersectionSet){
				nAmplifiedLampDeps++;

				// DependenceCS dep(srcUCID, dstUCID, ld.instrIDsrc, ld.instrIDdst, ld.getIterRelas32int());

				// bool alreayExist = std::find(amplifiedLampDeps.begin(), amplifiedLampDeps.end(), dep) != amplifiedLampDeps.end();
				// if(!alreayExist) amplifiedLampDeps.push_back(dep);
			}
		}
	}

	// // Ensure if we dont have any false positive
	// for(Dependence *dep : depList){
	// 	DependenceCS d(dep->ucIDsrc, dep->ucIDdst, dep->instrIDsrc, dep->instrIDdst, dep->getIterRelas32int());
	// 	assert(std::find(amplifiedLampDeps.begin(), amplifiedLampDeps.end(), d) != amplifiedLampDeps.end());
	// }

	std::cout 	<<"nAmplifiedLampDeps: "<<nAmplifiedLampDeps
			 	// <<", size of amplifiedLampDeps: "<<amplifiedLampDeps.size()
			 	<<", nCSDeps: "<<depList.size()<<"\n";


}


