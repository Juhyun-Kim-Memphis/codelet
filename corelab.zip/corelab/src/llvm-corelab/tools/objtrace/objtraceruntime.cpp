#include <stdio.h>
#include <iostream>
#include <assert.h>

#include "objtraceruntime.h"
#include "ShadowMemory.hpp"

AllocMap *allocIdMap;
LoadStoreMap *loadIdMap;
LoadStoreMap *storeIdMap;
uint64_t lowest_heap;

void shadowMemorySetting (void *addr, size_t size, FullID fullId){

	assert ((uint64_t)addr < 0x0000400000000000);
	uint64_t flipAddr = GET_SHADOW_ADDR_MALLOC_MAP(addr);

	for (unsigned int i = 0; i < (size-1)/8 + 1; i++)
	{	
		*( (uint64_t *)(flipAddr + (uint64_t)(i*8)) ) = fullId;
	}
}

void lowestHeapSetting (uint64_t addr){
	if ( lowest_heap > addr )
		lowest_heap = addr;
}

extern "C"
void objTraceInitialize () {
	ShadowMemoryManager::initialize();
	DEBUG("Obj Trace :: ShadowMemory Initialize Complete\n");
	allocIdMap = new AllocMap();
	loadIdMap = new LoadStoreMap();
	storeIdMap = new LoadStoreMap();
	lowest_heap = 0x0000000040000000;
}

extern "C"
void objTraceFinalize () {
	DEBUG("Obj Trace :: Finalize\n");

	for (auto e1 : *allocIdMap)
	{
		DEBUG("Alloc ID : %lu \t Candidate : \n", e1.first);
		for (auto e2 : e1.second)
		{
			DEBUG("addr : %zx size : %d\n", e2.first, e2.second);
		}
	}
/*
	DEBUG("\n @@@ NOW Store Instruction Data @@@ \n");

	for (auto e3 : *storeIdMap)
	{
		//can select what we want to look
		DEBUG("Instr ID : %lu \t Candidate : \n", e3.first);
		for (auto e4 : e3.second)
		{
			DEBUG("addr : %zx \t ObjID : %lu\n", e4.first, e4.second);
		}
	}
*/
}

extern "C"
void objTraceLoadInstr (void* addr, FullID fullId) {

	if(/* 0x0000000040000000 < (uint64_t)addr &&*/ (uint64_t)addr < 0x0000400000000000 )//TODO :: how to handle data seg access && where is the exact start address of heap space. 
	{
		//DEBUG("access %zx\n", (uint64_t)addr);
		uint64_t flipAddr = GET_SHADOW_ADDR_MALLOC_MAP(addr);
		//DEBUG("get flip ADDR %zx\n", (uint64_t)flipAddr);
		FullID fullAllocId = *( (uint64_t *)(flipAddr) );
		//DEBUG(" here?? %lu\n", fullAllocId);
		AllocMap::iterator allocIt = allocIdMap->find(fullAllocId);
	
/*
		if ( allocIt == allocIdMap->end() ){
			//DEBUG(" FAIL!!! :: Access addr : %zx \t AllocID : %lu \n", (uint64_t)addr, fullAllocId);
			//assert( 0 && "LOAD::ALLOC ID FIND FAIL");
		}
*/
		if ( allocIt != allocIdMap->end() )
		{
			LoadStoreMap::iterator it = loadIdMap->find(fullId);
			if( it == loadIdMap->end() ) 
			{
				LoadStoreInfo loadSet;
				loadSet.insert( std::pair<const uint64_t, FullID> ((uint64_t)addr, fullAllocId) );
				loadIdMap->insert( std::pair<FullID, LoadStoreInfo> ( fullId, loadSet ) );
			}
			else
			{
				(it->second).insert( std::pair<const uint64_t, FullID> ((uint64_t)addr, fullAllocId) );
			}
		}
	}
	
}

extern "C"
void objTraceStoreInstr (void* addr, FullID fullId) {

	if(/*(uint64_t)addr > 0x0000000040000000 &&*/ (uint64_t)addr < 0x0000400000000000 )//TODO :: how to handle data seg access
	{
		uint64_t flipAddr = GET_SHADOW_ADDR_MALLOC_MAP(addr);
		FullID fullAllocId = *( (uint64_t *)(flipAddr) );
		AllocMap::iterator allocIt = allocIdMap->find(fullAllocId);
/*
		if ( allocIt == allocIdMap->end() )
		{
			DEBUG(" FAIL!!! :: Access addr : %zx \n", (uint64_t)addr);
			assert( 0 && "STORE::ALLOC ID FIND FAIL" );
		}
*/
		if ( allocIt != allocIdMap->end() )
		{
			LoadStoreMap::iterator it = storeIdMap->find(fullId);
			if( it == storeIdMap->end() ) 
			{
				LoadStoreInfo storeSet;
				storeSet.insert( std::pair<const uint64_t, FullID> ((uint64_t)addr, fullAllocId) );
				storeIdMap->insert( std::pair<FullID, LoadStoreInfo> ( fullId, storeSet ) );
			}
			else
			{
				(it->second).insert( std::pair<const uint64_t, FullID> ((uint64_t)addr, fullAllocId) );
			}
		}
	}

}

extern "C" void*
objTraceMalloc (size_t size, FullID fullId){

	void *addr = malloc (size);
	const uint64_t addr_ = (uint64_t)addr;

	AllocMap::iterator it = allocIdMap->find(fullId);
	if( it == allocIdMap->end() ) // first alloc by this instruction
	{
		AllocInfo allocSet;
		allocSet.insert( std::pair<const uint64_t, size_t> (addr_, size) );
		allocIdMap->insert( std::pair<FullID, AllocInfo> ( fullId, allocSet ) );
	}
	else
	{
		//DEBUG("twice alloc by same ID (%lu)\n", fullId);
		(it->second).insert( std::pair<uint64_t, size_t> (addr_, size) );
	}
	
	shadowMemorySetting ( addr, size, fullId );

	return addr;
}

extern "C" void*
objTraceCalloc (size_t num, size_t size, FullID fullId){
  void* addr = calloc (num, size);
	const uint64_t addr_ = (uint64_t)addr;

	AllocMap::iterator it = allocIdMap->find(fullId);
	if( it == allocIdMap->end() )
	{
		AllocInfo allocSet;
		allocSet.insert( std::pair<const uint64_t, size_t> (addr_, (size*num)) );
		allocIdMap->insert( std::pair<FullID, AllocInfo> (fullId, allocSet) );
	}
	else
	{
		//DEBUG("twice alloc by same ID (%lu)\n", fullId);
		(it->second).insert( std::pair<uint64_t, size_t> (addr_, (size*num)) );
	}

	shadowMemorySetting ( addr, (size*num), fullId );

  return addr;
}

extern "C" void*
objTraceRealloc (void* addr, size_t size, FullID fullId){
  void* naddr = NULL;
  naddr = realloc (addr, size);
	const uint64_t addr_ = (uint64_t)naddr;

	AllocMap::iterator it = allocIdMap->find(fullId);
	if( it == allocIdMap->end() )
	{
		AllocInfo allocSet;
		allocSet.insert( std::pair<const uint64_t, size_t> (addr_, size) );
		allocIdMap->insert( std::pair<FullID, AllocInfo> (fullId, allocSet) );
	}
	else
	{
		//DEBUG("twice alloc by same ID (%lu)\n", fullId);
		(it->second).insert( std::pair<uint64_t, size_t> (addr_, size) );
	}

	shadowMemorySetting ( naddr, size, fullId );

  return naddr;
}

extern "C" void
objTraceFree (void* addr, FullID fullId){
  free (addr);
}
