#ifndef __BGL_GRAPH_UTIL_H
#define __BGL_GRAPH_UTIL_H

#include <boost/config.hpp>
#include <boost/graph/strong_components.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/property_map/property_map.hpp>
#include <boost/graph/graph_utility.hpp>
#include <boost/graph/copy.hpp>
#include <boost/graph/topological_sort.hpp>
#include <boost/graph/breadth_first_search.hpp>

#include <algorithm>
#include <iostream>
#include <iterator>
#include <map>

using namespace boost;

namespace corelab {
	// *** merge_vertex ***
	// can deal with only type of Graph (as long as it support BGL)
	// incoming/outgoing edges for v become incoming/outgoing edges for u
	// v is deleted
	template <class Graph>
	void bgl_merge_vertex(typename boost::graph_traits<Graph>::vertex_descriptor u,
	            typename boost::graph_traits<Graph>::vertex_descriptor v, 
	            Graph& g){
		BOOST_CONCEPT_ASSERT(( BidirectionalGraphConcept< Graph> ));
		BOOST_CONCEPT_ASSERT(( MutableGraphConcept< Graph > ));

		typedef boost::graph_traits<Graph> Traits;
		typedef typename Graph::edge_property_type EdgeProp;
		typename Traits::edge_descriptor e;
		typename Traits::out_edge_iterator out_i, out_end;
		for (boost::tie(out_i, out_end) = out_edges(v, g); out_i != out_end; ++out_i) {
			e = *out_i;
			typename Traits::vertex_descriptor targ = target(e, g);
			add_edge(u, targ, EdgeProp(boost::get(&EdgeProp::id, g, e)), g);
		}

		typename Traits::in_edge_iterator in_i, in_end;
		for (boost::tie(in_i, in_end) = in_edges(v, g); in_i != in_end; ++in_i) {
			e = *in_i;
			typename Traits::vertex_descriptor src = source(e, g);
			add_edge(src, u, EdgeProp(boost::get(&EdgeProp::id, g, e)), g);
		}

		clear_vertex(v, g);
		remove_vertex(v, g);
	}

	// struct found_target {}; //TODO:: exception for early termination ==> VertexChaserBFS
	template <typename VertexIDMap, typename VID>
	class VertexChaserBFS : public default_bfs_visitor {
		public: 
			//Usage:: provide VidMap, target VertexID, a boolean variable having false value.
			VertexChaserBFS(VertexIDMap vidMap_, VID goal, bool &f) : vidMap(vidMap_), target(goal), found(f) {}
			template <typename Vertex, typename Graph>
			void discover_vertex(Vertex u, const Graph &g){
				// errs()<<" ==> "<<vidMap[u]<<" ,"<<(vidMap[u]==target?"FOUND":"LOST")<<"\n";
				//TODO::exception for early termination
				if(((VID)(vidMap[u]))==target){
					// throw found_target();
					found=true;
				}
			}
			bool isFound(){return found;}

		private:
			VertexIDMap vidMap;
			VID target;
			bool& found;
	};

	template <class Graph, typename VID>
	bool bgl_isReachable(VID src, VID dst, Graph& g){
		typedef typename graph_traits<Graph>::vertex_descriptor VertexType;
		typedef typename Graph::vertex_property_type VertexProp;
		typedef typename graph_traits<Graph>::vertex_iterator VertexIter;
		typedef typename property_map<Graph, typename VertexProp::value_type VertexProp::*>::type VertexIDMap;
		VertexIDMap vidMap = get(&VertexProp::id, g);

		//TODO:: Check if we don't need to make Regular Vertex ID Map. (when vidMap is already regular.)
		// Make (External) Regular Vertex ID Map
		typedef typename std::map<VertexType, VID> RegularVertexIDMapImpl;
		typedef associative_property_map< RegularVertexIDMapImpl > RegularVertexIDMap;
		RegularVertexIDMapImpl rVidMapImpl;
		RegularVertexIDMap rVidMap(rVidMapImpl);
		VID vid = 0;
		VID rVidSrc;
		VertexIter vi, vi_end;
		for (boost::tie(vi, vi_end) = vertices(g); vi != vi_end; vi++){
			rVidMap[*vi] = vid;
			if(((VID)(vidMap[*vi])) == src)
				rVidSrc = vid;
			vid++;
		}

		bool f = false;
		VertexChaserBFS<VertexIDMap, VID> vis(vidMap, dst, f);
		breadth_first_search(g, vertex(rVidSrc, g), vertex_index_map(rVidMap).visitor(vis));

		return vis.isFound();
	}

	namespace SCC{
		template <class Graph, typename SCCMap>
		int getVertexToSCCIDMap(Graph &g, SCCMap &sccMap){
			typedef typename Graph::vertex_property_type VertexProp;
			typedef typename property_map<Graph, typename VertexProp::value_type VertexProp::*>::type VertexIDMap;
			VertexIDMap vidMap = get(&VertexProp::id, g);

			BOOST_CONCEPT_ASSERT(( ReadWritePropertyMapConcept<SCCMap, typename graph_traits<Graph>::vertex_descriptor> ));

			int nSCC = strong_components(g, sccMap, vertex_index_map(vidMap));
			return nSCC;
		}

		// offset of SCCIDVector is vid
		// (type) graph_traits<Graph>::vertices_size_type == SCCID
		template <class Graph>
		int getSCCIDVector(Graph &g, std::vector< typename graph_traits<Graph>::vertices_size_type > &sccIDVec){
			// typedef typename graph_traits<Graph>::vertices_size_type SCCID;

			typedef typename Graph::vertex_property_type VertexProp;
			typedef typename property_map<Graph, typename VertexProp::value_type VertexProp::*>::type VertexIDMap;
			VertexIDMap vidMap = get(&VertexProp::id, g);

			assert(sccIDVec.size() == num_vertices(g) && "ERROR: sccIDVec size mismatch!");

			typedef typename std::vector< graph_traits<ICFG::Graph>::vertices_size_type > MapImplType;
			typedef typename boost::iterator_property_map <MapImplType::iterator, VertexIDMap> SCCMap;
			SCCMap sccMap(sccIDVec.begin(), vidMap);

			int nSCC = getVertexToSCCIDMap<Graph, SCCMap>(g, sccMap);
			return nSCC;
		}
	}//namespace SCC

	template<typename Graph>
	class DAGSCC{
	public:
		typedef typename graph_traits<Graph>::vertices_size_type SCCID;
		typedef typename graph_traits<Graph>::vertex_iterator VertexIter;
		typedef typename graph_traits<Graph>::edge_iterator EdgeIter;
		typedef typename graph_traits<Graph>::vertex_descriptor VertexType;
		typedef typename Graph::vertex_property_type VertexProp;
		typedef typename VertexProp::value_type VID;
		typedef typename property_map<Graph, typename VertexProp::value_type VertexProp::*>::type VertexIDMap;
		typedef typename std::vector<SCCID> SCCMapImplType;
		typedef typename boost::iterator_property_map <typename SCCMapImplType::iterator, VertexIDMap> SCCMap;
		typedef std::vector<VID> TopologicalOrder;

		DAGSCC(const Graph *p) : oriG(p) {
			buildDAG();
			topologicalSort();
		}

		int getNumSCC(){return nSCC;}
		Graph& getDAG(){return dag;}
		TopologicalOrder& getTopologicalOrder(){return topologicalOrder;}

	private:
		const Graph *oriG; //original graph

		Graph dag; //DAG scc Graph
		int nSCC;
		std::vector<SCCID> sccIDVec;
		TopologicalOrder topologicalOrder;

		void buildDAG(){
			// copy ICFG graph
			VertexIDMap vidMapOri = get(&VertexProp::id, *const_cast<Graph *>(oriG));
			copy_graph(*const_cast<Graph *>(oriG), dag, vertex_index_map(vidMapOri));

			sccIDVec.assign(num_vertices(*oriG), 0);
			nSCC = SCC::getSCCIDVector<Graph>(*const_cast<Graph *>(oriG), sccIDVec);

			VertexIDMap vidMap = get(&VertexProp::id, dag);
			SCCMap sccMap(sccIDVec.begin(), vidMap);

			// Do Merge on every SCC.
			for (unsigned long sccID = 0; sccID < (unsigned long)nSCC; ++sccID){
				int numMergeOperationNeed = std::count(sccIDVec.begin(), sccIDVec.end(), SCCID(sccID)) - 1;
				for (int i = 0; i < numMergeOperationNeed; ++i){
					VertexIter vi, vi_end;
					for (boost::tie(vi, vi_end) = vertices(dag); vi != vi_end; vi++) {
						if(sccMap[*vi] == sccID){
							VertexType &v1 = *vi;
							vi++;
							assert(vi != vi_end && "FATAL ERROR(1):: Cannot find second node of a SCC");
							VertexIter vi2;
							for(vi2=vi; vi2 != vi_end ; vi2++){
								if(sccMap[*vi2] == sccID){
									VertexType &v2 = *vi2;
									remove_edge(v1, v2, dag);
									remove_edge(v2, v1, dag);
									bgl_merge_vertex(v1, v2, dag);
									break;
								}
							}
							assert(vi2 != vi_end && "FATAL ERROR(2):: Cannot find second node of a SCC");
							break;
						}
					}
					assert(vi != vi_end && "FATAL ERROR:: Cannot find first node of a SCC");
				} // numMergeOperationNeed Loop End
			}

			// // Remove Self Edges
			// EdgeIter ei, ei_end;
			// boost::tie(ei, ei_end) = edges(dag);
			// while(ei != ei_end){
			// 	VertexType t = target(*ei, dag), s = source(*ei, dag);
			// 	if(t == s){
			// 		remove_edge(*ei, dag);
			// 		boost::tie(ei, ei_end) = edges(dag);
			// 		if(ei == ei_end) break;
			// 	}
			// 	ei++;
			// }
		}

		void topologicalSort(){
			// TODO:: provide this regularVidMap by primitive function. (like copy_graph)
			// Make (External) Regular Vertex ID Map
			VertexIDMap vidMap = get(&VertexProp::id, dag);
			typedef typename std::map<ICFG::VertexType, ICFG::VID> RegularVertexIDMapImpl;
			RegularVertexIDMapImpl rVidMapImpl;
			typedef associative_property_map< RegularVertexIDMapImpl > RegularVertexIDMap;
			RegularVertexIDMap rVidMap(rVidMapImpl);

			std::map<uint32_t, VID> regularVIDToVID;

			VID vid = 0;
			VertexIter vi, vi_end;
			for (boost::tie(vi, vi_end) = vertices(dag); vi != vi_end; vi++){
				rVidMap[*vi] = vid;
				regularVIDToVID[rVidMap[*vi]] = vidMap[*vi];
				vid++;
			}
			
			typedef std::vector< VertexType > TopoSortContainer; // Vertext Container sorted in Reverse Topological order
			TopoSortContainer topoVContainer;
			topological_sort(dag, std::back_inserter(topoVContainer), vertex_index_map(rVidMap)); //std::front_inserter

			for (typename TopoSortContainer::reverse_iterator ii = topoVContainer.rbegin(); ii != topoVContainer.rend(); ++ii)
				topologicalOrder.push_back(regularVIDToVID[rVidMap[*ii]]);
		}

	};
}

#endif //__BGL_GRAPH_UTIL_H