#ifndef LLVM_CORELAB_COMPARE_MODULE
#define LLVM_CORELAB_COMPARE_MODULE

#include "llvm/Pass.h"
#include "typedefs.h"
#include <stdint.h>
#include <map>
#include <vector>
#include <set>
#include <list>
#include "store_load_loop.h"

namespace corelab
{ 
	using namespace llvm;
	using namespace corelab;

	class Compare: public ModulePass
	{
		private:
			Module *pM;

			std::map<std::string, int> fcnInstsMap;
			std::list<deps_elem *> old_res;
			std::list<instr_metadata*> metadata; // present metadata
			bool analysisOldProfilingResult();
			bool analysisMetadataInfo();
		public:
			static char ID;
			Compare();
			~Compare();
	
			std::map<std::string, int> fcnMap;
			std::set<int> fcnSet;
			std::map<int, int> oldToNewFnId; // map new fcnId -> old FcnId
			std::set< std::pair<int,int> > impacted;	// impacted new fcnId
			std::map<int, int> same; // new fcnId -> old fcnId
			std::map<int, int> modified; // new fcnId -> old fcnId
			std::set< std::pair<int,int> > modified_bb; // <new fcnId, bbId>
			std::vector<int> added; // added new fcnId
			std::vector<int> deleted; // deleted old fcnId
			std::map<int, int> bbnum_in_func; // new fcnId -> number of basic block
			std::multimap<int, int> funcCallChain;
			std::list<deps_elem*> prev_profiling; // previous profiling result which may used in next profiling version.
			const char *getPassName() const { return "CompareModule"; }

			void *getAdjustedAnalysisPointer(AnalysisID PI) {
				return this;
			}

			void getAnalysisUsage(AnalysisUsage &AU) const;

			bool runOnModule(Module &M);
			bool runOnEditedFunction(Function &F, int fcnCnt);
			bool checkBBNum(Function &F, int fcnCnt);
			bool checkFunctionCall(Function &F, int fcnCnt);
	};

}
#endif

