#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Constants.h"

namespace corelab 
{
	using namespace llvm;
	class LoopCount : public ModulePass
	{
		public:
		bool runOnModule(Module& M);
		void getAnalysisUsage(AnalysisUsage &AU) const;
		const char *getPassName() const { return "LoopCount"; }
		
		static char ID;
		LoopCount() : ModulePass(ID) {}

		private:
		Constant *beginLoop;
		Constant *endLoop;
		Constant *beginIteration;

		void runOnLoop(Loop *L, int loopID);
		void makeCreator(Module *m, int loopNum);
		void makeDestructor(Module *m);
	};

}

