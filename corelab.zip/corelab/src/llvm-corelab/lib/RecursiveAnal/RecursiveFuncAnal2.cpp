#include "corelab/RecursiveAnal/RecursiveFuncAnal2.hpp"
#include "llvm/IR/InstIterator.h"

using namespace llvm;
using namespace corelab;

char RecursiveFuncAnal2::ID = 0;
static RegisterPass<RecursiveFuncAnal2> X("recursive-func-anal2", "Find all recursive functions by using ICFG", false, false);

bool RecursiveFuncAnal2::runOnModule(Module &M) {
	errs() << "\nSTART [RecursiveFuncAnal::runOnModule] 	#######\n";

	module = &M;	
	icfgBuilder = &getAnalysis<ICFGBuilder>();
	MBBB = &getAnalysis<MicroBasicBlockBuilder>();
	IndirectCallAnal &indCallAnal = getAnalysis<IndirectCallAnal>();
	indCallAnal.getTypeBasedMatching(possibleTargetOf);

	assert( (recFuncList.empty() && recFuncsAndCallsList.empty()) && "runOnModule must be called twice");

	recFuncList.clear();
	recFuncsAndCallsList.clear();

	findAllRecursiveFunc();

	// printResult();

	errs() << "\nEND [RecursiveFuncAnal::runOnModule] 	#######\n";

	return false;
}


std::vector<std::pair<const Instruction*, const Function*>> findCalledFunctions(std::vector<std::pair<Instruction*, std::pair<const Function*, const Function*>>> CallPairList, const Function* fp)
{
	std::vector<std::pair<const Instruction*, const Function*>> Funcs;
	Funcs.clear();

	for(auto fpi = CallPairList.begin(), fpe = CallPairList.end(); fpi != fpe; ++fpi)
		if((*fpi).second.first == fp)
			Funcs.push_back(std::make_pair((*fpi).first, (*fpi).second.second));

	return Funcs;
}


void RecursiveFuncAnal2::traverseNextCallFunc(const Function* fp, std::vector<std::pair<Instruction*, std::pair<const Function*, const Function*>>> CallPairList, std::vector<std::pair<const Instruction*, const Function *>> FuncStack) {
	if(std::any_of(FuncStack.begin(), FuncStack.end(), [fp](std::pair<const Instruction*, const Function*> f) {
		return f.second == fp; }))
	{
		std::vector<std::pair<const Instruction *, const Function*>>::iterator fi2 = FuncStack.begin();
		std::vector<std::pair<const Instruction *, const Function*>> recFuncs;
		recFuncs.clear();

		while((*fi2).second != fp)
			++fi2;

		while(fi2 != FuncStack.end())
		{
			recFuncs.push_back(*fi2);
			++fi2;
		}

		std::unordered_set<const Function*> Funs;
		std::unordered_set<const Instruction*> Insts;
		Funs.clear();
		Insts.clear();
		for(auto ip = recFuncs.begin(), ipe = recFuncs.end(); ip!=ipe; ++ip)
		{
			Insts.insert((*ip).first);
			Funs.insert((*ip).second);
		}

		std::vector<std::pair<std::unordered_set<const Instruction*>, std::unordered_set<const Function *>>>::iterator rFACi = 
			std::find_if(recFuncsAndCallsList.begin(), recFuncsAndCallsList.end(), [Funs] (std::pair<std::unordered_set<const Instruction *>, std::unordered_set<const Function*>> funcpair) {return funcpair.second == Funs;});

		if(rFACi != recFuncsAndCallsList.end())
		{
			for(auto ii = Insts.begin(), ei = Insts.end(); ii != ei; ii++)
				(*rFACi).first.insert(*ii);
		} 
		else
			recFuncsAndCallsList.push_back(std::make_pair(Insts, Funs));

	}
	else{
		std::vector<std::pair<const Instruction*, const Function*>> next_calls = findCalledFunctions(CallPairList, fp);
		for(std::vector<std::pair<const Instruction *, const Function*>>::iterator fi = next_calls.begin(), fe = next_calls.end(); fi != fe; ++fi){
			FuncStack.push_back(std::make_pair((*fi).first, fp));
			traverseNextCallFunc((*fi).second, CallPairList, FuncStack);
			FuncStack.pop_back();
		}
	}
}


void RecursiveFuncAnal2::findAllRecursiveFunc() {
	std::vector<Instruction*> CallInsts;
	std::vector<std::pair<Instruction*, std::pair<const Function*, const Function*>>> CallPairList;
	std::vector<std::pair<const Instruction *, const Function *>> FuncStack;

	CallInsts.clear();
	CallPairList.clear();
	FuncStack.clear();

	Module& M = *module;			

	for(Module::iterator fi = M.begin(), fe = M.end(); fi != fe; ++fi) {
		Function &F = *fi;
		if (F.isDeclaration()) continue;
		for(Function::iterator bbi=F.begin(), be=F.end(); bbi!=be; ++bbi){
			BasicBlock &BB = *bbi;
			for(BasicBlock::iterator ii=BB.begin(), ie=BB.end(); ii!=ie; ++ii){
				if(CallInst* CI = dyn_cast<CallInst> (&*ii))
					CallInsts.push_back(CI);
			}
		}
	}	
	
	//find all MBB of CallInst and called MBB
	for(std::vector< Instruction *>::iterator ii = CallInsts.begin(), ie = CallInsts.end(); ii != ie; ++ii)
	{
		Function* F = nullptr;
		if(CallInst *call = dyn_cast<CallInst>(*ii)){
			F = call->getCalledFunction();
			if(F == nullptr){
				if(possibleTargetOf[call].size() == 0)
					errs()<< "WARNING : No target callee exist ! "<<*call<<"\n";

				for(Function *oneOfCallee : possibleTargetOf[call]){ //type std::vector<Function *>
					if(oneOfCallee->isDeclaration()) continue;
					MicroBasicBlock* CallMBB = findMBBofInst(*ii);
					assert((CallMBB != NULL) && "CallMBB must not null");

					CallPairList.push_back(std::make_pair(*ii, std::make_pair(CallMBB->getParent()->getParent(), oneOfCallee)));
				}
			}
			else{
				if(F->isDeclaration()) continue;
				MicroBasicBlock* CallMBB = findMBBofInst(*ii);
				assert((CallMBB != NULL) && "CallMBB must not null");
				ICFGNode::iterator CalledMBBNode = (*icfgBuilder)[CallMBB]->succ_begin();
				MicroBasicBlock* CalledMBB = (*CalledMBBNode)->getMBB();
				assert(((*icfgBuilder)[CallMBB]->size() == 1) && "CalledMBB node must be only 1");	

				CallPairList.push_back(std::make_pair(*ii, std::make_pair(CallMBB->getParent()->getParent(), CalledMBB->getParent()->getParent())));
			}
		} else { assert (0 && "FATAL ERROR "); }
	}

	std::vector<const Function *> firstFunc;
	firstFunc.clear();

	//To finding loop(recursive), collect first function to iterate
	for(auto fpi = CallPairList.begin(), fpe = CallPairList.end(); fpi != fpe; ++fpi){
		if(std::any_of(firstFunc.begin(), firstFunc.end(), [fpi](const Function *f) {
			return f == (*fpi).second.first; }))
		continue;
		firstFunc.push_back((*fpi).second.first);
	}

	for(auto fi = firstFunc.begin(), fe = firstFunc.end(); fi != fe; ++fi)
		traverseNextCallFunc(*fi, CallPairList, FuncStack);
}


MicroBasicBlock* RecursiveFuncAnal2::findMBBofInst(const Instruction* i)
{
	for(ICFG::iterator ni = icfgBuilder->begin(), ne = icfgBuilder -> end(); ni != ne; ++ni){
		MicroBasicBlock* MBB = ni -> getMBB();
		for(MicroBasicBlock::iterator ii = MBB->begin(), ie = MBB->end(); ii != ie; ++ii) {
			if(i == &*ii)
				return ni->getMBB();
		}
	}
	return NULL;
}


void RecursiveFuncAnal2::printResult(){
	errs() << "###[All recursive funcs (size: "<< recFuncsAndCallsList.size()<<")]###\n";
	for(auto fi = recFuncsAndCallsList.begin(), fe = recFuncsAndCallsList.end(); fi != fe; ++fi)
	{
		errs() << "[  ";
		std::for_each((*fi).second.begin(), (*fi).second.end(), [](const Function *f) {errs() << f->getName() <<"\t";});
		errs() <<"]\n";
		errs() <<"==================================\n";
		std::for_each((*fi).first.begin(), (*fi).first.end(), [](const Instruction *I) {errs() << (*I) <<"\n";});
		errs() <<"==================================\n\n";
	}
}