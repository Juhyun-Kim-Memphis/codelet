#ifndef LLVM_CORELAB_RECURSIVE_FUNC_ANAL2_H
#define LLVM_CORELAB_RECURSIVE_FUNC_ANAL2_H

//#include "corelab/ICFG/ICFG.hpp"
#include "llvm/IR/Module.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Function.h"
#include "corelab/ICFG/ICFGBuilder.hpp"
#include "corelab/ICFG/MicroBasicBlock.hpp"
#include "corelab/AliasAnalysis/IndirectCallAnal.hpp"
#include <unordered_set>

namespace corelab{
	using namespace llvm;

	class RecursiveFuncAnal2 : public ModulePass {
	public:
		RecursiveFuncAnal2() : ModulePass(ID) {}
		bool runOnModule(Module &M)  override;

		void getAnalysisUsage(AnalysisUsage &AU) const override {
			AU.addRequired< MicroBasicBlockBuilder >();
			AU.addRequired< ICFGBuilder >();
			AU.addRequired< IndirectCallAnal >();
			AU.setPreservesAll();                         // Does not transform code
		}
		static char ID;
		Module* module;
		ICFG* icfgBuilder;
		MicroBasicBlockBuilder *MBBB;

		const char *getPassName() const override { return "Recursive Function Analysis2"; }

		typedef std::vector<std::vector<const Function *>> RecursiveFuncList;
  		typedef std::vector<std::pair<std::unordered_set<const Instruction *>, std::unordered_set<const Function *>>> RecursiveFuncAndCallList; //If using std::unordered_set, there is an error in iterator...

  		typedef RecursiveFuncList::iterator iterator;
		typedef RecursiveFuncList::const_iterator const_iterator;
		
		typedef RecursiveFuncAndCallList::iterator rec_iterator;
		typedef RecursiveFuncAndCallList::const_iterator const_rec_iterator;


		void findAllRecursiveFunc();
		void traverseNextCallFunc(const Function*, std::vector<std::pair<Instruction*, std::pair<const Function*, const Function*>>>, std::vector<std::pair<const Instruction*,const Function *>>);
		MicroBasicBlock* findMBBofInst(const Instruction* i);

		void printResult();

		RecursiveFuncList& getRecFuncList(){return recFuncList;}
		RecursiveFuncAndCallList getRecFuncsAndCallsList(){return recFuncsAndCallsList;}
		
	protected:
		RecursiveFuncList recFuncList;
		RecursiveFuncAndCallList recFuncsAndCallsList;

		IndirectCallAnal::Matching possibleTargetOf;

	
	public:
		iterator                	begin()       	{ return recFuncList.begin(); }
	    const_iterator          	begin() 	const { return recFuncList.begin(); }
	    iterator                	end  ()       	{ return recFuncList.end();   }
	    const_iterator          	end  () 	const { return recFuncList.end();   }      

	/* it doesn't work
	      	rec_iterator 		begin() 	{ return recursiveFuncAndCallList.begin(); }
	      	const_rec_iterator	begin() 	const { return recursiveFuncAndCallList.begin(); }
	      	rec_iterator 		end() 		{ return recursiveFuncAndCallList.end(); }
	      	const_rec_iterator	end() 		const { return recursiveFuncAndCallList.end(); }
	*/
	};
}

#endif  // LLVM_CORELAB_RECURSIVE_FUNC_ANAL2_H
