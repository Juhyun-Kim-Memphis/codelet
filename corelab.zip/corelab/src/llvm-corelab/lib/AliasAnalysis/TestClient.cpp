#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/Support/Compiler.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Support/Debug.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/ADT/SCCIterator.h"
#include "llvm/Analysis/Passes.h"
#include "llvm/IR/DataLayout.h"
#include "llvm/IR/ValueSymbolTable.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/IR/Module.h"
#include "corelab/AliasAnalysis/TestClient.hpp"

#include <list>

using namespace llvm;
using namespace corelab;

char TestAAClient::ID = 0;
static RegisterPass<TestAAClient> X("test-aa-client", "test aa.", false, true);

// StringRef AliasResultToString(corelab::LoopAA::AliasResult ar);
// StringRef AliasResultToString(AliasResult ar);

int stackoverflow(Function *f){
	int b[1024];
	for (int i = 0; i < 1024; i++)
	{
		b[i] = rand()%100;
	}
	int c=f->size();
	for (int i = 0; i < 1024; i++)
	{
		c+=b[i];
	}
	errs()<<f->getName()<<"\n";
	return c + stackoverflow(f);
}

bool TestAAClient::runOnModule(Module& M) {
	errs() << "#######START [TestAAClient::runOnModule]######\n";
	
	unsigned loadCnt=0;
	unsigned loadElemCnt=0;
	unsigned storeCnt=0;
	unsigned callSiteCnt=0;
	unsigned loopCnt=0;
	unsigned funCnt=0;
	unsigned nInst = 0;

	for(Module::iterator fi = M.begin(), fe = M.end(); fi != fe; ++fi) {
		Function &F = *fi;
		if (F.isDeclaration()) continue;
		funCnt++;
		LoopInfo &li = getAnalysis<LoopInfoWrapperPass>(F).getLoopInfo();
		std::list<Loop*> all_loops( li.begin(), li.end() );
		while(!all_loops.empty()){
			Loop *loop = all_loops.front();
			for (Loop *subLoop : loop->getSubLoops())
				all_loops.push_back(subLoop);
			all_loops.pop_front();
			loopCnt++;
		}

		for (inst_iterator I = inst_begin(F), E = inst_end(F); I != E; ++I){
			nInst++;
			Instruction *instruction = &*I;
			if(LoadInst *ld = dyn_cast<LoadInst>(instruction)){
				loadCnt++;
				if(std::all_of(ld->user_begin(), ld->user_end(), [](User *user){return isa<GetElementPtrInst>(user);})){
					loadElemCnt++;
					//errs()<<"["<<*ld<<"]\n";
				}	
			}
			if(isa<StoreInst>(instruction))
				storeCnt++;
			if(isa<CallInst>(instruction)||isa<InvokeInst>(instruction))
				callSiteCnt++;
		}
	}
	// errs() 	<< "## loadCnt:"<<loadCnt<<", storeCnt:"<<storeCnt<<", loadElemCnt:"<<loadElemCnt
	// 	 	<<", callsiteCnt:"<<callSiteCnt<<", loopCnt:"<<loopCnt<<", FunctionCnt: "<<funCnt<<", nInst:"<< nInst <<" #######\n";
	//nFunc	nCallSite	nLoops	nInst	nLoadInst	nStoreInst
	errs()<<funCnt<<"\t"<<callSiteCnt<<"\t"<<loopCnt<<"\t"<<nInst<<"\t"<<loadCnt<<"\t"<<storeCnt<<"\n";

	// LoopTraverse &looptrav = getAnalysis<LoopTraverse>();
	// RecursiveFuncAnal &recFunAnal = getAnalysis<RecursiveFuncAnal>();
	// ICFGBuilder &icfgBuilder = getAnalysis<ICFGBuilder>();
	// ICFG &icfg = static_cast<ICFG&>(icfgBuilder);

	// // looptrav.printMaxLoopDepthOfFunctions();
	// Function *mainFcn = std::find_if(M.begin(), M.end(), [](Module::iterator fi){return (fi->getName() == "main" && !fi->hasLocalLinkage());});
	// //int a = stackoverflow(mainFcn);

	// size_t nRecFun = recFunAnal.size();
	// unsigned maxDepth = looptrav.getMaxLoopDepth();
	// errs()<< "[ MaxDepth: "<< maxDepth <<" ]\n";
	// errs()<< "[ # of Rec Fun:" << nRecFun <<" ]\n";
	// //recFunAnal.printAllRecursiveFunction();

	// icfgBuilder.printStats(errs());
	// icfgBuilder.printGraph(errs());
	//icfgBuilder.getNumConnectedComponents();
	//errs()<<"[ # of SCC:" <<icfgBuilder.getNumSCC()<<" ]\n";
	//icfgBuilder.printAllExternalFunCalls(errs());
	//icfgBuilder.printAllIndirectFunCalls(errs());

	// Use LLVM's Strongly Connected Components (SCCs) iterator to produce
	// a reverse topological sort of SCCs.
	// errs() << "SCCs for ICFG (size: "<< icfg.size() << ") in post-order:\n";
	// for (scc_iterator<ICFG *> I = scc_begin(&icfg),
	//                               IE = scc_end(&icfg);
	//                               I != IE; ++I) {
	//   // Obtain the vector of BBs in this SCC and print it out.
	//   const std::vector<ICFGNode *> &SCCMBBs = *I;
	//   errs() << "  SCC: ";
	//   for (std::vector<ICFGNode *>::const_iterator BBI = SCCMBBs.begin(),
	//                                                  BBIE = SCCMBBs.end();
	//                                                  BBI != BBIE; ++BBI) {
	//   	MicroBasicBlock &mbb = *((*BBI)->getMBB());
	//     errs() <<"[ "<< mbb.getParent()->getParent()->getName() << "::" << mbb.getParent()->getName() << "::" << *(mbb.getFirstNonPHI())<<" ],  ";
	//   }
	//   errs() << "\n";
	// }

	errs() << "#######END [TestAAClient::runOnModule]\n";
	return false;
}

// StringRef AliasResultToString(corelab::LoopAA::AliasResult ar){
// 	StringRef res;
// 	if(ar == corelab::LoopAA::NoAlias)
// 		res = "NoAlias";
// 	else if(ar == corelab::LoopAA::MayAlias)
// 		res = "MayAlias";
// 	//else if(ar == PartialAlias)
// 	//	res = "PartialAlias";
// 	else if(ar == corelab::LoopAA::MustAlias)
// 		res = "MustAlias";
// 	return res;
// }


// StringRef AliasResultToString(AliasResult ar){
// 	StringRef res;
// 	if(ar == NoAlias)
// 		res = "NoAlias";
// 	else if(ar == MayAlias)
// 		res = "MayAlias";
// 	else if(ar == PartialAlias)
// 		res = "PartialAlias";
// 	else if(ar == MustAlias)
// 		res = "MustAlias";
// 	return res;
// }





	//ValueSymbolTable &vst = M.getValueSymbolTable();
	// std::vector<BasicBlock * > allBasicBlock;
	// AliasAnalysis &llvmAA = getAnalysis<AliasAnalysis>();
	// AliasAnalysisWrapper &AAInterface = getAnalysis<AliasAnalysisWrapper>();
	// LoopAA *loopAA= getAnalysis< LoopAA >().getTopAA();
	// const DataLayout &dl = M.getDataLayout();

	// std::for_each(M.global_begin(), M.global_end(), 
	// 		[this](Module::global_iterator gi){if((gi)->getType()->isPointerTy()) ptrInModule.push_back(gi);});
	
	// Function *mainFcn = std::find_if(M.begin(), M.begin(), [](Module::iterator fi){return ( fi->getName() == "main" && fi->arg_size() == 2 );});
	// LoopInfo &li = getAnalysis<LoopInfoWrapperPass>(*mainFcn).getLoopInfo();
	// std::vector<Loop*> all_loops( li.begin(), li.end() );
	
	// //Constant *valueStr = ConstantArray::get(ArrayType::get(i8PtrType, s.size()), svec);
 //    //GlobalVariable *GV = new GlobalVariable(M, valueStr->getType(), true, 
 //    //GlobalValue::InternalLinkage, valueStr, "", 0, false);

	// //Every Instruction 
	// for(Module::iterator fi = M.begin(), fe = M.end(); fi != fe; ++fi) {
	// 	Function &F = *fi;
	// 	if (F.isDeclaration()) continue;

	// 	for(Function::iterator bbi=F.begin(), be=F.end(); bbi!=be; ++bbi)
	// 		allBasicBlock.push_back(bbi);	

	// 	for (inst_iterator ii = inst_begin(F), E = inst_end(F); ii != E; ++ii){
	// 		Instruction &I = *ii;
	// 		//errs()<<" [ "<<I<<" ] is "<< (I.getType()->isPointerTy() ? "PointerType" : "NOT Pointer") << "\n";
	// 		if(I.getType()->isPointerTy())
	// 			ptrInModule.push_back(&I);
	// 		if(CallInst *call = dyn_cast<CallInst>(&I)){
	// 			std::for_each(call->arg_operands().begin(), call->arg_operands().end(), 
	// 				[this](Value *arg){if(arg->getType()->isPointerTy()) ptrInModule.push_back(arg);});
	// 		}
	// 	}
	// }

	// std::for_each(allBasicBlock.begin(), allBasicBlock.end(), [](BasicBlock *bb){errs()<<bb->getName()<<" :{{ "<<*(bb->getTerminator())<<" }}\n";});

	// //loopAA->dump();
	// errs()<<"All PointerType Values in Module (total: "<< ptrInModule.size() <<") =====================\n";
	// std::for_each(ptrInModule.begin(), ptrInModule.end(), [](Value *p){errs()<<"{{ "<<*p<<" }}\n";});
	// errs()<<"======================================================\n";

	// //all possible pairs of PointerType Value
	// for (auto i = ptrInModule.begin(); i != ptrInModule.end(); ++i) {
	//   for (auto j = i; ++j != ptrInModule.end(); ) {
	//   	//if((**i).getName() == "p" && (**j).getName() == "q")
	//   	if(const LoadInst *ldInst_i = dyn_cast<LoadInst>(*i)){
	// 	  	if(const LoadInst *ldInst_j = dyn_cast<LoadInst>(*j)){
	// 			AliasResult ar = llvmAA.alias(MemoryLocation::get(ldInst_i), MemoryLocation::get(ldInst_j));
	// 			//errs() <<"( "<< (**i).getName() <<" , "<< (**j).getName() << " ) "<< AliasResultToString(ar) <<"\n";
	// 			errs() <<"( "<< **i <<" , "<< **j << " ) ===>"<< AliasResultToString(ar) <<"\n";
	// 	  	}
	// 	}
		
	// 	//errs() <<"( "<< **i <<" , "<< **j << " ) "<< AliasResultToString(ar) <<"\n";

	// 	//==================== Flow-sensitive query
		
	// 	//auto bbi = allBasicBlock.rbegin();
	// 	//for(auto bbi = allBasicBlock.begin(); bbi != allBasicBlock.end(); bbi++){
	// 		//Instruction *terminatorInst = (*bbi)->getTerminator();
	// 		//FlowSensitiveCxt fsc(M, *terminatorInst);	
	// 		//LoopAwareCxt lac(M, *terminatorInst, **(all_loops.begin()));	
	// 		//AliasInfo fsar = AAInterface.alias(*i, *j, fsc);
	// 		//errs() <<"Flow-sensitive(at "<<(*bbi)->getName()<<")=( "<< **i <<" , "<< **j << " ) "<< AliasResultToString(fsar.ar) <<"\n";
	// 	//};
		
	  	
	//   }
	// }
















// 12/01
// bool TestAAClient::runOnModule(Module& M) {
// 	errs() << "\nSTART [TestAAClient::runOnModule] 	#######\n";

// 	ICFGBuilder &icfgBuilder = getAnalysis<ICFGBuilder>();
// 	ICFG &icfg = static_cast<ICFG&>(icfgBuilder);
// 	//icfgBuilder.printStats(errs());
// 	//icfgBuilder.printGraph(errs());
// 	//icfgBuilder.printAllExternalFunCalls(errs());

// 	// Use LLVM's Strongly Connected Components (SCCs) iterator to produce
// 	// a reverse topological sort of SCCs.
// 	errs() << "SCCs for ICFG (size: "<< icfg.size() << ") in post-order:\n";
// 	for (scc_iterator<ICFG *> I = scc_begin(&icfg),
// 	                              IE = scc_end(&icfg);
// 	                              I != IE; ++I) {
// 	  // Obtain the vector of BBs in this SCC and print it out.
// 	  const std::vector<ICFGNode *> &SCCMBBs = *I;
// 	  errs() << "  SCC: ";
// 	  for (std::vector<ICFGNode *>::const_iterator BBI = SCCMBBs.begin(),
// 	                                                 BBIE = SCCMBBs.end();
// 	                                                 BBI != BBIE; ++BBI) {
// 	  	MicroBasicBlock &mbb = *((*BBI)->getMBB());
// 	    errs() <<"[ "<< mbb.getParent()->getParent()->getName() << "::" << mbb.getParent()->getName() << "::" << *(mbb.getFirstNonPHI())<<" ],  ";
// 	  }
// 	  errs() << "\n";
// 	}
	
		
	

// 	 errs() << "#######\nEND [TestAAClient::runOnModule]\n\n";
// 	return false;
// }