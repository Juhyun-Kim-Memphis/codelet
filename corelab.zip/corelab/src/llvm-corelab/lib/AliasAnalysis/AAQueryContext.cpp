// #include "llvm/Analysis/AliasAnalysis.h"
// #include "corelab/AliasAnalysis/AAQueryContext.hpp"
// #ifndef DEBUG_TYPE
//   #define DEBUG_TYPE "aa-query-context"
// #endif


// using namespace llvm;
// using namespace corelab;

// AliasInfo FlowSensitiveCxt::aliasStrategy(const MemoryLocation &LocA, const MemoryLocation &LocB, AliasAnalysisWrapper &AAWraper){
// 	AliasAnalysis *AA = AAWraper.getAA();
// 	assert(AA && "ERROR: FlowSensitiveCxt::aliasStrategy: AA is NULL.");
// 	AliasResult ar = AA->alias(LocA, LocB);
// 	return AliasInfo(ar);
// }

// AliasInfo LoopAwareCxt::aliasStrategy(const MemoryLocation &LocA, const MemoryLocation &LocB, AliasAnalysisWrapper &AAWraper){
// 	LoopAA *loopAA = AAWraper.getLoopAA();
// 	const DataLayout &dl = module.getDataLayout();
// 	unsigned LocASize, LocBSize;
// 	assert(loopAA && "ERROR: LoopAwareCxt::aliasStrategy: loopAA is NULL.");

// 	if(LocA.Size == MemoryLocation::UnknownSize){
// 		if(PointerType *ptyA = dyn_cast<PointerType>(LocA.Ptr->getType()))
// 			LocASize = dl.getTypeStoreSize( ptyA->getElementType() );
// 		else
// 			UNIMPLEMENTED("ERROR: LocA is not Pointer Type");
// 	}else {
// 		LocASize = (unsigned)LocA.Size;
// 	}
// 	if(LocB.Size == MemoryLocation::UnknownSize){
// 		if(PointerType *ptyB = dyn_cast<PointerType>(LocB.Ptr->getType()))
// 			LocBSize = dl.getTypeStoreSize( ptyB->getElementType() );
// 		else
// 			UNIMPLEMENTED("ERROR: LocB is not Pointer Type");
// 	}else {
// 		LocBSize = (unsigned)LocB.Size;
// 	}

// 	loopAA->dump();

// 	LoopAA::AliasResult ar = loopAA->alias(LocA.Ptr, LocASize, LoopAA::Same, LocB.Ptr, LocBSize, &loop);
// 	return AliasInfo(LoopAA::convert(ar));
// }

// void AliasAnalysisWrapper::getAnalysisUsage(AnalysisUsage &AU) const {
//     //AliasAnalysis::getAnalysisUsage(AU);
//     AU.addRequired<LoopInfoWrapperPass>();
//     AU.addRequired< AliasAnalysis >();
//     AU.addRequired< LoopAA >();
//     AU.setPreservesAll();
// }

// bool AliasAnalysisWrapper::runOnModule(Module& M){
// 	AA = &getAnalysis<AliasAnalysis>();
// 	loopAA = getAnalysis<LoopAA>().getTopAA();
// 	return false;
// }

// char AliasAnalysisWrapper::ID = 0;
// static RegisterPass<AliasAnalysisWrapper> X("aa-wrapper", "AliasAnalysisWrapper", false, false);