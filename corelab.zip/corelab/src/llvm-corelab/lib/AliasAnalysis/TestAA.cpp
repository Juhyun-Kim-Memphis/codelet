// #include "llvm/Analysis/AliasAnalysis.h"
// #include "corelab/AliasAnalysis/TestAA.hpp"
// #ifndef DEBUG_TYPE
//   #define DEBUG_TYPE "test-aa"
// #endif

// using namespace llvm;
// using namespace corelab;

// char TestAA::ID = 0;

// bool TestAA::runOnModule(Module &M) {
// 	InitializeLoopAA(this);
// 	return false;
// }

// corelab::LoopAA::AliasResult TestAA::aliasCheck(const Pointer &P1, TemporalRelation Rel, const Pointer &P2, const Loop *L) {
//   return MayAlias;
// }

// static RegisterPass<TestAA> X("test-aa", "a test version of LoopAA (inherit from ClassicLoopAA)", false, true);
// //static RegisterAnalysisGroup<corelab::LoopAA> Y(X);
