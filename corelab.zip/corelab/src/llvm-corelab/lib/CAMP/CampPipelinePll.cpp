#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/CallSite.h"

#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/IR/Instructions.h"
#include "llvm/Support/Compiler.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Support/Debug.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/IR/CFG.h"
#include "llvm/IR/IRBuilder.h"

#include "llvm/Analysis/CallGraph.h"
#include "llvm/Analysis/LoopInfo.h"
#include "llvm/Analysis/LoopPass.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/Analysis/Passes.h"
#include "llvm/IR/DataLayout.h"
#include "llvm/IR/InstIterator.h"

#include "corelab/Utilities/InstInsertPt.h"
#include "corelab/Utilities/GlobalCtors.h"
#include "corelab/Metadata/Metadata.h"
#include "corelab/Metadata/LoadNamer.h"

#include <iterator>
#include <iostream>
#include <fstream>
#include <assert.h>
#include <stdlib.h>
#include <algorithm>
#include <math.h>

#include "CampPipelinePll.h"

#define MAX_LINE_SIZE 4096
#define DO_NOTHING 0

using namespace std;
using namespace corelab;


char CAMPPipelinePll::ID = 0;
static RegisterPass<CAMPPipelinePll> X("camp-pipeline-pll", "camp-pipeline-pll", false, true);

bool CAMPPipelinePll::runOnModule(Module& M) {
	module = &M;

	errs()<<"############## runOnModule [CAMPPipelinePll] START ##############\n";
	
	cxtTreeBuilder = &getAnalysis< ContextTreeBuilder >();
	pCxtTree = cxtTreeBuilder->getContextTree();
	loopIdOf = cxtTreeBuilder->getLoopIDMap();
	loopOfLoopID = cxtTreeBuilder->getLoopMapOfCntxID();

	init();
	assert(pCxtTree->size() == ucIDMap.size());

	for(std::pair<LoopID, const Loop *> pair : *loopOfLoopID){

		LoopID loopID = pair.first;
		const Loop *loop = pair.second;
		
		const std::vector<Loop*>& subLoops = loop->getSubLoops();
		std::map<InstrID, Value *> instIDtoVal;
		errs()<<" "<<loopID<<", "<<loop->getHeader()->getName().str()<<", subloop#: "<< subLoops.size();// <<"\n";
		
		LoopPDG pdg;
		LoopPDG::Graph &g = pdg.getBGLGraph();
		LoopPDG::VidToValue &vidToVal = pdg.getVidToValue();
		LoopPDG::ValueToVid &valToVid = pdg.getValueToVid();
		LoopPDG::VidToSubLoop &vidToSubLoop = pdg.getVidToSubLoop();
		LoopPDG::SubLoopToVid &subLoopToVID = pdg.getSubLoopToVid();
		LoopPDG::EdgeSet &edgeSet = pdg.getEdgeSet();
		assert(vidToVal.empty() && valToVid.empty() && edgeSet.empty());

		const std::vector<BasicBlock*>& blocks = loop->getBlocks();
		int nCallSite = 0;

		//111111111111111111111111
		//make vertices
		//111111111111111111111111
		LoopPDG::VID vidCnt = 0;

		//subLoops
		for(Loop *sbl: subLoops){
			add_vertex(LoopPDG::VertexProp(vidCnt), g);
			vidToSubLoop[vidCnt] = sbl;
			subLoopToVID[sbl] = vidCnt;
			vidCnt++;
		}

		//instructions in current deps BB
		for(BasicBlock* bbi : blocks){ //loop->blocks()
			if(subLoops.size() != 0){
				if(std::any_of(subLoops.begin(), subLoops.end(), [bbi](Loop *loop){return loop->contains(bbi);}))
					continue;
			}
			assert(isa<BasicBlock>(bbi));
			
			for(BasicBlock::iterator ii=(bbi)->begin(), ie=(bbi)->end(); ii!=ie; ++ii){
				// Instruction *instPtr = &*ii;
				Value *val = &*ii;

				add_vertex(LoopPDG::VertexProp(vidCnt), g);
				vidToVal[vidCnt] = val;
				valToVid[val] = vidCnt;
				vidCnt++;

				//remember InstructionID
				Instruction *instruction = &*ii; 
				if(LoadInst *ld = dyn_cast<LoadInst>(instruction))
					instIDtoVal[Namer::getInstrId(instruction)] = val;
				else if (StoreInst *st = dyn_cast<StoreInst>(instruction)) 
					instIDtoVal[Namer::getInstrId(instruction)] = val;
				

				if(isa<CallInst>(ii) || isa<InvokeInst>(ii)){
					nCallSite++;
				}
			}
		}
		//11111111111111111111111 END

		//22222222222222222222222
		//use def chain (add Edge)
		//22222222222222222222222
		
		for(BasicBlock* bbi : blocks){ //loop->blocks()
			if(subLoops.size() != 0){
				if(std::any_of(subLoops.begin(), subLoops.end(), [bbi](Loop *loop){return loop->contains(bbi);}))
					continue;
			}
			assert(isa<BasicBlock>(bbi));
			
			for(BasicBlock::iterator ii=(bbi)->begin(), ie=(bbi)->end(); ii!=ie; ++ii){
				Instruction *instPtr = &*ii;
				Value *val = &*ii;
				assert(valToVid.find(val) != valToVid.end());
				LoopPDG::VID vid = valToVid[val];

				// for user (dst)
				for(auto ui = instPtr->user_begin(), uiE = instPtr->user_end(); ui != uiE; ++ui){
					LoopPDG::VID vid1 = vid;
					auto found = valToVid.find(*ui);
					if(found != valToVid.end()){ //found in curDepBB
						LoopPDG::VID vid2 = valToVid[*ui];
						edgeSet.insert(std::make_pair(vid1, vid2));
					}
					else{
						if(Instruction *dstInst = dyn_cast<Instruction>(*ui)){
							BasicBlock *bbp = dstInst->getParent();
							//case1: dst is out of Loop
							if(loop->contains(bbp) == false){
								interferingLoopSet.insert(loopID);
							}
							//case2: dst is in subLoop
							else if(std::any_of(subLoops.begin(), subLoops.end(), [bbp](Loop *l){return l->contains(bbp);})){
								for(Loop *subl: subLoops){
									if(subl->contains(bbp)){
										assert(subLoopToVID.find(subl) != subLoopToVID.end());
										LoopPDG::VID vid2 = subLoopToVID[subl];
										edgeSet.insert(std::make_pair(vid1, vid2));
									}
								}
							}
							else assert(0&&"  WTF434 \n");
						}
						else assert(0&&"  WTF134 \n");
					}
					// add_edge(vertex(vid1, g), vertex(vid2, g), DFG::EdgeProp(eidCnt), g);
				}
				// for operands (src)
				for(auto opi = instPtr->op_begin(), opiE = instPtr->op_end(); opi != opiE; ++opi){
					Value *operand = *opi;
					LoopPDG::VID vid2 = vid;
					auto found = valToVid.find(operand);
					if(found != valToVid.end()){ //found in curDepBB
						LoopPDG::VID vid1 = valToVid[operand];
						edgeSet.insert(std::make_pair(vid1, vid2));
					}
					else{
						if(Instruction *srcInst = dyn_cast<Instruction>(operand)){
							BasicBlock *bbp = srcInst->getParent();
							//case1: src is out of Loop
							if(loop->contains(bbp) == false){
								interferingLoopSet.insert(loopID);
							}
							//case2: src is in subLoop
							else if(std::any_of(subLoops.begin(), subLoops.end(), [bbp](Loop *l){return l->contains(bbp);})){
								for(Loop *subl: subLoops){
									if(subl->contains(bbp)){
										assert(subLoopToVID.find(subl) != subLoopToVID.end());
										LoopPDG::VID vid1 = subLoopToVID[subl];
										edgeSet.insert(std::make_pair(vid1, vid2));
									}
								}
							}
							else assert(0&&"  WTF4224 \n");
						}
						else if(BasicBlock *srcBB = dyn_cast<BasicBlock>(operand)){ //TODO: control dependence
							assert((isa<BranchInst>(instPtr)||isa<SwitchInst>(instPtr)) && "WTF55");
						}
						else if(Constant *srcBB = dyn_cast<Constant>(operand)){
							DO_NOTHING;
						}
						else if(Argument *srcBB = dyn_cast<Argument>(operand)){
							interferingLoopSet.insert(loopID);
						}
						else assert(0&&"  WTF44444 \n");
					}
				}
			}
		}
		//22222222222222222222222

		//33333333333333333333333
		// get Control dependencies
		//33333333333333333333333
		Function &parentFun = *loop->getHeader()->getParent();
		PostDominatorTree &PDT = getAnalysis<PostDominatorTreeWrapperPass>(parentFun).getPostDomTree();
		std::set<std::map<BasicBlock*, BasicBlock*>> nonPdomEdges;
		nonPdomEdges.clear();
		nonPdomEdges = getNonPdomEdges(parentFun,PDT);
		std::map<BasicBlock *,std::set<BasicBlock *> > conDepMap = getConDep(parentFun,PDT,nonPdomEdges);

		for(std::pair<BasicBlock *,std::set<BasicBlock *>> condep : conDepMap){
			BasicBlock *srcBB = condep.first;
			if(!loop->contains(srcBB)) continue; // !!! : WE only care control dependencies that are inside in the loop.
			for(BasicBlock *dstBB : condep.second){
				if(!loop->contains(dstBB)) continue; // !!! WE only care control dependencies that are inside in the loop.
				auto foundSrcInSubLoop = std::find_if(subLoops.begin(), subLoops.end(), [srcBB](Loop *l){return l->contains(srcBB);});
				auto foundDstInSubLoop = std::find_if(subLoops.begin(), subLoops.end(), [dstBB](Loop *l){return l->contains(dstBB);});
				if(foundSrcInSubLoop != subLoops.end()){
					Loop *srcSubLoop = *foundSrcInSubLoop; assert(srcSubLoop);
					assert(subLoopToVID.find(srcSubLoop) != subLoopToVID.end());
					LoopPDG::VID vid1 = subLoopToVID[srcSubLoop];
					if(foundDstInSubLoop != subLoops.end()){
						Loop *dstSubLoop = *foundDstInSubLoop; assert(dstSubLoop);
						assert(subLoopToVID.find(dstSubLoop) != subLoopToVID.end());
						LoopPDG::VID vid2 = subLoopToVID[dstSubLoop];
						edgeSet.insert(std::make_pair(vid1, vid2));
					} else { //dstBB should be in curDepBB
						for(BasicBlock::iterator ii=dstBB->begin(), ie=dstBB->end(); ii!=ie; ++ii){
							Value *val = &*ii;
							assert(valToVid.find(val) != valToVid.end());
							LoopPDG::VID vid2 = valToVid[val];
							edgeSet.insert(std::make_pair(vid1, vid2));
						}
					}
				} else { //src is branchInst (terminator)
					Value *terminator = srcBB->getTerminator();
					assert(valToVid.find(terminator) != valToVid.end());
					LoopPDG::VID vid1 = valToVid[terminator];
					if(foundDstInSubLoop != subLoops.end()){
						Loop *dstSubLoop = *foundDstInSubLoop; assert(dstSubLoop);
						assert(subLoopToVID.find(dstSubLoop) != subLoopToVID.end());
						LoopPDG::VID vid2 = subLoopToVID[dstSubLoop];
						edgeSet.insert(std::make_pair(vid1, vid2));
					} else {
						for(BasicBlock::iterator ii=dstBB->begin(), ie=dstBB->end(); ii!=ie; ++ii){
							Value *val = &*ii;
							assert(valToVid.find(val) != valToVid.end());
							LoopPDG::VID vid2 = valToVid[val];
							edgeSet.insert(std::make_pair(vid1, vid2));
						}
					}
				}
			}
		}

		//add edge (actual)
		assert(num_edges(g) == 0);
		LoopPDG::EID eidCnt = 0;
		for(std::pair<LoopPDG::VID, LoopPDG::VID> edge : edgeSet){
			add_edge(vertex(edge.first, g), vertex(edge.second, g), LoopPDG::EdgeProp(eidCnt), g);
			eidCnt++;
		}
		//33333333333333333333333

		//dive deeper to the context awareness
		auto got = loopMap.find(loopID);
		if(got != loopMap.end()){ // found in tree
			//STAT
			int ca_SumNumSCC = 0;
			int ci_SumNumSCC = 0;


			LoopPDG::EdgeSet edgeSetContextIgnorant;
			for(auto ucid: loopMap[loopID]){ //iterate per loop context (loop instance)
				LoopPDG::EdgeSet edgeSetContextAware;

				//link ucid <-> (subloop or callsite):VID
				std::map<UniqueContextID, LoopPDG::VID> childUCIDtoVID;
				ContextTreeNode *treeNode = *std::find_if(pCxtTree->begin(), pCxtTree->end(), [loopID, ucid](ContextTreeNode *n){
						return (!n->isCallSite)&&(n->getCntxIDforLoop()==loopID)&&(n->getUCID()==ucid);});
				for(ContextTreeNode *childNode : *treeNode->getChildren()){
					if(childNode->isCallSite){
						const Instruction* callOrInvokeInst = childNode->getCallInst();
						assert(callOrInvokeInst);
						Value *valCallOrInvoke = dyn_cast<Value>(const_cast<Instruction*>(callOrInvokeInst));
						assert(valToVid.find(valCallOrInvoke) != valToVid.end());
						childUCIDtoVID[childNode->getUCID()] = valToVid[valCallOrInvoke];
					}
					else{
						const Loop* subloop = childNode->getLoop();
						assert(subloop);
						assert(subLoopToVID.find(const_cast<Loop *>(subloop)) != subLoopToVID.end());
						childUCIDtoVID[childNode->getUCID()] = subLoopToVID[const_cast<Loop *>(subloop)];
					}
				}

				std::set<UniqueContextID> allChildrenSet = getAllChildrenSet(ucid);
				// errs()<<" nChildren: ("<<ucIDMap[ucid]->getChildren()->size()<<", "<<allChildrenSet.size()<<")";

				for(Dependence *dep: depList){
					if(dep->ucIDsrc == ucid){
						assert(instIDtoVal.find(dep->instrIDsrc) != instIDtoVal.end()); //ERROR milc
						assert(valToVid.find(instIDtoVal[dep->instrIDsrc]) != valToVid.end());

						if(dep->ucIDdst == ucid){
							assert(instIDtoVal.find(dep->instrIDdst) != instIDtoVal.end());
							assert(valToVid.find(instIDtoVal[dep->instrIDdst]) != valToVid.end());
							//TODO : inst -> inst
							LoopPDG::VID vid1 = valToVid[instIDtoVal[dep->instrIDsrc]];
							LoopPDG::VID vid2 = valToVid[instIDtoVal[dep->instrIDdst]];
							edgeSetContextAware.insert(std::make_pair(vid1, vid2));
							edgeSetContextIgnorant.insert(std::make_pair(vid1, vid2));
						}
						else if(allChildrenSet.find(dep->ucIDdst) != allChildrenSet.end()){
							UniqueContextID directChildUCID = getDirectChild(ucid, dep->ucIDdst)->getUCID();
							assert(childUCIDtoVID.find(directChildUCID) != childUCIDtoVID.end());
							//TODO : inst -> ucid
							LoopPDG::VID vid1 = valToVid[instIDtoVal[dep->instrIDsrc]];
							LoopPDG::VID vid2 = childUCIDtoVID[directChildUCID];
							edgeSetContextAware.insert(std::make_pair(vid1, vid2));
							edgeSetContextIgnorant.insert(std::make_pair(vid1, vid2));
						}
						else{
							interferingLoopSet.insert(loopID);
						}
					}
					else if(allChildrenSet.find(dep->ucIDsrc) != allChildrenSet.end()){
						UniqueContextID directChildUCIDsrc = getDirectChild(ucid, dep->ucIDsrc)->getUCID();
						assert(childUCIDtoVID.find(directChildUCIDsrc) != childUCIDtoVID.end());

						if(dep->ucIDdst == ucid){
							assert(instIDtoVal.find(dep->instrIDdst) != instIDtoVal.end()); //ERROR mesa
							assert(valToVid.find(instIDtoVal[dep->instrIDdst]) != valToVid.end());
							//TODO : ucid -> inst
							LoopPDG::VID vid1 = childUCIDtoVID[directChildUCIDsrc];
							LoopPDG::VID vid2 = valToVid[instIDtoVal[dep->instrIDdst]];
							edgeSetContextAware.insert(std::make_pair(vid1, vid2));
							edgeSetContextIgnorant.insert(std::make_pair(vid1, vid2));
						}
						else if(allChildrenSet.find(dep->ucIDdst) != allChildrenSet.end()){
							UniqueContextID directChildUCIDdst = getDirectChild(ucid, dep->ucIDdst)->getUCID();
							assert(childUCIDtoVID.find(directChildUCIDdst) != childUCIDtoVID.end());
							//TODO : ucid -> ucid
							LoopPDG::VID vid1 = childUCIDtoVID[directChildUCIDsrc];
							LoopPDG::VID vid2 = childUCIDtoVID[directChildUCIDdst];
							edgeSetContextAware.insert(std::make_pair(vid1, vid2));
							edgeSetContextIgnorant.insert(std::make_pair(vid1, vid2));
						}
						else{
							interferingLoopSet.insert(loopID);
						}
					}
					else{// src is outside
						interferingLoopSet.insert(loopID);
					}
				}
				//================================ For Context aware Loop-PDG ===========================//
				//444444444444444444444
				// copy graph to build context-aware PDG
				//444444444444444444444
				LoopPDG::Graph ca_loopPDG;
				LoopPDG::VertexIDMap vidMap = get(&LoopPDG::VertexProp::id, g);
				copy_graph(g, ca_loopPDG, vertex_index_map(vidMap));

				// assert((num_edges(ca_loopPDG) != 0) && (num_vertices(ca_loopPDG) != 0)); //ERROR in 401.bzip
				assert((num_edges(ca_loopPDG) == num_edges(g)) && (num_vertices(ca_loopPDG) == num_vertices(g)));

				LoopPDG::EID eidCntCA = num_edges(ca_loopPDG);
				for(std::pair<LoopPDG::VID, LoopPDG::VID> e: edgeSetContextAware){
					add_edge(vertex(e.first, ca_loopPDG), vertex(e.second, ca_loopPDG), LoopPDG::EdgeProp(eidCntCA), ca_loopPDG);
					eidCntCA++;
				}
				//444444444444444444444

				//555555555555555555555
				//compute number of SCC
				//555555555555555555555		
				typedef typename graph_traits<LoopPDG::Graph>::vertices_size_type SCCID;
				std::vector<SCCID> sccIDVec;
				sccIDVec.assign(num_vertices(ca_loopPDG), 0);
				assert(sccIDVec.size() == num_vertices(ca_loopPDG) && "ERROR: sccIDVec size mismatch!");

				LoopPDG::VertexIDMap ca_vidMap = get(&LoopPDG::VertexProp::id, ca_loopPDG);
				typedef typename std::vector< graph_traits<LoopPDG::Graph>::vertices_size_type > MapImplType;
				typedef typename boost::iterator_property_map <MapImplType::iterator, LoopPDG::VertexIDMap> SCCMap;
				SCCMap sccMap(sccIDVec.begin(), ca_vidMap);
				int nSCC = strong_components(ca_loopPDG, sccMap, vertex_index_map(ca_vidMap));
				errs()<<"["<<nSCC<<"], ";//<<"\n";
				ca_SumNumSCC += nSCC;
				//555555555555555555555
				//========================================================================================//
			}//iterate per loop context (loop instance)


			//================================ For Context aware Loop-PDG ===========================//
			//444444444444444444444
			// copy graph to build context-aware PDG
			//444444444444444444444
			LoopPDG::Graph ci_loopPDG;
			LoopPDG::VertexIDMap vidMap = get(&LoopPDG::VertexProp::id, g);
			copy_graph(g, ci_loopPDG, vertex_index_map(vidMap));

			// assert((num_edges(ci_loopPDG) != 0) && (num_vertices(ci_loopPDG) != 0));//ERROR in 401.bzip
			assert((num_edges(ci_loopPDG) == num_edges(g)) && (num_vertices(ci_loopPDG) == num_vertices(g)));

			LoopPDG::EID eidCntCI = num_edges(ci_loopPDG);
			for(std::pair<LoopPDG::VID, LoopPDG::VID> e: edgeSetContextIgnorant){
				add_edge(vertex(e.first, ci_loopPDG), vertex(e.second, ci_loopPDG), LoopPDG::EdgeProp(eidCntCI), ci_loopPDG);
				eidCntCI++;
			}
			//444444444444444444444

			//555555555555555555555
			//compute number of SCC
			//555555555555555555555		
			typedef typename graph_traits<LoopPDG::Graph>::vertices_size_type SCCID;
			std::vector<SCCID> sccIDVec;
			sccIDVec.assign(num_vertices(ci_loopPDG), 0);
			assert(sccIDVec.size() == num_vertices(ci_loopPDG) && "ERROR: sccIDVec size mismatch!");

			LoopPDG::VertexIDMap ci_vidMap = get(&LoopPDG::VertexProp::id, ci_loopPDG);
			typedef typename std::vector< graph_traits<LoopPDG::Graph>::vertices_size_type > MapImplType;
			typedef typename boost::iterator_property_map <MapImplType::iterator, LoopPDG::VertexIDMap> SCCMap;
			SCCMap sccMap(sccIDVec.begin(), ci_vidMap);
			int nSCC = strong_components(ci_loopPDG, sccMap, vertex_index_map(ci_vidMap));
			
			std::vector<int> sccWeightVec;//vector of weight sum of each SCC
			for (int i = 0; i < nSCC; ++i){ //consider each vertex has 1 weight equally.
				sccWeightVec.push_back( std::count(sccIDVec.begin(), sccIDVec.end(), i) );
			}
			// errs()<<"(";
			// for(auto sccid: sccIDVec){
			// 	errs()<<sccid<<", ";
			// }
			// errs()<<")";
			// errs()<<"(-";
			// for(auto sccWeight: sccWeightVec){
			// 	errs()<<sccWeight<<", ";
			// }
			// errs()<<"-)";

			errs()<<" .. <<"<<nSCC<<">>";//<<"\n";
			ci_SumNumSCC = nSCC*(loopMap[loopID].size());
			//555555555555555555555
			//========================================================================================//

			//STAT
			errs()<<" .. <<"<<ca_SumNumSCC<<", "<<ci_SumNumSCC<<">>, ratio:"<<((double)(ca_SumNumSCC))/((double)ci_SumNumSCC)<<"\n";
			vecSCCIncreaseRate.push_back(((double)(ca_SumNumSCC))/((double)ci_SumNumSCC));
		}
		else{ // not found in tree (only in source code)
			DO_NOTHING;
		}

		// errs()<<", nCS: "<<nCallSite;
		// errs()<<", nContext: "<<loopMap[loopID].size()<<"\n";
		// if(loopMap[loopID].size()==0) loopMap.erase(loopID);
	}

	//STAT
	double product = 1.0;
	for(double r: vecSCCIncreaseRate) product = product * r;
	double avgSCCIncreaseRate = std::pow(product, 1.0/((double)(vecSCCIncreaseRate.size())));


	errs()<<" nLoops(in source code): "<<loopOfLoopID->size()<<", nLoops(in tree):"<<loopMap.size()<<", avgSCCIncreaseRate:"<<avgSCCIncreaseRate<<"\n";

	errs()<<"############## runOnModule [CAMPPipelinePll] END ##############\n";
	return true;
}

void CAMPPipelinePll::init(){
	char line[MAX_LINE_SIZE];
	unsigned nNode = 0;
	unsigned cnt = 0;


	// ############################################################################### //
	// //################## read ContextTree.data ################## //
	// ############################################################################### //
	std::ifstream fpCtxTree ("ContextTree.data", std::ifstream::binary);
	assert(fpCtxTree);

	fpCtxTree.getline(line, MAX_LINE_SIZE);
	string startMsg("$$$$$ CONTEXT TREE IN PREORDER $$$$$");
	assert(startMsg.compare(line) == 0);
	fpCtxTree.getline(line, MAX_LINE_SIZE);
	nNode = (unsigned)(atoi(line));

	// std::unordered_map<UniqueContextID, ContextTreeNode *> ucIDMap;
	// std::unordered_map<LoopID, std::vector<UniqueContextID>> loopMap;

	char ucIDStr[64];
	char locIDStr[64];
	char kind[4];
	char funName[64];
	char loopIDStr[64];
	char tmp[128];

	//add root (main)
	fpCtxTree>>ucIDStr;
	fpCtxTree>>locIDStr;
	fpCtxTree>>kind;
	fpCtxTree>>tmp;
	fpCtxTree>>funName;
	assert(strcmp(kind, "CS") == 0 && strcmp(funName, "main") == 0);
	root = new ContextTreePll(true, NULL, 0, 0);
	root->setFunName(funName);
	ucIDMap[0] = root;

	for (int i = 0; i < nNode-1; ++i){
		fpCtxTree>>ucIDStr;
		fpCtxTree>>locIDStr;
		UniqueContextID ucID = (UniqueContextID)(atoi(ucIDStr));
		LocalContextID locID = (LocalContextID)(atoi(locIDStr));
		ContextTreePll *curParent = ucIDMap[ ucID - locID ];

		fpCtxTree>>kind;
		if(strcmp(kind, "CS") == 0){
			fpCtxTree>>tmp; // recursive Fun? or normal?
			fpCtxTree>>funName;
			ContextTreePll *node = new ContextTreePll(true, curParent, ucID, (LocalContextID)(atoi(locIDStr)));
			node->setFunName(funName);
			curParent->addChild(node);
			ucIDMap[ucID] = node;
		}
		else if(strcmp(kind, "L") == 0){
			fpCtxTree>>loopIDStr;
			fpCtxTree>>tmp; // loop name;
			ContextTreePll *node = new ContextTreePll(false, curParent, ucID, (LocalContextID)(atoi(locIDStr)));
			LoopID loopID = (LoopID)(atoi(loopIDStr));
			node->setLoopID(loopID);
			curParent->addChild(node);

			ucIDMap[ucID] = node;
			loopMap[loopID].push_back(ucID);
		}
		else
			assert(0 &&"WTF?");
	}

	fpCtxTree.getline(line, MAX_LINE_SIZE); // for last char "\n" of last element Node
	fpCtxTree.getline(line, MAX_LINE_SIZE);
	string endMsg("$$$$$ CONTEXT TREE END $$$$$");
	assert(endMsg.compare(line) == 0);
	fpCtxTree.close();

	int nLoopNode = 0;
	for(auto e : loopMap) nLoopNode += e.second.size();

	errs()	<<" [Context Tree Node #: "<<ucIDMap.size()
		 	<<", Static Loop(in ContextTree) #: "<<loopMap.size()
		 	<<", Loop contexts(Loop Node) #:"<<nLoopNode
		 	<<", Static Loop #: "<<loopOfLoopID->size()<<"]\n";

	// ############################################################################### //
	// ###################### read DependenceTable.data #################### //
	// ############################################################################### //
	std::ifstream fpDepTb ("DependenceTable.real.data", std::ifstream::binary);
	assert(fpDepTb);

	// std::vector<Dependence *> depList;

	char depStr[128];
	while(fpDepTb >> depStr){ // Attempt read into depStr, return false if it fails
		uint32_t campIDsrc=0;
		uint32_t campIDdst=0;
		uint32_t iterRel=0;
		if(sscanf (depStr,"%x>%x:%x",&campIDsrc,&campIDdst, &iterRel) != 3) assert(0 && "ERROR: read fail");
		Dependence *newDep = new Dependence(campIDsrc>>16, campIDdst>>16, campIDsrc & 0xffff, campIDdst & 0xffff);
		newDep->addIterRel(iterRel);

		depList.push_back(newDep);
	}

	errs()<<"deps# : "<<depList.size()<<"\n";
	fpDepTb.close();

	// ############################################################################### //
	// ###### classify Dependencies to belonging loop instance(context)  ############# //
	// ############################################################################### //
}

UniqueContextID CAMPPipelinePll::getRightSiblingUCID(UniqueContextID ucid){
	ContextTreeNodePll *node = ucIDMap[ucid];
	assert(node);
	ContextTreeNodePll *parent = node->getParent();
	assert(parent);
	std::vector<UniqueContextID> sibling;

	for(ContextTreePll *c: *parent->getChildren()){
		if(c->getUCID() > ucid)
			sibling.push_back(c->getUCID());
	}
	std::sort(sibling.begin(), sibling.end());

	if(sibling.empty())
		return -1;
	else
		return sibling.front();
}


std::set<UniqueContextID> CAMPPipelinePll::getAllChildrenSet(UniqueContextID ucid){
	std::set<UniqueContextID> allChildrenSet;
	ContextTreeNodePll *node = ucIDMap[ucid];
	assert(node);

	std::list<ContextTreePll*> children( node->getChildren()->begin(), node->getChildren()->end() );
	while(!children.empty()){
		ContextTreePll *c = children.front();
		for (ContextTreePll *gc : *c->getChildren())
			children.push_back(gc);

		children.pop_front();

		allChildrenSet.insert(c->getUCID());
	}
	return allChildrenSet;
}

ContextTreeNodePll *CAMPPipelinePll::getDirectChild(UniqueContextID ucidParent, UniqueContextID ucidChild){

	ContextTreeNodePll *node = ucIDMap[ucidParent];
	assert(node);

	ContextTreeNodePll *child = ucIDMap[ucidChild];
	assert(child && (child!=node));

	while( std::find(node->getChildren()->begin(), node->getChildren()->end(), child) == node->getChildren()->end()){		
		if(child == node || child == NULL)
			assert(0&&"WTF13043\n");
		else
			child = child->getParent();
	}
	return child;
}


std::set<std::map<BasicBlock*, BasicBlock*>> CAMPPipelinePll::getNonPdomEdges(Function &F, const PostDominatorTree &PDT) {
	std::set<std::map<BasicBlock*, BasicBlock*>> nonPdomEdges;
	for(Function::iterator BB = F.begin(); BB != F.end(); ++BB) {
		for(succ_iterator SUCC = succ_begin(&*BB); SUCC != succ_end(&*BB); ++SUCC) {
			std::map<BasicBlock*, BasicBlock*> edge;
			if(PDT.properlyDominates(*SUCC,&*BB) == false) {
				edge[&*BB] = *SUCC; // BB -> SUCC edge
				nonPdomEdges.insert(edge);
			}
		} // iterating Successors 	
	} // iterating CFG
	return nonPdomEdges;
} // getNonPdomEdges

std::map<BasicBlock *,std::set<BasicBlock *> > CAMPPipelinePll::getConDep(Function &F, const PostDominatorTree &PDT, std::set<std::map<BasicBlock*, BasicBlock*>> nonPdomEdges) {
	std::map<BasicBlock *,std::set<BasicBlock *> > depMap;
	for(std::set<std::map<BasicBlock*, BasicBlock*>>::iterator it = nonPdomEdges.begin(); it != nonPdomEdges.end(); ++it) {
		for(auto edge = it->begin(); edge != it->end(); ++edge) {
			BasicBlock *x = edge->first;
			BasicBlock *y = edge->second;

			if(PDT.getNode(x) == NULL){
				// errs()<< "Problematic BB: "<< *x<<"\n================\n";
				// errs()<< "his parent: "<< *x->getParent()<<"\n@@@@@@@@@@@@@@@@@@@\n";
				continue;
			}
			assert(PDT.getNode(x));
			if(PDT.getNode(y) == NULL){
				// errs()<< "Problematic BB: "<< *y<<"\n================\n";
				// errs()<< "his parent: "<< *y->getParent()<<"\n@@@@@@@@@@@@@@@@@@@\n";
				continue;
			}
			assert(PDT.getNode(y));

			DomTreeNode *parentOfx = PDT.getNode(x)->getIDom();
			DomTreeNode *p = PDT.getNode(y)->getIDom();//ERROR in 401.bzip
			while(parentOfx != p) {
				depMap[x].insert(p->getBlock());
				p = p->getIDom();
				if(p == NULL) break;
			} // while : Important Core Algorithm !!
			depMap[x].insert(y);
		}
	}
	return depMap;
}


// LoopID loopID = pair.first;
// const Loop *loop = pair.second;

// auto got = loopMap.find(loopID);
// int nDirectChildren;
// // std::vector<ContextTreePll *> *directChildren = ucIDMap[loopMap[loopID].front()]->getChildren();
// if(got != loopMap.end()){//found in Tree;
// 	assert(ucIDMap.find(loopMap[loopID].front())!=ucIDMap.end());
// 	nDirectChildren = ucIDMap[loopMap[loopID].front()]->getChildren()->size();
// } else {
// 	nDirectChildren = -1;
// }
// ContextTreeNode *exampleNode = NULL;
// auto foundExampleNode = std::find_if(pCxtTree->begin(), pCxtTree->end(), [loopID](ContextTreeNode *n){
// 	return (!n->isCallSite)&&(n->getCntxIDforLoop()==loopID);});
// if(foundExampleNode != pCxtTree->end()){
// 	exampleNode = *foundExampleNode;
// 	assert(exampleNode->getChildren()->size() == nDirectChildren);
// }
// else
// 	assert(-1 == nDirectChildren);	



// // control dep test
// errs()<<"\n333333333333333 \n";
// errs()<<"LOOP !!"<<*loop<<" \n";
// for(BasicBlock *bbi : blocks){
// 	errs()<<*bbi<<"\n";
// }
// errs()<<"LOOP END !! \n";

// for(auto cd: conDepMap){
// 	errs()<<"src:"<<cd.first->getName().str()<<" \n dst:[ ";
// 	for(auto dstbb: cd.second){
// 		errs()<<dstbb->getName().str()<<", ";
// 	}
// 	errs()<<"]\n";
// }
// errs()<<"\n344444444444444444444 \n";






// //33333333333333333333333
// //compute number of SCC
// //33333333333333333333333		
// typedef typename graph_traits<LoopPDG::Graph>::vertices_size_type SCCID;
// std::vector<SCCID> sccIDVec;
// sccIDVec.assign(num_vertices(g), 0);
// assert(sccIDVec.size() == num_vertices(g) && "ERROR: sccIDVec size mismatch!");

// LoopPDG::VertexIDMap vidMap = get(&LoopPDG::VertexProp::id, g);
// typedef typename std::vector< graph_traits<LoopPDG::Graph>::vertices_size_type > MapImplType;
// typedef typename boost::iterator_property_map <MapImplType::iterator, LoopPDG::VertexIDMap> SCCMap;
// SCCMap sccMap(sccIDVec.begin(), vidMap);
// int nSCC = strong_components(g, sccMap, vertex_index_map(vidMap));
// //errs()<<"nSCC: "<<nSCC;//<<"\n";
// //33333333333333333333333