#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/CallSite.h"

#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/IR/Instructions.h"
#include "llvm/Support/Compiler.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Support/Debug.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/IR/CFG.h"
#include "llvm/IR/IRBuilder.h"

#include "llvm/Analysis/CallGraph.h"
#include "llvm/Analysis/LoopInfo.h"
#include "llvm/Analysis/LoopPass.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/Analysis/Passes.h"
#include "llvm/IR/DataLayout.h"
#include "llvm/IR/InstIterator.h"

#include "CallCounter.h"
#include "corelab/Utilities/InstInsertPt.h"
#include "corelab/Utilities/GlobalCtors.h"
#include "corelab/Metadata/Metadata.h"
#include "corelab/Metadata/LoadNamer.h"

#include <iostream>
#include <fstream>
#include <algorithm>    // std::for_each
#include <iterator>

using namespace corelab;

char CAMPCallCounter::ID = 0;
static RegisterPass<CAMPCallCounter> X("camp-call-cnt", "camp-call-cnt", false, false);


bool CAMPCallCounter::runOnModule(Module& M) {
	module = &M;
	setFunctions(M);
	DEBUG(errs()<<"############## runOnModule [CAMPCallCounter] START ##############\n");
	
	for(Module::iterator fi = M.begin(), fe = M.end(); fi != fe; ++fi) {
		Function &F = *fi;
		LLVMContext &Context = M.getContext();
		std::vector<Value*> args(0);
		if (F.isDeclaration()) continue;

		LoopInfo &li = getAnalysis<LoopInfoWrapperPass>(F).getLoopInfo();
		std::list<Loop*> all_loops( li.begin(), li.end() );
		while(!all_loops.empty()){
			Loop *loop = all_loops.front();
			for (Loop *subLoop : loop->getSubLoops())
				all_loops.push_back(subLoop);
			all_loops.pop_front();

			BasicBlock *preHeader = loop->getLoopPreheader();
			
			// set loopID as an argument
			std::vector<Value*> args(1); 
			args.resize(1);
			args[0] = ConstantInt::get(Type::getInt16Ty(Context), 0); 
			assert(!preHeader->empty() && "ERROR: preheader of loop doesnt have TerminatorInst");
			CallInst::Create(campLoopBegin, args, "", preHeader->getTerminator());
			
		}

		for (inst_iterator I = inst_begin(F), E = inst_end(F); I != E; ++I){
			Instruction *instruction = &*I; 
			if(LoadInst *ld = dyn_cast<LoadInst>(instruction)) {
				args.resize (2);
				Value *addr = ConstantInt::get(Type::getInt64Ty(Context), 0);
				Value *temp = ConstantInt::get(Type::getInt16Ty(Context), 0); 
				
				args[0] = addr;
				args[1] = temp;
				CallInst::Create(campLoadInstr, args, "", ld);	
			}
			// For each store instructions
			else if (StoreInst *st = dyn_cast<StoreInst>(instruction)) {
				args.resize (2);
				Value *addr = ConstantInt::get(Type::getInt64Ty(Context), 0);
				Value *temp = ConstantInt::get(Type::getInt16Ty(Context), 0); 
				
				args[0] = addr;
				args[1] = temp;

				CallInst::Create(campStoreInstr, args, "", st);			
			}
			else if(isa<InvokeInst>(instruction) || isa<CallInst>(instruction) ){
				args.resize(1);
				Value *temp = ConstantInt::get(Type::getInt16Ty(Context), 0);
				args[0] = temp;
				CallInst::Create(campCallSiteBegin, args, "", instruction);
			} //InvokeInst

		}
	}

	DEBUG(errs()<<"############## runOnModule [CAMPCallCounter] END ##############\n");
	setIniFini(M);
	return false;
}


void CAMPCallCounter::setFunctions(Module &M)
{
	LLVMContext &Context = M.getContext();

	campInitialize = M.getOrInsertFunction(
			"campInitialize",
			Type::getVoidTy(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			(Type*)0);

	campFinalize = M.getOrInsertFunction(
			"campFinalize",
			Type::getVoidTy(Context),
			(Type*)0);

	campCallSiteBegin = M.getOrInsertFunction(
			"campCallSiteBegin",
			Type::getVoidTy(Context),
			Type::getInt16Ty(Context),
			(Type*)0);

	campLoopBegin = M.getOrInsertFunction(
			"campLoopBegin",
			Type::getVoidTy(Context),
			Type::getInt16Ty(Context),
			(Type*)0);

	campLoadInstr = M.getOrInsertFunction(
			"campLoadInstr",
			Type::getVoidTy(Context),
			Type::getInt64Ty(Context),
			Type::getInt16Ty(Context),
			(Type*)0);

	campStoreInstr = M.getOrInsertFunction(
			"campStoreInstr",
			Type::getVoidTy(Context),
			Type::getInt64Ty(Context),
			Type::getInt16Ty(Context),
			(Type*)0);

	return;
}

void CAMPCallCounter::setIniFini(Module& M)
{
	LLVMContext &Context = M.getContext();
	std::vector<Type*> formals(0);
	std::vector<Value*> actuals(0);
	FunctionType *voidFcnVoidType = FunctionType::get(Type::getVoidTy(Context), formals, false);

	/* initialize */
	Function *initForCtr = Function::Create( 
			voidFcnVoidType, GlobalValue::InternalLinkage, "__constructor__", &M); 
	BasicBlock *entry = BasicBlock::Create(Context,"entry", initForCtr); 
	BasicBlock *initBB = BasicBlock::Create(Context, "init", initForCtr); 
	actuals.resize(5);

	Value *loadCnt = ConstantInt::get(Type::getInt64Ty(Context), 0);
	Value *storeCnt = ConstantInt::get(Type::getInt64Ty(Context), 0);
	Value *callCnt = ConstantInt::get(Type::getInt64Ty(Context), 0);
	Value *loopCnt = ConstantInt::get(Type::getInt64Ty(Context), 0);
	Value *maxLoopDepthVal = ConstantInt::get(Type::getInt64Ty(Context), 0);
	actuals[0] = loadCnt;
	actuals[1] = storeCnt;
	actuals[2] = callCnt;
	actuals[3] = loopCnt;
	actuals[4] = maxLoopDepthVal;
	
	CallInst::Create(campInitialize, actuals, "", entry); 
	BranchInst::Create(initBB, entry); 
	ReturnInst::Create(Context, 0, initBB);
	callBeforeMain(initForCtr);
	
	/* finalize */
	Function *finiForDtr = Function::Create(voidFcnVoidType, GlobalValue::InternalLinkage, "__destructor__",&M);
	BasicBlock *finiBB = BasicBlock::Create(Context, "entry", finiForDtr);
	BasicBlock *fini = BasicBlock::Create(Context, "fini", finiForDtr);
	actuals.resize(0);
	CallInst::Create(campFinalize, actuals, "", fini);
	BranchInst::Create(fini, finiBB);
	ReturnInst::Create(Context, 0, fini);
	callAfterMain(finiForDtr);
}
