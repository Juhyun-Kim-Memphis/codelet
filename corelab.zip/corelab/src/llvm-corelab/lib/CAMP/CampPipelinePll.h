#ifndef LLVM_CORELAB_CAMP_PIPELINE_PLL_H
#define LLVM_CORELAB_CAMP_PIPELINE_PLL_H

#include <inttypes.h>
#include <vector>
#include <list>
#include <cstring>
#include <cassert>
#include <iostream>
#include <unordered_map>
#include <unordered_set>

#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Constants.h"
#include "llvm/Analysis/PostDominators.h"

#include "corelab/CAMP/campMeta.h"
#include "corelab/CAMP/ContextTreeBuilder.h"

#include <boost/config.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/property_map/property_map.hpp>
#include <boost/graph/graph_utility.hpp>
#include <boost/graph/copy.hpp>
#include <boost/graph/strong_components.hpp>

#ifndef DEBUG_TYPE
  #define DEBUG_TYPE "camp-pipeline-pll"
#endif

#define TREE_MAX_DEPTH_LIMIT 12000


namespace corelab
{
	using namespace llvm;
	using namespace std;
	using namespace boost;


	class LoopPDG{  
	public:
		typedef uint32_t VID; //Vertex ID
		typedef uint32_t EID; //Edge ID

		struct EdgeProp {
			EdgeProp(VID id) : id(id) {}
			EdgeProp() : id(0) {}
			typedef VID value_type;
			VID id;
		};

		struct VertexProp {
			VertexProp(EID id) : id(id) {}
			VertexProp() : id(0) {}
			typedef EID value_type;
			EID id;
		};

		//BGL boost graph library //ASSUME vertex_index_t == uint32_t TYPE
		// typedef adjacency_list<vecS, vecS, bidirectionalS, property<vertex_index_t, uint32_t>> Graph;
		typedef adjacency_list<vecS, listS, bidirectionalS, VertexProp, EdgeProp> Graph;
		typedef typename property_map<Graph, VID VertexProp::*>::type VertexIDMap;
		typedef typename property_map<Graph, EID EdgeProp::*>::type EdgeIDMap;
		typedef typename boost::graph_traits < Graph >::out_edge_iterator OutEdgeIter;
		typedef typename boost::graph_traits < Graph >::in_edge_iterator InEdgeIter;
		typedef typename boost::graph_traits < Graph >::vertex_descriptor VertexType;
		typedef typename boost::graph_traits < Graph >::edge_descriptor EdgeType;
		typedef typename boost::graph_traits < Graph >::vertex_iterator VertexIter;
		typedef typename boost::graph_traits < Graph >::edge_iterator EdgeIter;

		// Each node has input and output data ports
		// input: in edges
		// output: llvm::Value (in external property map)
		typedef std::unordered_map<VID, const llvm::Value*> VidToValue;
		typedef std::unordered_map<const llvm::Value*, VID> ValueToVid;
		typedef std::unordered_map<VID, llvm::Loop*> VidToSubLoop;
		typedef std::unordered_map<llvm::Loop*, VID> SubLoopToVid;
		typedef std::set<std::pair<VID, VID>> EdgeSet;

		Graph& getBGLGraph(){return bglGraph;}
		VidToValue& getVidToValue(){return vidToValue;}
		ValueToVid& getValueToVid(){return valueToVID;}
		VidToSubLoop& getVidToSubLoop(){return vidToSubLoop;}
		SubLoopToVid& getSubLoopToVid(){return subLoopToVID;}
		EdgeSet& getEdgeSet(){return edgeSet;}

	private:
		Graph bglGraph;
		VidToValue vidToValue;
		ValueToVid valueToVID;
		VidToSubLoop vidToSubLoop;
		SubLoopToVid subLoopToVID;
		EdgeSet edgeSet;
	};

	class ContextTreePll;
	typedef ContextTreePll ContextTreeNodePll;
	// typedef uint16_t UniqueContextID;
	typedef uint16_t LocalContextID;
	typedef uint16_t LoopID;

	class ContextTreePll{
		public:
			ContextTreePll(bool b, ContextTreeNodePll *p, UniqueContextID ucID_, LocalContextID locID_)
				: isCallSite(b), ucID(ucID_), parent(p), locID(locID_) {
					assert(locID == (ucID-(parent != NULL ? parent->ucID : 0)) );
				}

			bool isCallSite;
			//bool isRecursiveCallSite;
			
			char funName[64]; //for callsite

			LoopID loopID;	//for Loop

			UniqueContextID ucID;
			LocalContextID locID;
			
			//tree
			ContextTreePll *parent;
			std::vector<ContextTreePll *> children;

			//set
			inline void setFunName(char *s){strcpy(funName, s);}
			inline std::string getFunName(){return std::string(funName);}
			inline void setLoopID(LoopID l){loopID = l;}

			//get
			inline ContextTreePll* getParent(){return parent;}
			inline UniqueContextID getUCID(){return ucID;}
			inline LocalContextID getLocID(){return locID;}
			inline LoopID getLoopID(){return loopID;}
			inline LocalContextID getLocalContextID(){return locID;}
			inline std::vector<ContextTreePll *> *getChildren(){return &children;}
			inline bool isCallSiteNode(){return isCallSite;}

			void getContextStack(std::list<ContextTreeNodePll *> *cxtStk){
				cxtStk->push_front(this);
				if(parent) parent->getContextStack(cxtStk);
			}

			// inline bool isRecursiveCallSiteNode(){return isRecursiveCallSite;}
			void addChild(ContextTreeNodePll *c){
				children.push_back(c);
			}
			// void markRecursive(){
			// 	assert(isCallSite);
			// 	isRecursiveCallSite = true;
			// }
			void printPathToRoot(){
				if(isCallSite)
					cout<<" ["<<ucID<<"("<<funName<<")] ";
				else
					cout<<" ["<<ucID<<": "<<loopID<<"] ";
				if(parent == NULL) return;
				parent->printPathToRoot();
			}
	};

	typedef uint16_t InstrID;
	typedef uint32_t CampID;
	typedef uint32_t DepKey;

	typedef enum
	{
		N = 0x00,
		I = 0x01,
		X = 0x02,
		M = 0x03
	} IterRel;

	class Dependence{
		public:
			Dependence(UniqueContextID ucIDsrc_, UniqueContextID ucIDdst_, InstrID instrIDsrc_, InstrID instrIDdst_) 
			: ucIDsrc(ucIDsrc_), ucIDdst(ucIDdst_), instrIDsrc(instrIDsrc_), instrIDdst(instrIDdst_) {
				depKey = ucIDsrc << 16 | ucIDdst;
			}

			Dependence(const Dependence &obj){
				ucIDsrc = obj.ucIDsrc;
				ucIDdst = obj.ucIDdst;
				instrIDsrc = obj.instrIDsrc;
				instrIDdst = obj.instrIDdst;
			}
			DepKey depKey;
			UniqueContextID ucIDsrc;
			UniqueContextID ucIDdst;
			InstrID instrIDsrc;
			InstrID instrIDdst;
			IterRel iterRel[16];

			inline DepKey getDepKey(){return depKey;}
			void addIterRel(uint32_t iterRel_32){
				for (int i = 0; i < 16; ++i){
					iterRel[i] = (IterRel)( ( (0x03 << i*2) & iterRel_32 ) >> (i*2) );
				}
			}
			void printIterRel(){
				cout<<"IterRel: {";
				for (int i = 0; i < 16; ++i){
					cout<<(iterRel[i]==0?'N':iterRel[i]==1?'I':iterRel[i]==2?'X':'M')<<", ";
				}	
				cout<<"}";
			}
			bool operator==(const Dependence &rhs) const{
				// bool sameIterRel = true;
				// for (int i = 0; i < 16; ++i)
				// 	sameIterRel = sameIterRel && iterRel[i] == rhs.iterRel[i];
				// return depKey == rhs.depKey && instrIDsrc == rhs.instrIDsrc && instrIDdst == rhs.instrIDdst && sameIterRel;


				return depKey == rhs.depKey && instrIDsrc == rhs.instrIDsrc && instrIDdst == rhs.instrIDdst;
			}
	};


	class DependenceSimplified{
		public:
			DependenceSimplified(UniqueContextID ucIDsrc_, UniqueContextID ucIDdst_, InstrID instrIDsrc_, InstrID instrIDdst_) 
			: ucIDsrc(ucIDsrc_), ucIDdst(ucIDdst_), instrIDsrc(instrIDsrc_), instrIDdst(instrIDdst_) {}

			DependenceSimplified(const DependenceSimplified &obj){
				ucIDsrc = obj.ucIDsrc;
				ucIDdst = obj.ucIDdst;
				instrIDsrc = obj.instrIDsrc;
				instrIDdst = obj.instrIDdst;
			}
			UniqueContextID ucIDsrc;
			UniqueContextID ucIDdst;
			InstrID instrIDsrc;
			InstrID instrIDdst;

			bool operator==(const DependenceSimplified &rhs) const{
				return (ucIDsrc == rhs.ucIDsrc) && (ucIDdst == rhs.ucIDdst) && (instrIDsrc == rhs.instrIDsrc) && (instrIDdst == rhs.instrIDdst);
			}
	};

	class CAMPPipelinePll : public ModulePass
	{
		public:

			bool runOnModule(Module& M);

			virtual void getAnalysisUsage(AnalysisUsage &AU) const
			{
				AU.addRequired< ContextTreeBuilder >();
				AU.addRequired< LoopInfoWrapperPass >();
				AU.addRequired<PostDominatorTreeWrapperPass>();
				AU.setPreservesAll();
			}

			const char *getPassName() const { return "camp-pipeline-pll"; }

			static char ID;
			CAMPPipelinePll() : ModulePass(ID) {}

			void init();

		private:

			std::unordered_map<UniqueContextID, ContextTreeNodePll *> ucIDMap;
			std::unordered_map<LoopID, std::vector<UniqueContextID>> loopMap;
			ContextTreePll *root;
			std::vector<Dependence *> depList;


			// typedef DenseMap<const Loop *, CntxID > LoopIdOf; // CntxID == LoopID;
			// typedef std::map<CntxID, const Loop *> LoopOfCntxID;//inverse of LoopIdOf
			ContextTreeBuilder *cxtTreeBuilder;
			std::vector<ContextTreeNode *> *pCxtTree;
			ContextTreeBuilder::LoopIdOf *loopIdOf;
			ContextTreeBuilder::LoopOfCntxID *loopOfLoopID;

			std::set<LoopID> interferingLoopSet;

			Module *module;

			UniqueContextID getRightSiblingUCID(UniqueContextID ucid);
			std::set<UniqueContextID> getAllChildrenSet(UniqueContextID ucid);
			ContextTreeNodePll *getDirectChild(UniqueContextID ucidParent, UniqueContextID ucidChild);
			std::set<std::map<BasicBlock*, BasicBlock*>> getNonPdomEdges(Function &F, const PostDominatorTree &PDT);
			std::map<BasicBlock *,std::set<BasicBlock *> > getConDep(Function &F, const PostDominatorTree &PDT, std::set<std::map<BasicBlock*, BasicBlock*>> nonPdomEdges);

			std::vector<double> vecSCCIncreaseRate;
	};

}

#endif //LLVM_CORELAB_CAMP_PIPELINE_PLL_H
