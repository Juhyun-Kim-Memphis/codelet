#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/CallSite.h"

#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/IR/Instructions.h"
#include "llvm/Support/Compiler.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Support/Debug.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/IR/CFG.h"
#include "llvm/IR/IRBuilder.h"

#include "llvm/Analysis/CallGraph.h"
#include "llvm/Analysis/LoopInfo.h"
#include "llvm/Analysis/LoopPass.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/Analysis/Passes.h"
#include "llvm/IR/DataLayout.h"
#include "llvm/IR/InstIterator.h"

#include "corelab/Utilities/InstInsertPt.h"
#include "corelab/Utilities/GlobalCtors.h"
#include "corelab/Metadata/Metadata.h"
#include "corelab/Metadata/LoadNamer.h"
#include "CtxtObliProf.h"

using namespace corelab;
//using namespace corelab::CtxtObliProf;
const Value *getCalledValueOfIndCall(const Instruction* indCall);
Function *getCalledFunction_aux(Instruction* indCall);

char CtxtObliProf::ID = 0;
static RegisterPass<CtxtObliProf> X("ctxt-obli-prof", "Context Oblivious Profiler", false, false);

void CtxtObliProf::setFunctions(Module &M)
{
	LLVMContext &Context = M.getContext();

	ctxtobliInitialize = M.getOrInsertFunction(
			"ctxtobliInitialize",
			Type::getVoidTy(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			(Type*)0);

	ctxtobliFinalize = M.getOrInsertFunction(
			"ctxtobliFinalize",
			Type::getVoidTy(Context),
			(Type*)0);

	ctxtobliLoadInstr = M.getOrInsertFunction(
			"ctxtobliLoadInstr",
			Type::getVoidTy(Context),
			Type::getInt64Ty(Context),
			Type::getInt16Ty(Context),
			(Type*)0);

	ctxtobliStoreInstr = M.getOrInsertFunction(
			"ctxtobliStoreInstr",
			Type::getVoidTy(Context),
			Type::getInt64Ty(Context),
			Type::getInt16Ty(Context),
			(Type*)0);


	ctxtobliMalloc = M.getOrInsertFunction(
			"ctxtobliMalloc",
			Type::getInt8PtrTy(Context),
			Type::getInt64Ty(Context),
			(Type*)0);

	ctxtobliCalloc = M.getOrInsertFunction(
			"ctxtobliCalloc",
			Type::getInt8PtrTy(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			(Type*)0);

	ctxtobliRealloc = M.getOrInsertFunction(
			"ctxtobliRealloc",
			Type::getInt8PtrTy(Context),
			Type::getInt8PtrTy(Context),
			Type::getInt64Ty(Context),
			(Type*)0);

	ctxtobliFree = M.getOrInsertFunction(
			"ctxtobliFree",
			Type::getVoidTy(Context),
			Type::getInt8PtrTy(Context),
			(Type*)0);

	return;
}

void CtxtObliProf::setIniFini(Module& M)
{
	LLVMContext &Context = M.getContext();
	LoadNamer &loadNamer = getAnalysis< LoadNamer >();
	std::vector<Type*> formals(0);
	std::vector<Value*> actuals(0);
	FunctionType *voidFcnVoidType = FunctionType::get(Type::getVoidTy(Context), formals, false);

	/* initialize */
	Function *initForCtr = Function::Create( 
			voidFcnVoidType, GlobalValue::InternalLinkage, "__constructor__", &M); 
	BasicBlock *entry = BasicBlock::Create(Context,"entry", initForCtr); 
	BasicBlock *initBB = BasicBlock::Create(Context, "init", initForCtr); 
	actuals.resize(5);

	Value *loadCnt = ConstantInt::get(Type::getInt64Ty(Context), loadNamer.numLoads);
	Value *storeCnt = ConstantInt::get(Type::getInt64Ty(Context), loadNamer.numStores);
	Value *callCnt = ConstantInt::get(Type::getInt64Ty(Context), loadNamer.numCalls);
	Value *loopCnt = ConstantInt::get(Type::getInt64Ty(Context), loadNamer.numLoops);
	Value *maxLoopDepthVal = ConstantInt::get(Type::getInt64Ty(Context), 0);
	actuals[0] = loadCnt;
	actuals[1] = storeCnt;
	actuals[2] = callCnt;
	actuals[3] = loopCnt;
	actuals[4] = maxLoopDepthVal;
	
	CallInst::Create(ctxtobliInitialize, actuals, "", entry); 
	BranchInst::Create(initBB, entry); 
	ReturnInst::Create(Context, 0, initBB);
	callBeforeMain(initForCtr);
	
	/* finalize */
	Function *finiForDtr = Function::Create(voidFcnVoidType, GlobalValue::InternalLinkage, "__destructor__",&M);
	BasicBlock *finiBB = BasicBlock::Create(Context, "entry", finiForDtr);
	BasicBlock *fini = BasicBlock::Create(Context, "fini", finiForDtr);
	actuals.resize(0);
	CallInst::Create(ctxtobliFinalize, actuals, "", fini);
	BranchInst::Create(fini, finiBB);
	ReturnInst::Create(Context, 0, fini);
	callAfterMain(finiForDtr);
}

bool CtxtObliProf::runOnModule(Module& M) {
	setFunctions(M);
	pLoadNamer = &getAnalysis< LoadNamer >();
	LoadNamer &loadNamer = *pLoadNamer;
	module = &M;

	DEBUG(errs()<<"############## runOnModule [CtxtObliProf] START ##############\n");
	for(Module::iterator fi = M.begin(), fe = M.end(); fi != fe; ++fi) {
		Function &F = *fi;
		LLVMContext &Context = M.getContext();
		const DataLayout &dataLayout = module->getDataLayout();
		std::vector<Value*> args(0);
		if (F.isDeclaration()) continue;
		for (inst_iterator I = inst_begin(F), E = inst_end(F); I != E; ++I){
			Instruction *instruction = &*I; 
			if(LoadInst *ld = dyn_cast<LoadInst>(instruction)) {
				if(isUseOfGetElementPtrInst(ld) == false){
					args.resize (2);
					Value *addr = ld->getPointerOperand();
					Value *temp = ConstantInt::get(Type::getInt64Ty(Context), 0);
					InstInsertPt out = InstInsertPt::Before(ld);
					addr = castTo(addr, temp, out, &dataLayout); 
					
					InstrID instrId = Namer::getInstrId(instruction);

					Value *instructionId = ConstantInt::get(Type::getInt16Ty(Context), instrId);
					//for debug
					//errs()<<"<"<<instrId<<"> "<<*ld<<"\n";

					#ifdef CAMP_INSTALLER_DEBUG
						fprintf(stderr, "load instruction id %" SCNu16 "\n",instrId); 
					#endif

					args[0] = addr;
					args[1] = instructionId;
					CallInst::Create(ctxtobliLoadInstr, args, "", ld);	
				}
			}
			// For each store instructions
			else if (StoreInst *st = dyn_cast<StoreInst>(instruction)) {
				args.resize (2);
				Value *addr = st->getPointerOperand();
				Value *temp = ConstantInt::get(Type::getInt64Ty(Context), 0);
				InstInsertPt out = InstInsertPt::Before(st);
				addr = castTo(addr, temp, out, &dataLayout); 
				
				InstrID instrId = Namer::getInstrId(instruction);
				Value *instructionId = ConstantInt::get(Type::getInt16Ty(Context), instrId);
				//for debug
				//errs()<<"<"<<instrId<<"> "<<*st<<"\n";

				#ifdef CAMP_INSTALLER_DEBUG
					fprintf(stderr, "store instruction id %" SCNu16 "\n",instrId);
				#endif

				args[0] = addr;
				args[1] = instructionId;
				CallInst::Create(ctxtobliStoreInstr, args, "", st);			
			}
		}
	}
	hookMallocFree();

	DEBUG(errs()<<"############## runOnModule [CtxtObliProf] END ##############\n");
	setIniFini(M);
	return false;
}


bool CtxtObliProf::isUseOfGetElementPtrInst(LoadInst *ld){
	// is only Used by GetElementPtrInst ?
	return std::all_of(ld->user_begin(), ld->user_end(), [](User *user){return isa<GetElementPtrInst>(user);});
}


void CtxtObliProf::hookMallocFree(){
	for(Module::iterator fi = module->begin(), fe = module->end(); fi != fe; ++fi) {
		Function &F = *fi;
		std::vector<Value*> args(0);

		if (F.isDeclaration()) continue;
		for (inst_iterator I = inst_begin(F), E = inst_end(F); I != E; ++I){
			Instruction *instruction = &*I;
			bool wasBitCasted = false;
			Type *ty;
			IRBuilder<> Builder(instruction);
			if(isa<InvokeInst>(instruction) || isa<CallInst>(instruction)){
				Function *callee = getCalledFunction_aux(instruction);
				if(!callee){
					const Value *calledVal = getCalledValueOfIndCall(instruction);
					if(const Function *tarFun = dyn_cast<Function>(calledVal->stripPointerCasts())){
						wasBitCasted = true;
						ty = calledVal->getType();
						callee = const_cast<Function *>(tarFun);
					}
				}
				if(!callee) continue;
				if(callee->isDeclaration() == false) continue;

				if(CallInst *callInst = dyn_cast<CallInst>(instruction)){
					if(callee->getName() == "malloc"){
						if(wasBitCasted){
							Value * changeTo = Builder.CreateBitCast(ctxtobliMalloc, ty);
							callInst->setCalledFunction(changeTo);
						} else {
							callInst->setCalledFunction(ctxtobliMalloc);
						}
					}
					else if(callee->getName() == "calloc"){
						if(wasBitCasted){
							Value *changeTo = Builder.CreateBitCast(ctxtobliCalloc, ty);
							callInst->setCalledFunction(changeTo);
						} else {
							callInst->setCalledFunction(ctxtobliCalloc);
						}
					}
					else if(callee->getName() == "realloc"){
						if(wasBitCasted){
							Value *changeTo = Builder.CreateBitCast(ctxtobliRealloc, ty);
							callInst->setCalledFunction(changeTo);
						} else {
							callInst->setCalledFunction(ctxtobliRealloc);
						}
					}
					else if(callee->getName() == "free"){
						if(wasBitCasted){
							Value *changeTo = Builder.CreateBitCast(ctxtobliFree, ty);
							callInst->setCalledFunction(changeTo);
						} else {
							callInst->setCalledFunction(ctxtobliFree);
						}
					}
				}
				else if(InvokeInst *callInst = dyn_cast<InvokeInst>(instruction)){
					if(callee->getName() == "malloc"){
						if(wasBitCasted){
							Value *changeTo = Builder.CreateBitCast(ctxtobliMalloc, ty);
							callInst->setCalledFunction(changeTo);
						} else {
							callInst->setCalledFunction(ctxtobliMalloc);
						}
					}
					else if(callee->getName() == "calloc"){
						if(wasBitCasted){
							Value *changeTo = Builder.CreateBitCast(ctxtobliCalloc, ty);
							callInst->setCalledFunction(changeTo);
						} else {
							callInst->setCalledFunction(ctxtobliCalloc);
						}
					}
					else if(callee->getName() == "realloc"){
						if(wasBitCasted){
							Value *changeTo = Builder.CreateBitCast(ctxtobliRealloc, ty);
							callInst->setCalledFunction(changeTo);
						} else {
							callInst->setCalledFunction(ctxtobliRealloc);
						}
					}
					else if(callee->getName() == "free"){
						if(wasBitCasted){
							Value *changeTo = Builder.CreateBitCast(ctxtobliFree, ty);
							callInst->setCalledFunction(changeTo);
						} else {
							callInst->setCalledFunction(ctxtobliFree);
						}
					}
				}
				else
					assert(0&&"ERROR!!");
			}
		}
	}
}


//Utility
Value* CtxtObliProf::castTo(Value* from, Value* to, InstInsertPt &out, const DataLayout *dl)
{
	LLVMContext &Context = from->getContext();
	const size_t fromSize = dl->getTypeSizeInBits( from->getType() );
	const size_t toSize = dl->getTypeSizeInBits( to->getType() );

	// First make it an integer
	if( ! from->getType()->isIntegerTy() ) {
		// cast to integer of same size of bits
		Type *integer = IntegerType::get(Context, fromSize);
		Instruction *cast;
		if( from->getType()->getTypeID() == Type::PointerTyID )
			cast = new PtrToIntInst(from, integer);
		else {
			cast = new BitCastInst(from, integer);
		}
		out << cast;
		from = cast;
	} 

	// Next, make it have the same size
	if( fromSize < toSize ) {
		Type *integer = IntegerType::get(Context, toSize);
		Instruction *cast = new ZExtInst(from, integer);
		out << cast;
		from = cast;
	} else if ( fromSize > toSize ) {
		Type *integer = IntegerType::get(Context, toSize);
		Instruction *cast = new TruncInst(from, integer);
		out << cast;
		from = cast;
	}

	// possibly bitcast it to the approriate type
	if( to->getType() != from->getType() ) {
		Instruction *cast;
		if( to->getType()->getTypeID() == Type::PointerTyID )
			cast = new IntToPtrInst(from, to->getType() );
		else {
			cast = new BitCastInst(from, to->getType() );
		}

		out << cast;
		from = cast;
	}

	return from;
}
