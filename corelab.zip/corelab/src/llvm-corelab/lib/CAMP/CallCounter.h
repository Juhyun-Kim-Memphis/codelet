#ifndef LLVM_CORELAB_CAMP_CALL_CNT_H
#define LLVM_CORELAB_CAMP_CALL_CNT_H

#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Constants.h"

#ifndef DEBUG_TYPE
  #define DEBUG_TYPE "camp-call-cnt"
#endif


namespace corelab
{
	using namespace llvm;
	using namespace std;

	class CAMPCallCounter : public ModulePass
	{
		public:

			bool runOnModule(Module& M);

			virtual void getAnalysisUsage(AnalysisUsage &AU) const
			{
				AU.addRequired< LoopInfoWrapperPass >();
				AU.setPreservesAll();
			}

			const char *getPassName() const { return "camp-call-cnt"; }

			static char ID;
			CAMPCallCounter() : ModulePass(ID) {}

		private:
			
			Module *module;

			/* Functions */

			// initialize, finalize functions
			Constant *campInitialize;
			Constant *campFinalize;

			// functions for load, store instructions
			Constant *campLoadInstr;
			Constant *campStoreInstr;

			// functions for context 
			Constant *campCallSiteBegin;
			Constant *campLoopBegin;


			void setFunctions(Module &M);
			void setIniFini(Module &M);

	};
}

#endif
