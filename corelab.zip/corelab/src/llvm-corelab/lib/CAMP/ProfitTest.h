#ifndef LLVM_CORELAB_CAMP_PROFIT_TEST_H
#define LLVM_CORELAB_CAMP_PROFIT_TEST_H

#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Constants.h"

#include "ContextTreeBuilder.h"

#include <fstream>
#include <map>

#ifndef DEBUG_TYPE
  #define DEBUG_TYPE "camp-profit-test"
#endif


namespace corelab
{
	using namespace llvm;
	using namespace std;

	class ProfitTest : public ModulePass
	{
		public:

			bool runOnModule(Module& M);

			virtual void getAnalysisUsage(AnalysisUsage &AU) const{
				AU.addRequired< ContextTreeBuilder >();
				AU.setPreservesAll();
			}

			const char *getPassName() const { return "camp-profit-test"; }

			static char ID;
			ProfitTest() : ModulePass(ID) {}

		private:
			
			Module *module;
			ContextTreeBuilder *cxtTreeBuilder;

			std::vector<ContextTreeNode *> *pCxtTree;

			//### Member variables for Context Tree Approach ###
			//this is given by ContextTreeBuilder pass
			LocIDMapForCallSite *locIdOf_callSite;  // if key is instrID of indirect call, then value is -1
			LocIDMapForIndirectCalls *locIdOf_indCall;
			LocIDMapForLoop *locIdOf_loop;

			/* Functions */

			// initialize, finalize functions
			Constant *campInitialize;
			Constant *campFinalize;

			// functions for context 
			Constant *campCallSiteBegin;
			Constant *campCallSiteEnd;
			Constant *campLoopBegin;
			Constant *campLoopNext;
			Constant *campLoopEnd;

			Constant *campDisableCtxtChange;
			Constant *campEnableCtxtChange;

			void setFunctions(Module &M);
			void setIniFini(Module &M);

			void addProfilingCodeForCallSite(Instruction *invokeOrCallInst, Value *locIDVal);
			void addProfilingCodeForLoop(Loop *loop, Value *locIDVal);
			Value *addTargetComparisonCodeForIndCall(const Instruction *invokeOrCallInst, std::vector<std::pair<Function *, LocalContextID>> &targetLocIDs);
	};
}

#endif
