#ifndef LLVM_CORELAB_CAMP_ACCESSED_MEM_SIZE_PROF_INSTALLER_CNT_H
#define LLVM_CORELAB_CAMP_ACCESSED_MEM_SIZE_PROF_INSTALLER_CNT_H

#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Constants.h"
#include "corelab/CAMP/ContextTreeBuilder.h"

#ifndef DEBUG_TYPE
  #define DEBUG_TYPE "accessed-mem-size-prof-installer"
#endif

namespace corelab
{
	using namespace llvm;
	using namespace std;

	class AccessedMemSizeProfInstaller : public ModulePass
	{
		public:
			typedef uint16_t InstrID;
			typedef uint32_t CampID;

			bool runOnModule(Module& M);

			virtual void getAnalysisUsage(AnalysisUsage &AU) const
			{
				// AU.addRequired< LoopInfoWrapperPass >();
				AU.addRequired< ContextTreeBuilder >();
				AU.addRequired< LoadNamer >();
				AU.setPreservesAll();
			}

			const char *getPassName() const { return "accessed-mem-size-prof-installer"; }

			static char ID;
			AccessedMemSizeProfInstaller() : ModulePass(ID) {}

		private:
			/* External Runtime Functions */

			// initialize, finalize functions
			Constant *amspInitialize;
			Constant *amspFinalize;

			// Constant *amspLoadInstr;
			Constant *amspStoreInstr;

			// functions for context 
			Constant *amspCallSiteBegin;
			Constant *amspCallSiteEnd;
			Constant *amspLoopBegin;
			// Constant *amspLoopNext;
			Constant *amspLoopEnd;

			// function for memory management
			// Constant *amspMalloc;
			// Constant *amspCalloc;
			// Constant *amspRealloc;
			// Constant *amspFree;

			//Context Change Enabler/disabler for Recursive Function
			Constant *amspDisableCtxtChange;
			Constant *amspEnableCtxtChange;

			/********************/
			/* private members */
			/******************/

			Module *module;
			LoadNamer *pLoadNamer;
			ContextTreeBuilder *cxtTreeBuilder;
			std::vector<ContextTreeNode *> *pCxtTree;

			//### Member variables for Context Tree Approach ###
			//this is given by ContextTreeBuilder pass
			LocIDMapForCallSite *locIdOf_callSite;  // if key is instrID of indirect call, then value is -1
			LocIDMapForIndirectCalls *locIdOf_indCall;
			LocIDMapForLoop *locIdOf_loop;

			void setFunctions(Module &M);
			void setIniFini(Module &M);

			void addProfilingCodeForLoop(Loop *L, Value *locIDVal);
			Value *addTargetComparisonCodeForIndCall(const Instruction *invokeOrCallInst, std::vector<std::pair<Function *, LocalContextID>> &targetLocIDs);
			void addProfilingCodeForCallSite(Instruction *invokeOrCallInst, Value *locIDVal);

	};
}

#endif //LLVM_CORELAB_CAMP_ACCESSED_MEM_SIZE_PROF_INSTALLER_CNT_H
