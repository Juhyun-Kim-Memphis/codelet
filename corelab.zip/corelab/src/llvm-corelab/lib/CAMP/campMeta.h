#ifndef CORELAB_CAMP_META_H
#define CORELAB_CAMP_META_H

#include "corelab/CAMP/campCommon.h"
#include <inttypes.h>

#endif	
