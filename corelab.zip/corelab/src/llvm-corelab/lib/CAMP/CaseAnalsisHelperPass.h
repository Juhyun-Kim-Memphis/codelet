#ifndef LLVM_CORELAB_CAMP_CASE_ANAL_HELPER_H
#define LLVM_CORELAB_CAMP_CASE_ANAL_HELPER_H

#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Constants.h"

namespace corelab
{
	using namespace llvm;
	using namespace std;

	class CaseAnalsisHelper : public ModulePass	{
		public:
			bool runOnModule(Module& M);

			virtual void getAnalysisUsage(AnalysisUsage &AU) const{
				// AU.addRequired< LoopInfoWrapperPass >();
				AU.setPreservesAll();
			}

			const char *getPassName() const { return "camp-call-cnt"; }

			static char ID;
			CaseAnalsisHelper() : ModulePass(ID) {}

		private:
			
			Module *module;
		
	};

}

#endif
