#include "llvm/Support/raw_ostream.h"
#include "llvm/Support/Debug.h"
#include "llvm/IR/Instructions.h"
#include "corelab/Utilities/GlobalCtors.h"
#include "corelab/Utilities/InstInsertPt.h"

#include "AccessedMemSizeProfInstaller.h"

using namespace corelab;

char AccessedMemSizeProfInstaller::ID = 0;
static RegisterPass<AccessedMemSizeProfInstaller> X("amsp-installer", "amsp-installer", false, false);

//Util
Value* castTo(Value* from, Value* to, InstInsertPt &out, const DataLayout *dl);
Instruction *getProloguePosition(Instruction *inst);
const Value *getCalledValueOfIndCall(const Instruction* indCall);

bool AccessedMemSizeProfInstaller::runOnModule(Module& M) {
	module = &M;
	setFunctions(M);
	DEBUG(errs()<<"############## runOnModule [AccessedMemSizeProfInstaller] START ##############\n");

	// initialize
	cxtTreeBuilder = &getAnalysis< ContextTreeBuilder >();
	pCxtTree = cxtTreeBuilder->getContextTree();
	locIdOf_callSite = cxtTreeBuilder->getLocIDMapForCallSite();
	locIdOf_indCall = cxtTreeBuilder->getLocIDMapForIndirectCalls();
	locIdOf_loop = cxtTreeBuilder->getLocIDMapForLoop();
	ContextTreeBuilder::LoopIdOf *loopIdOf = cxtTreeBuilder->getLoopIDMap();
	ContextTreeBuilder::LoopOfCntxID *loopOfLoopID = cxtTreeBuilder->getLoopMapOfCntxID();

	// ===================================== //
	// Instrument every Store Instructions
	// ===================================== //
	for(Module::iterator fi = M.begin(), fe = M.end(); fi != fe; ++fi) {
		Function &F = *fi;
		LLVMContext &Context = M.getContext();
		const DataLayout &dataLayout = module->getDataLayout();
		std::vector<Value*> args(0);
		if (F.isDeclaration()) continue;
		for (inst_iterator I = inst_begin(F), E = inst_end(F); I != E; ++I){
			Instruction *instruction = &*I; 
			// For each store instructions
			if (StoreInst *st = dyn_cast<StoreInst>(instruction)) {
				args.resize (3);
				Value *addr = st->getPointerOperand();
				Value *temp = ConstantInt::get(Type::getInt64Ty(Context), 0);
				InstInsertPt out = InstInsertPt::Before(st);
				addr = castTo(addr, temp, out, &dataLayout); 
				
				InstrID instrId = Namer::getInstrId(instruction);
				Value *instructionId = ConstantInt::get(Type::getInt16Ty(Context), instrId);
				//for debug
				
				Value *val = st->getValueOperand();
				Type *valTy = val->getType();
				uint64_t sizeInByte =dataLayout.getTypeStoreSize(valTy);
				assert(sizeInByte != 0 && "ERROR : spurious data type");
				Value *vSizeInByte = ConstantInt::get(Type::getInt16Ty(Context), static_cast<int16_t>(sizeInByte));

				args[0] = addr;
				args[1] = vSizeInByte;
				args[2] = instructionId;
				CallInst::Create(amspStoreInstr, args, "", st);			
			}
		}
	}


	// ===================================================== //
	// Instrument Context Change Code (loop, CallSite)
	// ===================================================== //
	for(std::pair<CntxID, const Loop *> loopID : *loopOfLoopID){
		Value *locIDVal = ConstantInt::get(Type::getInt16Ty(M.getContext()), (*locIdOf_loop)[loopID.first]);
		addProfilingCodeForLoop(const_cast<Loop *>(loopID.second), locIDVal);
	}

	for( std::pair<const Instruction *, std::vector<std::pair<Function *, LocalContextID>>> &indCall : *locIdOf_indCall){
		Value *locIDVal = addTargetComparisonCodeForIndCall(indCall.first, indCall.second);
		addProfilingCodeForCallSite(const_cast<Instruction *>(indCall.first), locIDVal);
	}

	for( std::pair<const Instruction *, LocalContextID> &normalCallSite : *locIdOf_callSite ){
		Value *locIDVal = ConstantInt::get(Type::getInt16Ty(M.getContext()), normalCallSite.second);
		addProfilingCodeForCallSite(const_cast<Instruction *>(normalCallSite.first), locIDVal);
	}

	DEBUG(errs()<<"############## runOnModule [AccessedMemSizeProfInstaller] END ##############\n");
	setIniFini(M);
	return false;
}

void AccessedMemSizeProfInstaller::setFunctions(Module &M)
{
	LLVMContext &Context = M.getContext();

	amspInitialize = M.getOrInsertFunction(
			"amspInitialize",
			Type::getVoidTy(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			Type::getInt64Ty(Context),
			(Type*)0);

	amspFinalize = M.getOrInsertFunction(
			"amspFinalize",
			Type::getVoidTy(Context),
			(Type*)0);

	amspStoreInstr = M.getOrInsertFunction(
			"amspStoreInstr",
			Type::getVoidTy(Context),
			Type::getInt64Ty(Context),
			Type::getInt16Ty(Context),
			Type::getInt16Ty(Context),
			(Type*)0);

	amspCallSiteBegin = M.getOrInsertFunction(
			"amspCallSiteBegin",
			Type::getVoidTy(Context),
			Type::getInt16Ty(Context),
			(Type*)0);

	amspCallSiteEnd = M.getOrInsertFunction(
			"amspCallSiteEnd",
			Type::getVoidTy(Context),
			Type::getInt16Ty(Context),
			(Type*)0);

	amspLoopBegin = M.getOrInsertFunction(
			"amspLoopBegin",
			Type::getVoidTy(Context),
			Type::getInt16Ty(Context),
			(Type*)0);

	amspLoopEnd = M.getOrInsertFunction(
			"amspLoopEnd",
			Type::getVoidTy(Context),
			Type::getInt16Ty(Context),
			(Type*)0);

	// amspMalloc = M.getOrInsertFunction(
	// 		"amspMalloc",
	// 		Type::getInt8PtrTy(Context),
	// 		Type::getInt64Ty(Context),
	// 		(Type*)0);

	// amspCalloc = M.getOrInsertFunction(
	// 		"amspCalloc",
	// 		Type::getInt8PtrTy(Context),
	// 		Type::getInt64Ty(Context),
	// 		Type::getInt64Ty(Context),
	// 		(Type*)0);

	// amspRealloc = M.getOrInsertFunction(
	// 		"amspRealloc",
	// 		Type::getInt8PtrTy(Context),
	// 		Type::getInt8PtrTy(Context),
	// 		Type::getInt64Ty(Context),
	// 		(Type*)0);

	// amspFree = M.getOrInsertFunction(
	// 		"amspFree",
	// 		Type::getVoidTy(Context),
	// 		Type::getInt8PtrTy(Context),
	// 		(Type*)0);

	amspDisableCtxtChange = M.getOrInsertFunction(
			"amspDisableCtxtChange",
			Type::getVoidTy(Context),
			(Type*)0);

	amspEnableCtxtChange = M.getOrInsertFunction(
			"amspEnableCtxtChange",
			Type::getVoidTy(Context),
			(Type*)0);

	return;
}

void AccessedMemSizeProfInstaller::setIniFini(Module& M)
{
	LLVMContext &Context = M.getContext();
	std::vector<Type*> formals(0);
	std::vector<Value*> actuals(0);
	FunctionType *voidFcnVoidType = FunctionType::get(Type::getVoidTy(Context), formals, false);

	/* initialize */
	Function *initForCtr = Function::Create( 
			voidFcnVoidType, GlobalValue::InternalLinkage, "__constructor__", &M); 
	BasicBlock *entry = BasicBlock::Create(Context,"entry", initForCtr); 
	BasicBlock *initBB = BasicBlock::Create(Context, "init", initForCtr); 
	actuals.resize(5);

	Value *loadCnt = ConstantInt::get(Type::getInt64Ty(Context), 0);
	Value *storeCnt = ConstantInt::get(Type::getInt64Ty(Context), 0);
	Value *callCnt = ConstantInt::get(Type::getInt64Ty(Context), 0);
	Value *loopCnt = ConstantInt::get(Type::getInt64Ty(Context), 0);
	Value *maxLoopDepthVal = ConstantInt::get(Type::getInt64Ty(Context), 0);
	actuals[0] = loadCnt;
	actuals[1] = storeCnt;
	actuals[2] = callCnt;
	actuals[3] = loopCnt;
	actuals[4] = maxLoopDepthVal;
	
	CallInst::Create(amspInitialize, actuals, "", entry); 
	BranchInst::Create(initBB, entry); 
	ReturnInst::Create(Context, 0, initBB);
	callBeforeMain(initForCtr);
	
	/* finalize */
	Function *finiForDtr = Function::Create(voidFcnVoidType, GlobalValue::InternalLinkage, "__destructor__",&M);
	BasicBlock *finiBB = BasicBlock::Create(Context, "entry", finiForDtr);
	BasicBlock *fini = BasicBlock::Create(Context, "fini", finiForDtr);
	actuals.resize(0);
	CallInst::Create(amspFinalize, actuals, "", fini);
	BranchInst::Create(fini, finiBB);
	ReturnInst::Create(Context, 0, fini);
	callAfterMain(finiForDtr);
}

void AccessedMemSizeProfInstaller::addProfilingCodeForLoop(Loop *L, Value *locIDVal){
	// get the pre-header, header and exitblocks
	BasicBlock *header = L->getHeader();
	BasicBlock *preHeader = L->getLoopPreheader();
	SmallVector<BasicBlock*, 1> exitingBlocks;
	L->getExitingBlocks(exitingBlocks);
	
	// set loopID as an argument
	std::vector<Value*> args(1); 

	// call beginLoop at the loop preheader
	// it will push the conext
	args.resize(1);
	args[0] = locIDVal; 
	assert(!preHeader->empty() && "ERROR: preheader of loop doesnt have TerminatorInst");
	CallInst::Create(amspLoopBegin, args, "", preHeader->getTerminator());

	// call endLoop at the exit blocks
	// it will pop the context
	int edgenum = 0;
	char edgeId[50];
	for (unsigned i = 0; i < exitingBlocks.size(); ++i)
	{
		BasicBlock *exitingBB = exitingBlocks[i];
		TerminatorInst *exitingTerm = exitingBB->getTerminator();
		unsigned int exitNum = exitingTerm->getNumSuccessors();
		unsigned int realExit = 0;
		for (unsigned int exit_i = 0; exit_i < exitNum; ++exit_i)
		{
			bool find = true;
			for (Loop::block_iterator bi = L->block_begin(), 
					be = L->block_end(); bi != be; ++bi)
			{
				BasicBlock *compare = (*bi);
				BasicBlock *target = exitingTerm->getSuccessor(exit_i);
				if (target == compare)
					find = false;
			}
			if(find)
			{
				++realExit;
				sprintf(edgeId, "edge%d", ++edgenum);

				BasicBlock *exitBB = exitingTerm->getSuccessor(exit_i);
				if(exitBB->isLandingPad())
				{
					bool isDominatedByLoop = std::all_of(pred_begin(exitBB), pred_end(exitBB), [L](BasicBlock *bb){return L->isLoopExiting(bb);});
					assert(isDominatedByLoop && "ERROR:: exitBB doesn't dominated by loop!");
					args.resize(1);
					args[0] = locIDVal;	
					Instruction *inst = exitBB->getFirstNonPHI();
					assert(exitBB->getLandingPadInst() == inst && "ERROR:: FirstNonPHI of LandingPad BB is not LandingPadinst!");
					assert(inst->getNextNode() && "ERROR:: next inst of LandingPadinst doesnt exists.");
					CallInst::Create(amspLoopEnd, args, "", inst->getNextNode());
				}
				else
				{
					BasicBlock *edgeBB = BasicBlock::Create(module->getContext(), edgeId,exitingBB->getParent());
					exitingTerm->setSuccessor(exit_i, edgeBB);
					BranchInst::Create(exitBB, edgeBB);
				
					for(BasicBlock::iterator ii = exitBB->begin(), 
							ie = exitBB->end(); ii != ie; ++ii) {
						Instruction *inst = &(*ii);
						if (inst->getOpcode()==Instruction::PHI) {
							PHINode *phiNode = (PHINode *)inst;
							for(unsigned int bi = 0; bi < phiNode->getNumIncomingValues();
									++bi) {
								if(phiNode->getIncomingBlock(bi) == exitingBB)
								{
									phiNode->setIncomingBlock(bi, edgeBB);
									break;
								}
							}
						}
					}
					args.resize(1);
					args[0] = locIDVal;	
					Instruction *inst = edgeBB->getFirstNonPHI();
					CallInst::Create(amspLoopEnd, args, "", inst);
				}// if exitBB is not LandingPad
			}
		}
	}
	// call beginIteration at the loop header
	// it will increase the iteration count of the loop
	args.resize(0);

	// CallInst::Create(amspLoopNext, args, "", header->getFirstNonPHI()); 
}

Value *AccessedMemSizeProfInstaller::addTargetComparisonCodeForIndCall(const Instruction *invokeOrCallInst, std::vector<std::pair<Function *, LocalContextID>> &targetLocIDs){
	assert(isa<InvokeInst>(invokeOrCallInst)||isa<CallInst>(invokeOrCallInst));
	assert((*locIdOf_callSite)[invokeOrCallInst] == (LocalContextID)(-1));

	LLVMContext &llvmContext = invokeOrCallInst->getModule()->getContext();
	const DataLayout &dataLayout = module->getDataLayout();
	Instruction *pInvokeOrCallInst = const_cast<Instruction *>(invokeOrCallInst);

	AllocaInst *locIDAddr = new AllocaInst(Type::getInt16Ty(llvmContext), "locID", getProloguePosition(const_cast<Instruction *>(invokeOrCallInst)));
	locIDAddr->setAlignment(sizeof(LocalContextID));

	BasicBlock* jumpHereAfterAssign =pInvokeOrCallInst->getParent()->splitBasicBlock(pInvokeOrCallInst, "AfterAssign."+locIDAddr->getName());

	TerminatorInst* insertCmpBeforehere = jumpHereAfterAssign->getSinglePredecessor()->getTerminator();
	pInvokeOrCallInst = jumpHereAfterAssign->getFirstNonPHI();

	Value *locIDVal = new LoadInst(locIDAddr, "Loaded."+locIDAddr->getName(), pInvokeOrCallInst);

	assert((locIDAddr && jumpHereAfterAssign && insertCmpBeforehere && locIDVal) && "ERROR: locIDAddrOf Map Error!!");

	//compare with this
	const Value *calledVal = getCalledValueOfIndCall(invokeOrCallInst);//same definition in ContextTreeBuilder.cpp

	//this loop will iterate by number of target candidate and make compare code(icmp, branch. basicblock)
	for(std::pair<Function *, LocalContextID> &targetLocID : targetLocIDs){
		Function *callee = targetLocID.first;
		Value *constLocID = ConstantInt::get(Type::getInt16Ty(llvmContext), targetLocID.second);

		//Amazingly, We can just compare (Function *) type with calledVal (may be Function pointer but how?)
		assert(const_cast<Value *>(calledVal)->getType() == callee->getType());
		ICmpInst* icmpInst = new ICmpInst(insertCmpBeforehere, ICmpInst::ICMP_EQ, const_cast<Value *>(calledVal), callee);

		BasicBlock *notMatchedBB=insertCmpBeforehere->getParent()->splitBasicBlock(insertCmpBeforehere, "NotMatched."+locIDAddr->getName()+"."+callee->getName());

		BasicBlock *locIDAssignBB = BasicBlock::Create(invokeOrCallInst->getModule()->getContext(), "locIDResolved."+locIDAddr->getName()+"."+callee->getName(), pInvokeOrCallInst->getParent()->getParent());
		new StoreInst(constLocID, locIDAddr, locIDAssignBB);
		BranchInst::Create(jumpHereAfterAssign, locIDAssignBB);

		//Replace unconditional branch to conditional branch
		assert(notMatchedBB->getSinglePredecessor()->getTerminator() == icmpInst->getNextNode() && "ERROR: next instruction of icmp is not BranchInst! ..1");
		assert(isa<BranchInst>(icmpInst->getNextNode()) && "ERROR: next instruction of icmp is not BranchInst! ..2");
		BasicBlock* branchInsertAtEnd = icmpInst->getNextNode()->getParent();
		assert(branchInsertAtEnd == notMatchedBB->getSinglePredecessor());
		icmpInst->getNextNode()->eraseFromParent();
		BranchInst::Create(locIDAssignBB, notMatchedBB, icmpInst, branchInsertAtEnd);
	}
	//addProfilingCodeForCallSite(pInvokeOrCallInst, locIDVal);
	return locIDVal;
}

void AccessedMemSizeProfInstaller::addProfilingCodeForCallSite(Instruction *invokeOrCallInst, Value *locIDVal){
	std::vector<Value*> args(0);
	args.resize(1);
	args[0] = locIDVal;

	Constant* ContextBegin = amspCallSiteBegin;
	Constant* ContextEnd = amspCallSiteEnd;

	CallInst::Create(ContextBegin, args, "", invokeOrCallInst);

	auto found = std::find_if(pCxtTree->begin(), pCxtTree->end(), [invokeOrCallInst](ContextTreeNode *p){return p->getCallInst() == invokeOrCallInst;});
	assert(found != pCxtTree->end());
	if((*found)->isRecursiveCallSiteNode()){
		std::vector<Value*> argsNone(0);
		argsNone.resize(0);
		CallInst::Create(amspDisableCtxtChange, argsNone, "", invokeOrCallInst);
	}

	assert((isa<InvokeInst>(invokeOrCallInst) && (!isa<TerminatorInst>(invokeOrCallInst))) == false && "WTF??");
	if(TerminatorInst *termInst = dyn_cast<TerminatorInst>(invokeOrCallInst)){

		if(isa<CallInst>(invokeOrCallInst)){
			CallInst *ci = CallInst::Create(ContextEnd, args, "", invokeOrCallInst->getParent());
			if((*found)->isRecursiveCallSiteNode()){
				std::vector<Value*> argsNone(0);
				argsNone.resize(0);
				CallInst::Create(amspEnableCtxtChange, argsNone, "", ci);
			}
		}
		else if(InvokeInst *invokeInst = dyn_cast<InvokeInst>(invokeOrCallInst)){
			//insert ConextEnd to two successors of invokeInst (normal, exception)
			assert(invokeInst->getNumSuccessors()==2 && "ERROR:: InvokeInst has more than 2 successors!");

			BasicBlock* normalDestBB = invokeInst->getNormalDest();
			CallInst *ci1 = CallInst::Create(ContextEnd, args, "", normalDestBB->getFirstNonPHI());

			BasicBlock* unwindDestBB = invokeInst->getUnwindDest();
			Instruction *landingPadInst = unwindDestBB->getFirstNonPHI();
			assert(landingPadInst == invokeInst->getLandingPadInst());
			assert(landingPadInst->getNextNode() && "ERROR:: next inst of landingPadInst doesn't exist.");
			//if this landingPadBB is exitBB of some Loop, insert ContextEnd before ContextEnd of Loop
			//because function exit(ret) happens first.
			CallInst *ci2 = CallInst::Create(ContextEnd, args, "", landingPadInst->getNextNode());
			if((*found)->isRecursiveCallSiteNode()){
				std::vector<Value*> argsNone(0);
				argsNone.resize(0);
				CallInst::Create(amspEnableCtxtChange, argsNone, "", ci1);
				CallInst::Create(amspEnableCtxtChange, argsNone, "", ci2);
			}
		}
		else
			assert(0&&"WTF?????");
	}
	else{
		assert(invokeOrCallInst->getNextNode() != NULL && "ERROR: next instruction of Non-TerminatorInst doesn't exist.");
		CallInst *ci = CallInst::Create(ContextEnd, args, "", invokeOrCallInst->getNextNode());

		if((*found)->isRecursiveCallSiteNode()){
			std::vector<Value*> argsNone(0);
			argsNone.resize(0);
			CallInst::Create(amspEnableCtxtChange, argsNone, "", ci);
		}

	}
}
