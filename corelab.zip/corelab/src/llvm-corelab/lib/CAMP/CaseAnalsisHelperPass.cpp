#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/CallSite.h"

#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/IR/Instructions.h"
#include "llvm/Support/Compiler.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Support/Debug.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/IR/CFG.h"
#include "llvm/IR/IRBuilder.h"

#include "llvm/Analysis/CallGraph.h"
#include "llvm/Analysis/LoopInfo.h"
#include "llvm/Analysis/LoopPass.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/Analysis/Passes.h"
#include "llvm/IR/DataLayout.h"
#include "llvm/IR/InstIterator.h"

#include "CaseAnalsisHelperPass.h"
#include "corelab/Utilities/InstInsertPt.h"
#include "corelab/Utilities/GlobalCtors.h"
#include "corelab/Metadata/Metadata.h"
#include "corelab/Metadata/LoadNamer.h"

#include <iostream>
#include <fstream>
#include <algorithm>    // std::for_each
#include <iterator>

using namespace corelab;

char CaseAnalsisHelper::ID = 0;
static RegisterPass<CaseAnalsisHelper> X("camp-case-anal-help", "camp-case-anal-help", false, false);

bool CaseAnalsisHelper::runOnModule(Module& M) {
	module = &M;
	errs()<<"############## runOnModule [CaseAnalsisHelper] START ##############\n";
	
	errs()<<"############## runOnModule [CaseAnalsisHelper] END ##############\n";
	return false;
}
