// Builds a conservative ICFG.
// It's not callsite-sensitive.

#ifndef __ICFG_BUILDER_H
#define __ICFG_BUILDER_H

#include <unordered_map>

#include "llvm/Pass.h"
#include "llvm/IR/CallSite.h"
#include "corelab/AliasAnalysis/IndirectCallAnal.hpp"
#include "corelab/Utilities/FindFunctionExitBB.hpp"
using namespace llvm;

#include "ICFG.hpp"

namespace corelab {
	struct ICFGBuilder: public ModulePass, public ICFG {
		typedef std::vector<const Instruction *> CSList; //CallSite : CallInstruction = 1 : 1 mathching
		typedef std::vector<const Instruction *> ExternalCallList;
		typedef std::vector<const Instruction *> IndirectCallList;
		typedef DenseMap<const Instruction *, CSList> RetToCallSites;

		// typedef std::unordered_map<Function *, std::vector<VID>> FunctionToVidList;

		public:
			static char ID;
			ICFGBuilder(): ModulePass(ID) {}
			virtual bool runOnModule(Module &M);

			virtual void getAnalysisUsage(AnalysisUsage &AU) const {
			  AU.addRequired< LoopInfoWrapperPass >();
			  AU.addRequired< IndirectCallAnal >();
			  AU.addRequired< FindFunctionExitBB >();
			  AU.addRequired< MicroBasicBlockBuilder >();
			  AU.setPreservesAll();
			  //AU.addRequired<CallGraphWrapperPass>();//AU.addRequired<FPCallGraph>();
			}
			
		private:
			void ignoreCall(Instruction *callOrInvoke, mbb_iterator &mbbi);
			void linkCallSite(Instruction *callOrInvoke, Function *fun, mbb_iterator &mbbi);

			FindFunctionExitBB *findFunctionExitBB;

			IndirectCallAnal::Matching possibleTargetOf;
			std::vector<const Instruction *> ignoredCalls;
	};
}

#endif