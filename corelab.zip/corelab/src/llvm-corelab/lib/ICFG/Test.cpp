#include "llvm/Analysis/CallGraph.h"
#include "llvm/IR/CFG.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/Support/raw_ostream.h"

#include "ICFGBuilder.hpp"
#include "util.hpp"
#include "corelab/Utilities/BGLutils.hpp"

void dumpICFG_toDOTFile(std::string, ICFG::Graph &g, ICFG::VidToMBB &vidToMBB);

using namespace corelab;
using namespace llvm;

namespace corelab {
	class ICFGTest: public ModulePass {
		public:
			static char ID;
			ICFGTest(): ModulePass(ID) {}
			void getAnalysisUsage(AnalysisUsage &AU) const;
			virtual bool runOnModule(Module &M);

			ICFG *icfg;

	};
}

void ICFGTest::getAnalysisUsage(AnalysisUsage &AU) const {
	AU.addRequired< ICFGBuilder >();
	AU.setPreservesAll();
}

bool ICFGTest::runOnModule(Module &M) {
	errs() << "\nSTART [ICFGTest::runOnModule]  #######\n";

	// ******* ICFG Test ********//
	icfg = &getAnalysis<ICFGBuilder>();
	errs() << "numNodes: "<< num_vertices(icfg->getBGLGraph()) << ", numEdges: "<<num_edges(icfg->getBGLGraph())<<"\n";

	dumpICFG_toDOTFile("test.dot", icfg->getBGLGraph(), icfg->getVidToMBB());

	errs() << "\nEND [ICFGTest::runOnModule]	#######\n";
	return false;
}

static RegisterPass<ICFGTest> Y("icfg-test", "ICFG Test", false, false);
char ICFGTest::ID = 0;