#include "llvm/Support/raw_ostream.h"

#include <boost/config.hpp>
#include <boost/property_map/property_map.hpp>
#include <boost/graph/graph_utility.hpp>
#include <boost/graph/graphviz.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/property_map/transform_value_property_map.hpp>

#include <algorithm>
#include <string>
#include <iostream>
#include "ICFG.hpp"

using namespace boost;

void dumpICFG_toDOTFile(std::string path, ICFG::Graph &g, ICFG::VidToMBB &vidToMBB){
	typedef ICFG::Graph Graph;
	typedef graph_traits<Graph>::vertex_descriptor Vertex;
	typedef graph_traits<Graph>::edge_descriptor Edge;
	// Graph& g(ptr_icfg->getBGLGraph());

	// // typedef typename property_map<Graph, VID ICFGVertexProp::*>::type VertexIDMap;
	ICFG::VertexIDMap vidMap = get(&ICFG::ICFGVertexProp::id, g);

	// +++++++ This code is deprecated +++++++ //
		// Make NameMap for using it as label of node. The name means the first instruction of MBB
		// typedef typename std::vector<std::string> NameMapImpl;
		// NameMapImpl nameMapImpl(num_vertices(g)+1); //TODO:: FIXME:: why should i add 1 ?????
		// typedef typename boost::iterator_property_map <NameMapImpl::iterator, ICFG::VertexIDMap> NameMap;
		// NameMap nameMap(nameMapImpl.begin(), vidMap);
		// graph_traits<Graph>::vertex_iterator i, end;
		// for (boost::tie(i,end) = vertices(g); i != end; ++i) {
		// 	// assert((vidToMBB)[vidMap[*i]] && "FATAL ERROR:: broken vidMap");
		// 	// raw_string_ostream rawOut(nameMap[*i]);
		// 	// (vidToMBB)[vidMap[*i]]->front().print(rawOut);
		// 	errs()<<"vidMap[*i] :"<<(vidToMBB)[vidMap[*i]]->front()<<"\n";
		// }

	std::ofstream dot_file(path, std::ios::out | std::ofstream::binary);
	assert(dot_file.is_open());

	// Define Graph attribute
	dot_file << "digraph D {\n"
			// << "  rankdir=LR\n"
			// << "  size=\"4,3\"\n"
			// << "  ratio=\"fill\"\n"
			// << "  node[shape=\"circle\"]\n"
			<< "  edge[style=\"bold\"]\n";

	//Draw Vertices
	graph_traits<Graph>::vertex_iterator i, end;
	for (boost::tie(i,end) = vertices(g); i != end; ++i) {
		std::string s;
		raw_string_ostream rawOut(s);
		(vidToMBB)[vidMap[*i]]->front().print(rawOut);

		dot_file << vidMap[*i]
				 << "[label=\""<<"<"<<vidMap[*i]<<">: "<< s <<"\"" //TODO:: need to remove ", align 4" at the end.
				 // << "[label=\""<< nameMap[*i] <<"\"" //TODO:: need to remove ", align 4" at the end.
				 // << ""
				 <<"]\n";		
	}

	//Draw Edges
	ICFG::EdgeIDMap eidMap = get(&ICFG::ICFGEdgeProp::id, g);
	ICFG::EdgeIter ei, eend;
	for (boost::tie(ei, eend) = edges(g); ei != eend; ++ei) {
		graph_traits < ICFG::Graph >::edge_descriptor e = *ei;
		graph_traits < ICFG::Graph >::vertex_descriptor u = source(e, g), v = target(e, g);
		dot_file << vidMap[u] << " -> " << vidMap[v]
				 << "[color=\"blue\"" 
				 <<"]\n";
	}

	dot_file << "}";
	dot_file.close();
}
