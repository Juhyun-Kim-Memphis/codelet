#include "ICFG.hpp"
using namespace corelab;

#include "llvm/Support/raw_ostream.h"
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>

using namespace llvm;


ICFGNode *ICFG::getOrInsertMBB(const MicroBasicBlock *mbb) {
  ICFGNode *&node = mbb_to_node[mbb];
  if (node)
    return node;

  //make new node 
  // errs()<<"Node add : "<<mbb->front()<<"\n";

  node = new ICFGNode(const_cast<MicroBasicBlock *>(mbb), this);
  nodes.push_back(node);
  VertexType v = add_vertex(ICFGVertexProp(nodes.size()-1), bglGraph);
  VertexIDMap idMap = get(&ICFGVertexProp::id, bglGraph);
  mbb_to_vid[mbb] = idMap[v];
  vid_to_mbb[mbb_to_vid[mbb]] = mbb;
  // errs()<<"inserting "<<idMap[v]<<"\n";
  return node;
}

void ICFGNode::print(raw_ostream &O) const {
  if (mbb == NULL)
    O << "<root>";
  else {
    const BasicBlock *bb = mbb->getParent();
    const Function *f = bb->getParent();
    O <<">"<< f->getName() << "." << bb->getName() << ".[" << mbb->front()<<"]";
    //<< ".[" << mbb->back()<<"]";
  }
}

void ICFG::addEdge(const MicroBasicBlock *x, const MicroBasicBlock *y) {
  ICFGNode *node_x = getOrInsertMBB(x);
  ICFGNode *node_y = getOrInsertMBB(y);
  node_x->addSuccessor(node_y);
  node_y->addPredecessor(node_x);

  // assert(mbb_to_vid[x] != )
  add_edge(vertex(mbb_to_vid[x], bglGraph), vertex(mbb_to_vid[y], bglGraph), ICFGEdgeProp(edgeCnt) , bglGraph);
  // errs()<<"inserting Edge "<<edgeCnt<<"\n";
  edgeCnt++;
}

void ICFG::printGraph(raw_ostream &O) const {
  O << "==========ICFG=========== "<< size()<<"\n";
  for (const_iterator x = begin(); x != end(); ++x) {
    for (ICFGNode::const_iterator si = x->succ_begin();
         si != x->succ_end(); ++si) {
      const ICFGNode *y = *si;
      printEdge(O, &*x, &*y);
    }
  }
  O << "=========================\n";
  
  //print all nodes
  //for (const_iterator x = begin(); x != end(); ++x) {x->print(O); O<<"\n";}
}

void ICFG::printEdge(raw_ostream &O, const ICFGNode *x, const ICFGNode *y) {
  x->print(O);
  O << " ==> ";
  y->print(O);
  O << "\n";
}

ICFGNode &ICFG::front() {
  ICFGNode *root = NULL;
  for (iterator ii = begin(); ii != end(); ++ii) {
    if (ii->pred_begin() == ii->pred_end()) {
      assert(!root);
      root = &*ii;
    }
  }
  assert(root);
  return *root;
}

const ICFGNode &ICFG::front() const {
  const ICFGNode *root = NULL;
  for (const_iterator ii = begin(); ii != end(); ++ii) {
    if (ii->pred_begin() == ii->pred_end()) {
      assert(!root);
      root = &*ii;
    }
  }
  assert(root);
  return *root;
}

