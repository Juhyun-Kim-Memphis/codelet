//Copyright (c) 2012, Jingyue Wu 
//https://github.com/wujingyue/rcs
// Similar to llvm::CallGraph
#ifndef __ICFG_H
#define __ICFG_H

#include <vector>
#include <unordered_map>
using namespace std;

#include "llvm/ADT/GraphTraits.h"
using namespace llvm;

#include "MicroBasicBlock.hpp"
using namespace corelab;

#include <boost/config.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/property_map/property_map.hpp>
#include <boost/graph/graph_utility.hpp>
#include <boost/graph/copy.hpp>
using namespace boost;

namespace corelab {
	struct ICFG;

	struct ICFGNode: public ilist_node<ICFGNode> {

	  typedef vector<ICFGNode *>::iterator iterator;
	  typedef vector<ICFGNode *>::const_iterator const_iterator;

	  ICFGNode(): mbb(NULL), parent(NULL) {}
	  ICFGNode(MicroBasicBlock *m, ICFG *p): mbb(m), parent(p) {}

	  iterator succ_begin() { return succs.begin(); }
	  iterator succ_end() { return succs.end(); }
	  const_iterator succ_begin() const { return succs.begin(); }
	  const_iterator succ_end() const { return succs.end(); }
	  iterator pred_begin() { return preds.begin(); }
	  iterator pred_end() { return preds.end(); }
	  const_iterator pred_begin() const { return preds.begin(); }
	  const_iterator pred_end() const { return preds.end(); }

	  MicroBasicBlock *getMBB() const { return mbb; }
	  const ICFG *getParent() const { return parent; }
	  ICFG *getParent() { return parent; }
	  unsigned size() const { return (unsigned)succs.size(); }
	  void addSuccessor(ICFGNode *succ) { succs.push_back(succ); }
	  void addPredecessor(ICFGNode *pred) { preds.push_back(pred); }
	  void print(raw_ostream &O) const;

	  inline bool operator==(const ICFGNode& other){return mbb == other.mbb;}
	  inline bool operator!=(const ICFGNode& other){return !(*this == other);}

	 private:
	  MicroBasicBlock *mbb;
	  // Need maintain successors and predecessors in order to implement
	  // GraphTraits<Inverse<ICFGNode *> >
	  vector<ICFGNode *> succs, preds;
	  ICFG *parent;
	};

	struct ICFG {

		typedef uint32_t VID;
		struct ICFGVertexProp{
			ICFGVertexProp(VID id):id(id){}
			ICFGVertexProp():id(0){}
			typedef VID value_type;
			VID id;
			
			boost::default_color_type color;
		};
		//Graph::vertex_property_type == ICFGVertexProp

		typedef uint32_t EID;
		struct ICFGEdgeProp{
			ICFGEdgeProp(EID id):id(id){}
			ICFGEdgeProp():id(0){}
			typedef EID value_type;
			EID id;	
		};
		//Graph::edge_property_type == ICFGEdgeProp

		//BGL boost graph library //ASSUME vertex_index_t == uint32_t TYPE
		// typedef adjacency_list<vecS, vecS, bidirectionalS, property<vertex_index_t, uint32_t>> Graph;
		typedef adjacency_list<vecS, listS, bidirectionalS, ICFGVertexProp, ICFGEdgeProp> Graph;
		// typedef typename boost::property_map<Graph, vertex_index_t>::type VertexIDMap;
		typedef typename property_map<Graph, VID ICFGVertexProp::*>::type VertexIDMap;
		typedef typename property_map<Graph, EID ICFGEdgeProp::*>::type EdgeIDMap;
		typedef typename boost::graph_traits < Graph >::vertex_descriptor VertexType;
		typedef typename boost::graph_traits < Graph >::edge_descriptor EdgeType;
		typedef typename boost::graph_traits < Graph >::vertex_iterator VertexIter;
		typedef typename boost::graph_traits < Graph >::edge_iterator EdgeIter;
		typedef typename graph_traits<Graph>::vertices_size_type SCCID;

		typedef DenseMap<const MicroBasicBlock *, ICFGNode *> MBBToNode;
		typedef DenseMap<const MicroBasicBlock *, VID> MBBToVid; 
		typedef std::unordered_map<VID, const MicroBasicBlock *> VidToMBB;
		typedef iplist<ICFGNode>::iterator iterator;
		typedef iplist<ICFGNode>::const_iterator const_iterator;

		ICFG() { 
			BOOST_CONCEPT_ASSERT(( VertexListGraphConcept< ICFG::Graph > ));
			BOOST_CONCEPT_ASSERT(( BidirectionalGraphConcept< ICFG::Graph > ));
			BOOST_CONCEPT_ASSERT(( MutableGraphConcept< ICFG::Graph > ));
			BOOST_CONCEPT_ASSERT((ReadWritePropertyMapConcept<ICFG::VertexIDMap, ICFG::VertexType>));
			BOOST_CONCEPT_ASSERT((ReadWritePropertyMapConcept<ICFG::EdgeIDMap, ICFG::EdgeType>));
			edgeCnt = 0; 
		}

		// Returns NULL if <mbb> is not in the ICFG. 
		const ICFGNode *operator[](const MicroBasicBlock *mbb) const {
			return mbb_to_node.lookup(mbb);
		}
		ICFGNode *operator[](const MicroBasicBlock *mbb) {
			return mbb_to_node.lookup(mbb);
		}

		iterator begin() { return nodes.begin(); }
		iterator end() { return nodes.end(); }
		const_iterator begin() const { return nodes.begin(); }
		const_iterator end() const { return nodes.end(); }
		ICFGNode &front();
		const ICFGNode &front() const;
		size_t size() const {
			assert(mbb_to_node.size() == nodes.size());
			assert(nodes.size() == num_vertices(bglGraph));
			return nodes.size();
		}

		/**
		* This must be the only interface to create a new node. 
		* <addEdge> calls <getOrInsertMBB>, so it's fine. 
		*/
		ICFGNode *getOrInsertMBB(const MicroBasicBlock *mbb);
		void addEdge(const MicroBasicBlock *x, const MicroBasicBlock *y); // x --> y

		// Print functions. 
		static void printEdge(raw_ostream &O, const ICFGNode *x, const ICFGNode *y);
		void printGraph(raw_ostream &O) const;

		MicroBasicBlockBuilder *getMicroBasicBlockBuilder(){return MBBB;}
		Graph& getBGLGraph(){return bglGraph;}
		VidToMBB& getVidToMBB(){return vid_to_mbb;}
		MBBToVid& getMBBToVid(){return mbb_to_vid;}
		std::vector< std::pair<MicroBasicBlock*, MicroBasicBlock*> >&getCallsiteAndCalleePairs(){return callsiteAndCalleePairs;}

	protected:
		MicroBasicBlockBuilder *MBBB;

	private:
		MBBToNode mbb_to_node;
		iplist<ICFGNode> nodes;

		//Inter-procedural infomation: edges of connecting callsite-callee
		std::vector< std::pair<MicroBasicBlock*, MicroBasicBlock*> > callsiteAndCalleePairs;

		//bglGraph, vid_to_mbb: These two should be used together.
		MBBToVid mbb_to_vid;
		VidToMBB vid_to_mbb;
		Graph bglGraph;
		uint32_t edgeCnt;
	};
} // namespace corelab 

namespace llvm {
template<>
struct GraphTraits<ICFGNode *> {
  typedef ICFGNode NodeType;
  typedef ICFGNode::iterator ChildIteratorType;

  static NodeType *getEntryNode(NodeType *node) { return node; }
  static ChildIteratorType child_begin(NodeType *x) { return x->succ_begin(); }
  static ChildIteratorType child_end(NodeType *x) { return x->succ_end(); }
};

template<>
struct GraphTraits<const ICFGNode *> {
  typedef const ICFGNode NodeType;
  typedef ICFGNode::const_iterator ChildIteratorType;

  static NodeType *getEntryNode(NodeType *node) { return node; }
  static ChildIteratorType child_begin(NodeType *x) { return x->succ_begin(); }
  static ChildIteratorType child_end(NodeType *x) { return x->succ_end(); }
};

template<>
struct GraphTraits<Inverse<ICFGNode *> > {
  typedef ICFGNode NodeType;
  typedef ICFGNode::iterator ChildIteratorType;

  static NodeType *getEntryNode(Inverse<NodeType *> node) {
    return node.Graph;
  }
  static ChildIteratorType child_begin(NodeType *x) { return x->pred_begin(); }
  static ChildIteratorType child_end(NodeType *x) { return x->pred_end(); }
};

template<>
struct GraphTraits<Inverse<const ICFGNode *> > {
  typedef const ICFGNode NodeType;
  typedef ICFGNode::const_iterator ChildIteratorType;

  static NodeType *getEntryNode(Inverse<NodeType *> node) {
    return node.Graph;
  }
  static ChildIteratorType child_begin(NodeType *x) { return x->pred_begin(); }
  static ChildIteratorType child_end(NodeType *x) { return x->pred_end(); }
};

template<>
struct GraphTraits<ICFG *>: public GraphTraits<ICFGNode *> {
  typedef ICFG::iterator nodes_iterator;
  static ICFGNode *getEntryNode(ICFG *icfg) { return &icfg->front(); }
  static nodes_iterator nodes_begin(ICFG *icfg) { return icfg->begin(); }
  static nodes_iterator nodes_end(ICFG *icfg) { return icfg->end(); }
  static unsigned size(ICFG *icfg) { return icfg->size(); }
};

template<>
struct GraphTraits<const ICFG *>: public GraphTraits<const ICFGNode *> {
  typedef ICFG::const_iterator nodes_iterator;
  static const ICFGNode *getEntryNode(const ICFG *icfg) {
    return &icfg->front();
  }
  static nodes_iterator nodes_begin(const ICFG *icfg) { return icfg->begin(); }
  static nodes_iterator nodes_end(const ICFG *icfg) { return icfg->end(); }
  static unsigned size(const ICFG *icfg) { return icfg->size(); }
};
}//namespace llvm

namespace boost {
	// typename graph_traits< ICFG::Graph >::vertex_descriptor
	// add_vertex(ICFG::Graph &g){
	// 	return add_vertex(ICFG::ICFGVertexProp(num_vertices(g)), g);
	// }
}//namespace boost

#endif
