#include "DataFlowGraph.hpp"
#include "llvm/IR/InstIterator.h"

#include <set>
#include <map>
#include <unordered_set>

//Use the Function defined at lib/ICFG/DrawGraphvizDOT.cpp (../ICFG/DrawGraphvizDOT.cpp)
void dumpICFG_toDOTFile(std::string, ICFG::Graph &g, ICFG::VidToMBB &vidToMBB);
void dumpDFG_toDOTFile(std::string path, DFG &dfg, DFGWithMemDataFlows::MemDataFlowEdgeSet *memDataFlowEdges = nullptr);

namespace corelab {
	class DFGTest: public ModulePass {
		public:
			static char ID;
			DFGTest(): ModulePass(ID) {}
			void getAnalysisUsage(AnalysisUsage &AU) const;
			virtual bool runOnModule(Module &M);

			Module *module;
			DataFlowGraphBuilder *dfgBuilder;

			void countMemFlowForEachFunction(DFGWithMemDataFlows &dfgMem); //For CallSite-ignorant
			void countMemFlowForEachCallSite(DFGWithMemDataFlows &dfgMem); //For CallSite-sensitive
	};
}

using namespace corelab;
using namespace llvm;

void DFGTest::getAnalysisUsage(AnalysisUsage &AU) const {
	AU.addRequired< DataFlowGraphBuilder >();
	AU.setPreservesAll();
}

bool DFGTest::runOnModule(Module &M) {
	errs() << "\nSTART [DFGTest::runOnModule]  #######\n";
	module = &M;

	//******* DFG Test ********//
	dfgBuilder = &getAnalysis<DataFlowGraphBuilder>();
	errs()<<"ICFG #N: "<<num_vertices(dfgBuilder->getICFG()->getBGLGraph())<<" #E: "<<num_edges(dfgBuilder->getICFG()->getBGLGraph())<<"\n";
	//dumpICFG_toDOTFile("icfgFromDFGTest.dot", dfgBuilder->getICFG()->getBGLGraph(), dfgBuilder->getICFG()->getVidToMBB());
	//dumpDFG_toDOTFile("dfg.dot", dfgBuilder->getDFG());

	DFGWithMemDataFlows dfgMem;
	dfgBuilder->AddReachableMemoryDataFlowUsingCFG(dfgMem, dfgBuilder->getICFG());
	// dfgBuilder->noMemoryDataFlow(dfgMem, dfgBuilder->getICFG());
	
	//dumpDFG_toDOTFile("dfgMem.dot", dfgMem, &dfgMem.getMemDataFlowEdges());	
	errs()<<"DFG #N: "<<num_vertices(dfgMem.getBGLGraph())<<" #E: "<<num_edges(dfgMem.getBGLGraph())<<"\n";

	if(dfgBuilder->isCallSiteSensitiveDFG())
		countMemFlowForEachCallSite(dfgMem);
	else
		countMemFlowForEachFunction(dfgMem);

	errs() << "\nEND [DFGTest::runOnModule]	#######\n";
	return false;
}


void DFGTest::countMemFlowForEachFunction(DFGWithMemDataFlows &dfgMem){
	assert((dfgBuilder->isCallSiteSensitiveDFG()==false) && "ERROR : this function should be called only when CallSite ignorant DFG");
	
	ICFG *cfg = dfgBuilder->getICFG();
	DataFlowGraphBuilder::ValueToVidList &valToVidList = dfgBuilder->getValueToVidList();
	Function *mainFcn = &*std::find_if(module->begin(), module->end(), [](Function &fi){return (fi.getName() == "main" && !fi.hasLocalLinkage());});

	for(Module::iterator fi = module->begin(), fe = module->end(); fi != fe; ++fi) {
		Function &F = *fi;
		
		if (F.isDeclaration()) continue;
		if (&F == mainFcn) continue;

		// 1. initialize statistic variable for a Function.
		std::vector<DFG::VID> vidSetInspected;
		std::map<DFG::VID, int> inEdgeCnter;
		std::map<DFG::VID, int> outEdgeCnter;

		// 2. Prepare Vertex Set for inspecting Memory flow 
		// llvm::Value appears only once.
		for (inst_iterator I = inst_begin(F), E = inst_end(F); I != E; ++I){
			Instruction *inst = &*I;
			assert((valToVidList[inst].size() == 1)&&"ERROR: llvm::Value must appears only once.");
			DFG::VID vid = valToVidList[inst].front();
			vidSetInspected.push_back(vid);
		}

		// 3. Count All the in-flows and out-flows.
		DFG::VertexIDMap vidMap = get(&DFG::VertexProp::id, dfgMem.getBGLGraph());
		DFG::EdgeIDMap eidMap = get(&DFG::EdgeProp::id, dfgMem.getBGLGraph());
		for(DFG::VID vid : vidSetInspected){
			//iterate in-edges and out-edges of this vertex vid
			DFG::InEdgeIter in_i, in_end;
			for (boost::tie(in_i, in_end) = in_edges(vertex(vid, dfgMem.getBGLGraph()), dfgMem.getBGLGraph()); in_i != in_end; ++in_i) {
				DFG::EdgeType e = *in_i;
				bool isMemDep = dfgMem.getMemDataFlowEdges().find(eidMap[e]) != dfgMem.getMemDataFlowEdges().end();

				DFG::VID srcVid = vidMap[source(e, dfgMem.getBGLGraph())];
				bool isFromInside = std::find(vidSetInspected.begin(), vidSetInspected.end(), srcVid) != vidSetInspected.end();

				// errs()<< "++.>"<<srcVid<<"... (isMemDep: "<<isMemDep<<"), (isInSide: "<< isFromInside <<")\n";
				if((isFromInside == false) && isMemDep)
					inEdgeCnter[vid]++;
			}

			DFG::OutEdgeIter out_i, out_end;
			for (boost::tie(out_i, out_end) = out_edges(vertex(vid, dfgMem.getBGLGraph()), dfgMem.getBGLGraph()); out_i != out_end; ++out_i) {
				DFG::EdgeType e = *out_i;
				bool isMemDep = dfgMem.getMemDataFlowEdges().find(eidMap[e]) != dfgMem.getMemDataFlowEdges().end();

				DFG::VID dstVid = vidMap[target(e, dfgMem.getBGLGraph())];
				bool isFromInside = std::find(vidSetInspected.begin(), vidSetInspected.end(), dstVid) != vidSetInspected.end();

				// errs()<< "++.>"<<dstVid<<"... (isMemDep: "<<isMemDep<<"), (isInSide: "<< isFromInside <<")\n";
				if((isFromInside == false) && isMemDep)
					outEdgeCnter[vid]++;
			}
		}

		int nInEdges=0;
		for(auto e: inEdgeCnter){
			nInEdges += e.second;
			//errs()<< "inEdges : "<< *dfgMem.getVidToValue()[e.first]<<", #: "<<e.second<<"\n";
		}
		int nOutEdges=0;
		for(auto e: outEdgeCnter){
			nOutEdges += e.second;
			//errs()<< "outEdges : "<< *dfgMem.getVidToValue()[e.first]<<", #: "<<e.second<<"\n";
		}
		errs()<<"[Function: "<<F.getName()<<"] in: "<<nInEdges<<", out: "<<nOutEdges<<"\n";
	}
}

void DFGTest::countMemFlowForEachCallSite(DFGWithMemDataFlows &dfgMem){
	assert(dfgBuilder->isCallSiteSensitiveDFG() && "ERROR : this function should be called only when CallSite Sensitive DFG");
	
	CSSICFGBuilder *cssICFG = static_cast<CSSICFGBuilder *>(dfgBuilder->getICFG());
	assert(cssICFG);
	DataFlowGraphBuilder::ValueToVidList &valToVidList = dfgBuilder->getValueToVidList();
	DataFlowGraphBuilder::VidToCSID &vidToCSID = dfgBuilder->getVidToCSID();


	for(auto e : cssICFG->getCallInfoMap()){
		CSSICFGBuilder::CallSiteIndex csid = e.first;
		Instruction *callOrInvoke = e.second.first;
		Function &F = *e.second.second;
		
		// 1. initialize statistic variable for a Function.
		std::vector<DFG::VID> vidSetInspected;
		std::map<DFG::VID, int> inEdgeCnter;
		std::map<DFG::VID, int> outEdgeCnter;

		// 2. Prepare Vertex Set for inspecting Memory flow 
		// llvm::Value appears only once.
		for (inst_iterator I = inst_begin(F), E = inst_end(F); I != E; ++I){
			Instruction *inst = &*I;
			for(auto vid : valToVidList[inst]){
				if(csid == vidToCSID[vid])
					vidSetInspected.push_back(vid);
			}
		}

		// 3. prepare visited node memo to exclude visited value (TODO: is it fare?)
		std::unordered_set<DFG::VID> visitedSrc;
		std::unordered_set<DFG::VID> visitedDst;

		// 4. Count All the in-flows and out-flows.
		DFG::VertexIDMap vidMap = get(&DFG::VertexProp::id, dfgMem.getBGLGraph());
		DFG::EdgeIDMap eidMap = get(&DFG::EdgeProp::id, dfgMem.getBGLGraph());
		for(DFG::VID vid : vidSetInspected){
			//iterate in-edges and out-edges of this vertex vid
			DFG::InEdgeIter in_i, in_end;
			for (boost::tie(in_i, in_end) = in_edges(vertex(vid, dfgMem.getBGLGraph()), dfgMem.getBGLGraph()); in_i != in_end; ++in_i) {
				DFG::EdgeType e = *in_i;
				DFG::VID srcVid = vidMap[source(e, dfgMem.getBGLGraph())];
				bool beenVisited = visitedSrc.find(srcVid) != visitedSrc.end();
				
				if(beenVisited == false){
					visitedSrc.insert(srcVid);

					bool isMemDep = dfgMem.getMemDataFlowEdges().find(eidMap[e]) != dfgMem.getMemDataFlowEdges().end();

					bool isFromInside = std::find(vidSetInspected.begin(), vidSetInspected.end(), srcVid) != vidSetInspected.end();

					// errs()<< "++.>"<<srcVid<<"... (isMemDep: "<<isMemDep<<"), (isInSide: "<< isFromInside <<")\n";
					if((isFromInside == false) && isMemDep)
						inEdgeCnter[vid]++;
				}
			}

			DFG::OutEdgeIter out_i, out_end;
			for (boost::tie(out_i, out_end) = out_edges(vertex(vid, dfgMem.getBGLGraph()), dfgMem.getBGLGraph()); out_i != out_end; ++out_i) {
				DFG::EdgeType e = *out_i;
				DFG::VID dstVid = vidMap[target(e, dfgMem.getBGLGraph())];
				bool beenVisited = visitedSrc.find(dstVid) != visitedSrc.end();

				if(beenVisited == false){
					visitedSrc.insert(dstVid);
					bool isMemDep = dfgMem.getMemDataFlowEdges().find(eidMap[e]) != dfgMem.getMemDataFlowEdges().end();

					bool isFromInside = std::find(vidSetInspected.begin(), vidSetInspected.end(), dstVid) != vidSetInspected.end();

					// errs()<< "++.>"<<dstVid<<"... (isMemDep: "<<isMemDep<<"), (isInSide: "<< isFromInside <<")\n";
					if((isFromInside == false) && isMemDep)
						outEdgeCnter[vid]++;
				}
			}
		}

		int nInEdges=0;
		for(auto e: inEdgeCnter){
			nInEdges += e.second;
			//errs()<< "inEdges : "<< *dfgMem.getVidToValue()[e.first]<<", #: "<<e.second<<"\n";
		}
		int nOutEdges=0;
		for(auto e: outEdgeCnter){
			nOutEdges += e.second;
			//errs()<< "outEdges : "<< *dfgMem.getVidToValue()[e.first]<<", #: "<<e.second<<"\n";
		}
		errs()<<"[Call: "<<*callOrInvoke<<" , Function: "<<F.getName()<<"] in: "<<nInEdges<<", out: "<<nOutEdges<<"\n";

	}
	

}



static RegisterPass<DFGTest> Y("dfg-test", "DFG Test", false, false);
char DFGTest::ID = 0;

