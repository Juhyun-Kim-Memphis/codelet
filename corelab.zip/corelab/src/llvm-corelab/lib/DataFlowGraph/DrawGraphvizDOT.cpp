#include <boost/config.hpp>
#include <boost/property_map/property_map.hpp>
#include <boost/graph/graph_utility.hpp>
#include <boost/graph/graphviz.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/property_map/transform_value_property_map.hpp>

#include <algorithm>
#include <string>
#include <iostream>
#include "DataFlowGraph.hpp"
#include "llvm/Support/raw_ostream.h"

using namespace boost;

//TODO: make to make this generally appilicable to all Graph
void dumpDFG_toDOTFile(std::string path, DFG &dfg, DFGWithMemDataFlows::MemDataFlowEdgeSet *memDataFlowEdges = nullptr){
	bool isMemEdgeDrawable = memDataFlowEdges ? true : false;
	DFG::Graph &g = dfg.getBGLGraph();
	DFG::VidToValue &vidToVal = dfg.getVidToValue();

	DFG::VertexIDMap vidMap = get(&DFG::VertexProp::id, g);

	// // Make ValueName Map for using it as label of node (deprecated)
	// typedef typename std::vector<std::string> ValueNameMapImpl;
	// ValueNameMapImpl valNameMapImpl(num_vertices(g));//(num_vertices(g))  
	// typedef typename boost::iterator_property_map <ValueNameMapImpl::iterator, DFG::VertexIDMap> ValueNameMap;
	// ValueNameMap valNameMap(valNameMapImpl.begin(), vidMap);
	// for (boost::tie(i,end) = vertices(g); i != end; ++i) {
	// 	raw_string_ostream rawOut(valNameMap[*i]);
	// 	vidToVal[vidMap[*i]]->print(rawOut);
	// }

	std::ofstream dot_file(path, std::ios::out | std::ofstream::binary);
	assert(dot_file.is_open());
	
	// Define Graph attribute
	dot_file << "digraph D {\n"
			// << "  rankdir=LR\n"
			// << "  size=\"4,3\"\n"
			// << "  ratio=\"fill\"\n"
			// << "  node[shape=\"circle\"]\n"
			<< "  edge[style=\"bold\"]\n";

	DFG::VertexIter i, end;
	//Draw Vertices
	for (boost::tie(i,end) = vertices(g); i != end; ++i) {
		std::string s;
		raw_string_ostream rawOut(s);
		vidToVal[vidMap[*i]]->print(rawOut);

		dot_file << vidMap[*i]
				 << "[label=\"" << "<"<<vidMap[*i] <<">: "<< s <<"\"" //TODO:: need to remove ", align 4" at the end.
				 // << ""
				 <<"]\n";		
	}

	//Draw Edges
	DFG::EdgeIDMap eidMap = get(&DFG::EdgeProp::id, g);
	DFG::EdgeIter ei, eend;
	for (boost::tie(ei, eend) = edges(g); ei != eend; ++ei) {
		graph_traits < DFG::Graph >::edge_descriptor e = *ei;
		graph_traits < DFG::Graph >::vertex_descriptor u = source(e, g), v = target(e, g);
		
		bool isMemFlow = false;
		if(isMemEdgeDrawable)
			isMemFlow = memDataFlowEdges->find(eidMap[e]) != memDataFlowEdges->end();
		
		dot_file << vidMap[u] << " -> " << vidMap[v] <<"["
				 // << "[color=\"blue\"" 
				 << (isMemFlow ? "color=\"blue\", style=\"dotted\"" : "")
				 <<"]\n";
	}

	dot_file << "}";
	dot_file.close();
}


// graph_traits<DFG>::vertex_iterator i, end;
// for (boost::tie(i,end) = vertices(dfg); i != end; ++i) {
// 	// errs() << idMap[*i] << ", "<< *outputValMap[*i] <<" uses:";
// 	make_label_writer(idMap)(std::cout, *i);
// 	graph_traits<DFG>::out_edge_iterator ei, ei_end;
// 	for (boost::tie(ei, ei_end) = out_edges(*i, dfg); ei != ei_end; ei++)
// 		make_label_writer(edgeNameMap)(std::cout, *ei);
// }