
#include "DataFlowGraph.hpp"
#include "corelab/Utilities/BGLutils.hpp"

void DataFlowGraphBuilder::AddAllConservativeMemoryDataFlow(DFGWithMemDataFlows &inOutDFG){
	//Graph copy
	assert((num_vertices(inOutDFG.getBGLGraph()) == 0 && inOutDFG.getVidToValue().size() == 0 && inOutDFG.getMemDataFlowEdges().size() == 0));
	DFG::Graph& g = inOutDFG.getBGLGraph(); //copied DFG
	DFG::VidToValue &vidToVal = inOutDFG.getVidToValue();
	DFG::VertexIDMap vidMapOri = get(&DFG::VertexProp::id, dfg.getBGLGraph());
	copy_graph(dfg.getBGLGraph(), g, vertex_index_map(vidMapOri));
	vidToVal.insert(dfg.getVidToValue().begin(), dfg.getVidToValue().end());
	DFG::VertexIDMap vidMap = get(&DFG::VertexProp::id, g);
	
	auto &memDataFlowEdges = inOutDFG.getMemDataFlowEdges();//set of RAW(Store -> Load) edges by memory data flow.

	//Add edges
	//1. find edge Store->Load Pairs in DFG
	std::unordered_set<DFG::VID> loadSet;
	std::unordered_set<DFG::VID> storeSet;
	for(auto e: vidToVal){
		// errs()<<".. "<<*e.second<<"\n";
		if(isa<LoadInst>(e.second))
			loadSet.insert(e.first);
		else if(isa<StoreInst>(e.second))
			storeSet.insert(e.first);
	}
	// errs()<<"nLoad: "<<loadSet.size()<<", nStore: "<<storeSet.size()<<", nStoreLoadPairs: "<<loadSet.size()*storeSet.size()<<"\n";

	//2. Add edges
	assert(num_edges(g) != 0);
	DFG::EID eidCnt = num_edges(g);
	for(auto vidSt : storeSet){
		for(auto vidLd : loadSet){
			add_edge(vertex(vidSt, g), vertex(vidLd, g), DFG::EdgeProp(eidCnt), g);
			memDataFlowEdges.insert(eidCnt);
			eidCnt++;
		}
	}
}

void DataFlowGraphBuilder::AddReachableMemoryDataFlowUsingCFG(DFGWithMemDataFlows &outDFG, ICFG *inCFG){
	//Graph copy
	assert((num_vertices(outDFG.getBGLGraph()) == 0 && outDFG.getVidToValue().size() == 0 && outDFG.getMemDataFlowEdges().size() == 0));
	DFG::Graph& g = outDFG.getBGLGraph(); //copied DFG
	DFG::VidToValue &vidToVal = outDFG.getVidToValue();
	DFG::VertexIDMap vidMapOri = get(&DFG::VertexProp::id, dfg.getBGLGraph());
	copy_graph(dfg.getBGLGraph(), g, vertex_index_map(vidMapOri));
	vidToVal.insert(dfg.getVidToValue().begin(), dfg.getVidToValue().end());
	DFG::VertexIDMap vidMap = get(&DFG::VertexProp::id, g);
	
	auto &memDataFlowEdges = outDFG.getMemDataFlowEdges();//set of RAW(Store -> Load) edges by memory data flow.

	//Add edges
	//1. find edge Store->Load Pairs in DFG
	std::unordered_set<DFG::VID> loadSet;
	std::unordered_set<DFG::VID> storeSet;
	for(auto e: vidToVal){
		// errs()<<".. "<<*e.second<<"\n";
		if(isa<LoadInst>(e.second))
			loadSet.insert(e.first);
		else if(isa<StoreInst>(e.second))
			storeSet.insert(e.first);
	}
	// errs()<<"nLoad: "<<loadSet.size()<<", nStore: "<<storeSet.size()<<", nStoreLoadPairs: "<<loadSet.size()*storeSet.size()<<"\n";

	//2. initialize CFG related things.
	ICFG::MBBToVid& mbbToVid = inCFG->getMBBToVid();
	//ICFG::VertexIDMap vidMapCFG = get(&ICFG::ICFGVertexProp::id, inCFG->getBGLGraph());
	//print_graph(inCFG->getBGLGraph(), vidMapCFG);

	//3. Add edges
	assert(num_edges(g) != 0);
	DFG::EID eidCnt = num_edges(g);
	for(auto vidSt : storeSet){
		for(auto vidLd : loadSet){
			bool isReachable = bgl_isReachable(dfg2icfg[vidSt], dfg2icfg[vidLd], inCFG->getBGLGraph());
			if(isReachable){
				add_edge(vertex(vidSt, g), vertex(vidLd, g), DFG::EdgeProp(eidCnt), g);
				memDataFlowEdges.insert(eidCnt);
				eidCnt++;
			}
		}
	}
}

void DataFlowGraphBuilder::noMemoryDataFlow(DFGWithMemDataFlows &outDFG, ICFG *inCFG){
	//Graph copy
	assert((num_vertices(outDFG.getBGLGraph()) == 0 && outDFG.getVidToValue().size() == 0 && outDFG.getMemDataFlowEdges().size() == 0));
	DFG::Graph& g = outDFG.getBGLGraph(); //copied DFG
	DFG::VidToValue &vidToVal = outDFG.getVidToValue();
	DFG::VertexIDMap vidMapOri = get(&DFG::VertexProp::id, dfg.getBGLGraph());
	copy_graph(dfg.getBGLGraph(), g, vertex_index_map(vidMapOri));
	vidToVal.insert(dfg.getVidToValue().begin(), dfg.getVidToValue().end());
}