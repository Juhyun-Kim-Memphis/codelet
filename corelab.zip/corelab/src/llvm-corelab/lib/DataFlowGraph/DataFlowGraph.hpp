#ifndef __DATAFLOWGRAPH_BUILDER_H
#define __DATAFLOWGRAPH_BUILDER_H

#include "llvm/Pass.h"
#include "llvm/IR/CallSite.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/Support/raw_ostream.h"

#include "corelab/Utilities/FindFunctionExitBB.hpp"
#include "corelab/ICFG/ICFGBuilder.hpp"
#include "corelab/ICFG/util.hpp"
#include "corelab/CallSiteSensitive/CallSiteSensitiveCFG.hpp"

#include <unordered_map>
#include <unordered_set>

#include <boost/config.hpp>
#include <boost/graph/adjacency_list.hpp>
using namespace llvm;

namespace corelab {

	using namespace boost;
	
	class DFGWithMemDataFlows;

	// DataFlowGraph
	class DFG{  
	public:
		typedef uint32_t VID; //Vertex ID
		typedef uint32_t EID; //Edge ID

		struct EdgeProp {
			EdgeProp(VID id) : id(id) {}
			EdgeProp() : id(0) {}
			typedef VID value_type;
			VID id;
		};

		struct VertexProp {
			VertexProp(EID id) : id(id) {}
			VertexProp() : id(0) {}
			typedef EID value_type;
			EID id;
		};

		//BGL boost graph library //ASSUME vertex_index_t == uint32_t TYPE
		// typedef adjacency_list<vecS, vecS, bidirectionalS, property<vertex_index_t, uint32_t>> Graph;
		typedef adjacency_list<vecS, listS, bidirectionalS, VertexProp, EdgeProp> Graph;
		typedef typename property_map<Graph, VID VertexProp::*>::type VertexIDMap;
		typedef typename property_map<Graph, EID EdgeProp::*>::type EdgeIDMap;
		typedef typename boost::graph_traits < Graph >::out_edge_iterator OutEdgeIter;
		typedef typename boost::graph_traits < Graph >::in_edge_iterator InEdgeIter;
		typedef typename boost::graph_traits < Graph >::vertex_descriptor VertexType;
		typedef typename boost::graph_traits < Graph >::edge_descriptor EdgeType;
		typedef typename boost::graph_traits < Graph >::vertex_iterator VertexIter;
		typedef typename boost::graph_traits < Graph >::edge_iterator EdgeIter;

		// Each node has input and output data ports
		// input: in edges
		// output: llvm::Value (in external property map)
		typedef std::unordered_map<VID, const llvm::Value*> VidToValue;

		Graph& getBGLGraph(){return bglGraph;}
		VidToValue& getVidToValue(){return vidToValue;}

	private:
		Graph bglGraph;
		VidToValue vidToValue;
	};

	class DataFlowGraphBuilder: public ModulePass {
		public:
			//giving Callsite-awareness !!
			typedef int32_t CallSiteID;
			typedef std::unordered_map<DFG::VID, CallSiteID> VidToCSID;// tells position which function call it is in, main:0, none: -1

			typedef typename std::unordered_map<DFG::VID, ICFG::VID> DFGvidToICFGvid;
			typedef typename std::unordered_map<const llvm::Value *, std::vector<DFG::VID>> ValueToVidList;

			static char ID;
			DataFlowGraphBuilder(): ModulePass(ID) {}
			void getAnalysisUsage(AnalysisUsage &AU) const;
			virtual bool runOnModule(Module &M);

			void makeCallSiteSensitiveDataflowGraph();
			void makeCallSiteInsensitiveDataflowGraph();

			void AddAllConservativeMemoryDataFlow(DFGWithMemDataFlows &inOutDFG);
			void AddReachableMemoryDataFlowUsingCFG(DFGWithMemDataFlows &outDFG, ICFG *inCFG);
			void noMemoryDataFlow(DFGWithMemDataFlows &outDFG, ICFG *inCFG);
			
			DFG& getDFG(){return dfg;}
			ICFG* getICFG(){return icfg;}
			DFGvidToICFGvid &getDFGvidToICFGvid(){return dfg2icfg;}
			bool isCallSiteSensitiveDFG(){return isCSS;}

			ValueToVidList& getValueToVidList(){return vIDListOfVal;}
			VidToCSID& getVidToCSID(){return vidToCSID;}

		private:
			void handleCallInstCalleePair(MicroBasicBlock *callInstMBB, MicroBasicBlock *calleeMBB, bool isCallSiteSensitive);

			ICFG *icfg;
			DFGvidToICFGvid dfg2icfg;

			Module *module;
			FindFunctionExitBB *findFunctionExitBB;

			DFG dfg;
			bool isCSS;//isCallSiteSensitive?

			//giving Callsite-awareness !!
			ValueToVidList vIDListOfVal;
			VidToCSID vidToCSID;
	};

	class DFGWithMemDataFlows : public DFG {
	public: 
		typedef typename std::unordered_set<DFG::EID> MemDataFlowEdgeSet;
		MemDataFlowEdgeSet& getMemDataFlowEdges(){ return memDataFlowEdges; }
	private:
		MemDataFlowEdgeSet memDataFlowEdges;
	};


	static inline bool isRetInst(const Instruction *I) {
		return isa<ReturnInst>(I) || isa<ResumeInst>(I);
	}


}

#endif //__DATAFLOWGRAPH_BUILDER_H