#include <stdio.h>
#include <iostream>
#include "campRuntime.h"

//#define CAMPID_BASED
#define CTXID_BASED
#define SAMPLING_THRESHOLD 50

static CntxID currentCtx;
//for Sampling
#ifdef CTXID_BASED
static uint16_t sampling; //doesn't do anything when 0xFFFF;
static IterStack globalIterStack;
static int globalIterStackIdx;
static int globalIterStackIdx_overflow;

#endif

#ifdef CAMPID_BASED
typedef std::map<CampID, uint8_t> CampIDCounterMap; //for sampling
static CampIDCounterMap campIDCntMap;
static void printCampIDCounterMap();
#endif

static uint64_t nSampledStoreInvo; //sampling ratio stat
static uint64_t nSampledLoadInvo; //sampling ratio stat
static uint64_t nStoreInvo; //sampling ratio stat
static uint64_t nLoadInvo; //sampling ratio stat

static uint64_t nCallSiteInvo; //sampling ratio stat
static uint64_t nLoopInvo; //sampling ratio stat


// Initializer/Finalizer
extern "C"
void campInitialize (size_t ldrCnt, size_t strCnt, size_t callCnt, size_t loopCnt, size_t maxLoopDepth) {
	#ifdef CTXID_BASED
	sampling = 0x00000000;
	globalIterStackIdx = -1;
	currentCtx = 0;
	for (int i = 0; i < STK_MAX_SIZE_DIV_BY_8; ++i)
		globalIterStack.i64[i] = 0;
	#endif	

	nSampledStoreInvo = 0; //sampling ratio stat
	nSampledLoadInvo = 0; //sampling ratio stat
	nStoreInvo = 0; //sampling ratio stat
	nLoadInvo = 0; //sampling ratio stat

	nCallSiteInvo=0;
	nLoopInvo=0;

	fprintf(stderr,"sizeof void* %lu,  IterRelation size:%lu, CampID %lu \n", sizeof(void*), sizeof(IterRelation), sizeof(CampID));
}

extern "C"
void campFinalize () {
	//printCampIDCounterMap();
	#ifdef CAMPID_BASED
	fprintf(stderr," # of campID: %lu\n", campIDCntMap.size());
	#endif
	#ifdef CAMPID_BASED
	fprintf(stderr,"CampID based(threshold: %d): nSampledStoreInvo:%d, nSampledLoadInvo:%d, nStoreInvo:%d, nLoadInvo:%d, \n"
		, SAMPLING_THRESHOLD,nSampledStoreInvo ,nSampledLoadInvo ,nStoreInvo ,nLoadInvo ); //sampling ratio stat
	fprintf(stderr,"ContextID base: totalLoadStore:%d, SampledLoadStore:%d, ratio: %lf\n"
		,nStoreInvo+nLoadInvo, nSampledStoreInvo+nSampledLoadInvo , (((double)(nSampledStoreInvo+nSampledLoadInvo))/((double)(nStoreInvo+nLoadInvo)))*100); //sampling ratio stat
	fprintf(stderr,"CampID based: Load Sampling ratio: %lf\n"
		,(((double)(nSampledLoadInvo))/((double)(nLoadInvo)))*100); //sampling ratio stat
	fprintf(stderr,"CampID based: Store Sampling ratio: %lf\n"
		,(((double)(nSampledStoreInvo))/((double)(nStoreInvo)))*100); //sampling ratio stat
	#endif
	#ifdef CTXID_BASED

	fprintf(stderr,"ContextID base(threshold: %d): nSampledStoreInvo:%ld, nSampledLoadInvo:%ld, nStoreInvo:%ld, nLoadInvo:%ld, nCallSiteInvo:%ld, nLoopInvo:%ld \n"
		, SAMPLING_THRESHOLD,nSampledStoreInvo ,nSampledLoadInvo ,nStoreInvo ,nLoadInvo, nCallSiteInvo, nLoopInvo ); //sampling ratio stat
	fprintf(stderr,"ContextID base: totalLoadStore:%ld, SampledLoadStore:%ld, ratio: %lf\n"
		,nStoreInvo+nLoadInvo, nSampledStoreInvo+nSampledLoadInvo , (((double)(nSampledStoreInvo+nSampledLoadInvo))/((double)(nStoreInvo+nLoadInvo)))*100); //sampling ratio stat
	fprintf(stderr,"CampID based: Load Sampling ratio: %lf\n"
		,(((double)(nSampledLoadInvo))/((double)(nLoadInvo)))*100); //sampling ratio stat
	fprintf(stderr,"CampID based: Store Sampling ratio: %lf\n"
		,(((double)(nSampledStoreInvo))/((double)(nStoreInvo)))*100); //sampling ratio stat
	#endif

}

// Normal Context Event
extern "C"
void campLoopBegin (CntxID cntxID) {
	currentCtx += cntxID;
	nLoopInvo++;

	#ifdef CTXID_BASED
	if(globalIterStackIdx >= STK_MAX_SIZE-1)
		globalIterStackIdx_overflow++;
	else{
		globalIterStackIdx++;

		globalIterStack.i8[globalIterStackIdx] = 0;
		sampling &= ((0x01 << globalIterStackIdx)^sampling); //make the corresponding bit 0
	}

	#endif
}

extern "C"
void campLoopNext () {
	#ifdef CTXID_BASED

	if(sampling == 0x00000000){
		globalIterStack.i8[globalIterStackIdx] = (globalIterStack.i8[globalIterStackIdx]+1) & 0x7f;
		if(globalIterStack.i8[globalIterStackIdx]>SAMPLING_THRESHOLD) sampling |= (0x01 << globalIterStackIdx);
	}
	#endif
}

extern "C"
void campLoopEnd (CntxID cntxID) {

	currentCtx -= cntxID;


	#ifdef CTXID_BASED
	if(globalIterStackIdx_overflow > -1)
		globalIterStackIdx_overflow--;
	else{
		globalIterStack.i8[globalIterStackIdx] = 0;
		sampling &= ((0x01 << globalIterStackIdx)^sampling);

		globalIterStackIdx--;
	}


	#endif
}

extern "C"
void campCallSiteBegin (CntxID cntxID) {
	currentCtx += cntxID;
	nCallSiteInvo++;

	#ifdef CTXID_BASED

	#endif
}

extern "C"
void campCallSiteEnd  (CntxID cntxID) {
	currentCtx -= cntxID;

	#ifdef CTXID_BASED

	#endif
}

// Memory Event
extern "C"
void campLoadInstr (void* addr, InstrID instrID) {
	nLoadInvo++; //sampling ratio stat

	#ifdef CAMPID_BASED
	//incrase counter of corresponding campID (for Sampling)
	CampID campID = currentCtx << 16 | instrID;
	//CampID based
	if(campIDCntMap[campID] > SAMPLING_THRESHOLD) return;
	campIDCntMap[campID]++;
	#endif


	#ifdef CTXID_BASED
	if(sampling != 0x00000000) return;//Context ID based
	#endif

	nSampledLoadInvo++; //sampling ratio stat
}

extern "C"
void campStoreInstr (void* addr, InstrID instrID) {
	nStoreInvo++; //sampling ratio stat

	#ifdef CAMPID_BASED	
	CampID campID = currentCtx << 16 | instrID;
	//CampID based
	if(campIDCntMap[campID] > SAMPLING_THRESHOLD) return;
	campIDCntMap[campID]++;
	#endif		

	#ifdef CTXID_BASED
	//if(sampling != 0x00000000) return;//Context ID based
	#endif


	nSampledStoreInvo++; //sampling ratio stat
}

extern "C" void*
campMalloc (size_t size){
	void* addr = malloc (size);
	return addr;
}

extern "C" void*
campCalloc (size_t size, size_t num){
	void* addr = calloc (size, num);
	return addr;
}

extern "C" void*
campRealloc (void* addr, size_t size){
	void* naddr = NULL;
	naddr = realloc (addr, size);
	return naddr;
}

extern "C" void
campFree (void* addr){
	free (addr);
}


extern "C" void campDisableCtxtChange(){
}

extern "C" void campEnableCtxtChange(){
}

#ifdef CAMPID_BASED
static void printCampIDCounterMap(){
	printf("[======== CampID counter Map ========]\n");
	for(auto it=campIDCntMap.begin(), itE=campIDCntMap.end(); it!=itE; ++it){
		printf("[%d : %d] \n", it->first, it->second);
	}
	printf("[======== CampID counter Map END========]\n");
	
}
#endif