#ifndef CORELAB_CAMP_POST_PROCESS_HPP
#define CORELAB_CAMP_POST_PROCESS_HPP

#include <inttypes.h>
#include <vector>
#include <list>
#include <cstring>


#define TREE_MAX_DEPTH_LIMIT 12000

namespace corelab
{
	using namespace std;

	class ContextTree;
	typedef ContextTree ContextTreeNode;
	typedef uint16_t UniqueContextID;
	typedef uint16_t LocalContextID;
	typedef uint16_t LoopID;

	class ContextTree{
		public:
			ContextTree(bool b, ContextTreeNode *p, UniqueContextID ucID_, LocalContextID locID_)
				: isCallSite(b), ucID(ucID_), parent(p), locID(locID_) {
					assert(locID == (ucID-(parent != NULL ? parent->ucID : 0)) );
				}

			bool isCallSite;
			//bool isRecursiveCallSite;
			
			char funName[64]; //for callsite

			LoopID loopID;	//for Loop

			UniqueContextID ucID;
			LocalContextID locID;
			
			//tree
			ContextTree *parent;
			std::vector<ContextTree *> children;

			//set
			inline void setFunName(char *s){strcpy(funName, s);}
			inline void setLoopID(LoopID l){loopID = l;}

			//get
			inline ContextTree* getParent(){return parent;}
			inline UniqueContextID getUCID(){return ucID;}
			inline LocalContextID getLocID(){return locID;}
			inline LoopID getLoopID(){return loopID;}
			inline LocalContextID getLocalContextID(){return locID;}
			inline std::vector<ContextTree *> *getChildren(){return &children;}
			inline bool isCallSiteNode(){return isCallSite;}

			void getContextStack(std::list<ContextTreeNode *> *cxtStk){
				cxtStk->push_front(this);
				if(parent) parent->getContextStack(cxtStk);
			}

			// inline bool isRecursiveCallSiteNode(){return isRecursiveCallSite;}
			void addChild(ContextTreeNode *c){
				children.push_back(c);
			}
			// void markRecursive(){
			// 	assert(isCallSite);
			// 	isRecursiveCallSite = true;
			// }
			void printPathToRoot(){
				if(isCallSite)
					cout<<" ["<<ucID<<"("<<funName<<")] ";
				else
					cout<<" ["<<ucID<<": "<<loopID<<"] ";
				if(parent == NULL) return;
				parent->printPathToRoot();
			}
	};

	typedef uint16_t InstrID;
	typedef uint32_t DepKey;

	typedef enum
	{
		N = 0x00,
		I = 0x01,
		X = 0x02,
		M = 0x03
	} IterRel;

	class Dependence{
		public:
			Dependence(UniqueContextID ucIDsrc_, UniqueContextID ucIDdst_, InstrID instrIDsrc_, InstrID instrIDdst_) 
			: ucIDsrc(ucIDsrc_), ucIDdst(ucIDdst_), instrIDsrc(instrIDsrc_), instrIDdst(instrIDdst_) {
				depKey = ucIDsrc << 16 | ucIDdst;
			}
			DepKey depKey;
			UniqueContextID ucIDsrc;
			UniqueContextID ucIDdst;
			InstrID instrIDsrc;
			InstrID instrIDdst;
			IterRel iterRel[16];

			inline DepKey getDepKey(){return depKey;}
			void addIterRel(uint32_t iterRel_32){
				for (int i = 0; i < 16; ++i){
					iterRel[i] = (IterRel)( ( (0x03 << i*2) & iterRel_32 ) >> (i*2) );
				}
			}
			void printIterRel(){
				cout<<"IterRel: {";
				for (int i = 0; i < 16; ++i){
					cout<<(iterRel[i]==0?'N':iterRel[i]==1?'I':iterRel[i]==2?'X':'M')<<", ";
				}	
				cout<<"}";
			}
			bool operator==(const Dependence &rhs) const{
				// bool sameIterRel = true;
				// for (int i = 0; i < 16; ++i)
				// 	sameIterRel = sameIterRel && iterRel[i] == rhs.iterRel[i];
				// return depKey == rhs.depKey && instrIDsrc == rhs.instrIDsrc && instrIDdst == rhs.instrIDdst && sameIterRel;


				return depKey == rhs.depKey && instrIDsrc == rhs.instrIDsrc && instrIDdst == rhs.instrIDdst;
			}
	};

}

#endif //CORELAB_CAMP_POST_PROCESS_HPP
