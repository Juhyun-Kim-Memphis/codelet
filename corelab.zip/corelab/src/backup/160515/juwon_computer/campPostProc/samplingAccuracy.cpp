#include <iostream>
#include <fstream>
#include <assert.h>
#include <stdlib.h>
#include <algorithm>
#include <unordered_set>
#include <unordered_map>
#include <list>
#include "PostProcess.hpp"

#define MAX_LINE_SIZE 4096

using namespace std;
using namespace corelab;

// typedef struct {
// 	uint64_t depKey;
// 	uint8_t kind; // 0 nothing, 1 is intra, 2 is inter

// 	bool operator==(const DepElem &rhs) const{
// 		// bool sameIterRel = true;
// 		// for (int i = 0; i < 16; ++i)
// 		// 	sameIterRel = sameIterRel && iterRel[i] == rhs.iterRel[i];
// 		// return depKey == rhs.depKey && instrIDsrc == rhs.instrIDsrc && instrIDdst == rhs.instrIDdst && sameIterRel;


// 		return depKey == rhs.depKey && kind == rhs.kind;
// 	}
// } DepElem;

class DepElem{
public:
	uint64_t depKey;
	uint8_t kind; // 0 nothing, 1 is intra, 2 is inter

	bool operator==(const DepElem &rhs) const{
		// bool sameIterRel = true;
		// for (int i = 0; i < 16; ++i)
		// 	sameIterRel = sameIterRel && iterRel[i] == rhs.iterRel[i];
		// return depKey == rhs.depKey && instrIDsrc == rhs.instrIDsrc && instrIDdst == rhs.instrIDdst && sameIterRel;


		return depKey == rhs.depKey && kind == rhs.kind;
	}

};




// uint8_t checkLastBit(uint32_t iterRel){
// 	uint32_t mask = 0x00000003;
// 	uint8_t res = 0;

// 	// [ iter32 inter intra, iter31 inter intra ... iter0 inter intra ]
// 	for(int i=0;i<16;i++){
// 		mask = (mask << (i*2));
// 		if((((iterRel & mask) >> (i*2)) & 0x00000003) == 0x00000003)
// 			res = 3;
// 		if((((iterRel & mask) >> (i*2)) & 0x00000003) == 0x00000001)
// 			res = 1;
// 		if((((iterRel & mask) >> (i*2)) & 0x00000003) == 0x00000002)
// 			res = 2;
// 	}

// 	return res;
// }

int main(int argc, char** argv){
	unsigned truePositive = 0;
	unsigned truePositive2 = 0;
	unsigned falsePositive = 0;
	unsigned falseNegative = 0;



	char line[MAX_LINE_SIZE];
	unsigned nNode = 0;

	std::ifstream fpCtxTree ("ContextTree.data", std::ifstream::binary);
	assert(fpCtxTree);

	fpCtxTree.getline(line, MAX_LINE_SIZE);
	string startMsg("$$$$$ CONTEXT TREE IN PREORDER $$$$$");
	assert(startMsg.compare(line) == 0);
	fpCtxTree.getline(line, MAX_LINE_SIZE);
	nNode = (unsigned)(atoi(line));

	std::unordered_map<UniqueContextID, ContextTreeNode *> ucIDMap;
	std::unordered_map<LoopID, std::vector<UniqueContextID>> loopMap;

	char ucIDStr[64];
	char locIDStr[64];
	char kind[4];
	char funName[64];
	char loopIDStr[64];
	char tmp[128];

	//add root (main)
	fpCtxTree>>ucIDStr;
	fpCtxTree>>locIDStr;
	fpCtxTree>>kind;
	fpCtxTree>>tmp;
	fpCtxTree>>funName;
	assert(strcmp(kind, "CS") == 0 && strcmp(funName, "main") == 0);
	ContextTree *root = new ContextTree(true, NULL, 0, 0);
	root->setFunName(funName);
	ucIDMap[0] = root;

	//read ContextTree.data
	for (int i = 0; i < nNode-1; ++i){
		fpCtxTree>>ucIDStr;
		fpCtxTree>>locIDStr;
		UniqueContextID ucID = (UniqueContextID)(atoi(ucIDStr));
		LocalContextID locID = (LocalContextID)(atoi(locIDStr));
		ContextTree *curParent = ucIDMap[ ucID - locID ];

		fpCtxTree>>kind;
		if(strcmp(kind, "CS") == 0){
			fpCtxTree>>tmp; // recursive Fun? or normal?
			fpCtxTree>>funName;
			ContextTree *node = new ContextTree(true, curParent, ucID, (LocalContextID)(atoi(locIDStr)));
			node->setFunName(funName);
			curParent->addChild(node);
			ucIDMap[ucID] = node;
		}
		else if(strcmp(kind, "L") == 0){
			fpCtxTree>>loopIDStr;
			fpCtxTree>>tmp; // loop name;
			ContextTree *node = new ContextTree(false, curParent, ucID, (LocalContextID)(atoi(locIDStr)));
			LoopID loopID = (LoopID)(atoi(loopIDStr));
			node->setLoopID(loopID);
			curParent->addChild(node);

			ucIDMap[ucID] = node;
			loopMap[loopID].push_back(ucID);
		}
		else
			assert(0 &&"WTF?");
	}

	fpCtxTree.getline(line, MAX_LINE_SIZE); // for last char "\n" of last element Node
	fpCtxTree.getline(line, MAX_LINE_SIZE);
	string endMsg("$$$$$ CONTEXT TREE END $$$$$");
	assert(endMsg.compare(line) == 0);
	fpCtxTree.close();


	char depStr[128];
	std::ifstream fpDepTb ("DependenceTable.data", std::ifstream::binary);
	assert(fpDepTb);
	std::vector<DepElem> depVec;
	std::unordered_set<uint64_t> depSet;//SET

	while(fpDepTb >> depStr){ // Attempt read into depStr, return false if it fails
		uint32_t campIDsrc=0;
		uint32_t campIDdst=0;
		uint32_t iterRel=0;
		if(sscanf (depStr,"%x>%x:%x",&campIDsrc,&campIDdst, &iterRel) != 3) assert(0 && "ERROR: read fail");
		Dependence *dep = new Dependence(campIDsrc>>16, campIDdst>>16, campIDsrc & 0xffff, campIDdst & 0xffff);
		dep->addIterRel(iterRel);

		uint64_t newDep64 = ((((uint64_t)campIDsrc)<<32)|(((uint64_t)campIDdst)&0xffffffff));//SET

		// auto found = std::find(depSet.begin(), depSet.end(), newDep);
		// if(found == depSet.end())
			// depSet.push_back(newDep);
			assert(depSet.find(newDep64) == depSet.end());
			depSet.insert(newDep64);

			DepElem newDep64_e;
			newDep64_e.depKey = newDep64;
			newDep64_e.kind = 0;
			//////////////////////////
			std::list<ContextTreeNode *> cxtStksrc;
			std::list<ContextTreeNode *> cxtStkdst;
			ucIDMap[dep->ucIDsrc]->getContextStack(&cxtStksrc); assert(!cxtStksrc.empty());
			ucIDMap[dep->ucIDdst]->getContextStack(&cxtStkdst); assert(!cxtStkdst.empty());
			std::list<ContextTreeNode *> cxtStkLoop;
			while(cxtStksrc.front()->getUCID() == cxtStkdst.front()->getUCID() && !cxtStkdst.empty() && !cxtStksrc.empty()){
				assert(cxtStksrc.front() == cxtStkdst.front());
				if(cxtStksrc.front()->isCallSite == false){
					cxtStkLoop.push_back(cxtStksrc.front()); //only push loop node
				}
				cxtStksrc.pop_front();
				cxtStkdst.pop_front();
				if(cxtStkdst.empty() || cxtStksrc.empty())
					break;
			}
			if(cxtStkLoop.empty() == false){
				if(dep->iterRel[cxtStkLoop.size()-1] == M){
					newDep64_e.kind = 1;
					depVec.push_back(newDep64_e);
					newDep64_e.kind = 2;
					depVec.push_back(newDep64_e);
				}
				else if(dep->iterRel[cxtStkLoop.size()-1] == X){
					newDep64_e.kind = 2;
					depVec.push_back(newDep64_e);
				}
				else if(dep->iterRel[cxtStkLoop.size()-1] == I){
					newDep64_e.kind = 1;
					depVec.push_back(newDep64_e);
				}
				else{
					newDep64_e.kind = 0;
					depVec.push_back(newDep64_e);	
				}
			}
			else{
				newDep64_e.kind = 0;
				depVec.push_back(newDep64_e);	
			}
			cxtStksrc.clear();
			cxtStkdst.clear();
			delete dep; 
			//////////////////////////

		// else{
		// 	std::cout<<"Found Duplication "<<"!!("<< std::hex << found->depKey; found->printIterRel();
		// 	std::cout<<"), ("<< std::hex << newDep.depKey; newDep.printIterRel();
		// 	std::cout<<"\n";
		// 	assert(0 && "WTF33");
		// }
	}
	fpDepTb.close();


	std::ifstream fpDepTbReal ("DependenceTable.real.data", std::ifstream::binary);
	assert(fpDepTbReal);
	// std::vector<Dependence> depSetReal;
	std::vector<DepElem> depVecReal;
	std::unordered_set<uint64_t> depSetReal;//SET

	while(fpDepTbReal >> depStr){ // Attempt read into depStr, return false if it fails
		uint32_t campIDsrc=0;
		uint32_t campIDdst=0;
		uint32_t iterRel=0;
		if(sscanf (depStr,"%x>%x:%x",&campIDsrc,&campIDdst, &iterRel) != 3) assert(0 && "ERROR: read fail");

		Dependence *dep = new Dependence(campIDsrc>>16, campIDdst>>16, campIDsrc & 0xffff, campIDdst & 0xffff);
		dep->addIterRel(iterRel);

		// Dependence newDep(campIDsrc>>16, campIDdst>>16, campIDsrc & 0xffff, campIDdst & 0xffff);
		// newDep.addIterRel(iterRel);
		uint64_t newDep64 = ((((uint64_t)campIDsrc)<<32)|(((uint64_t)campIDdst)&0xffffffff));//SET

		// auto found = std::find(depSetReal.begin(), depSetReal.end(), newDep);
		// if(found == depSetReal.end())
			// depSetReal.push_back(newDep);
			assert(depSetReal.find(newDep64) == depSetReal.end());
			depSetReal.insert(newDep64);//SET


			DepElem newDep64_e;
			newDep64_e.depKey = newDep64;
			newDep64_e.kind = 0;
			//////////////////////////
			std::list<ContextTreeNode *> cxtStksrc;
			std::list<ContextTreeNode *> cxtStkdst;
			ucIDMap[dep->ucIDsrc]->getContextStack(&cxtStksrc); assert(!cxtStksrc.empty());
			ucIDMap[dep->ucIDdst]->getContextStack(&cxtStkdst); assert(!cxtStkdst.empty());
			std::list<ContextTreeNode *> cxtStkLoop;
			while(cxtStksrc.front()->getUCID() == cxtStkdst.front()->getUCID() && !cxtStkdst.empty() && !cxtStksrc.empty()){
				assert(cxtStksrc.front() == cxtStkdst.front());
				if(cxtStksrc.front()->isCallSite == false)
					cxtStkLoop.push_back(cxtStksrc.front()); //only push loop node
				cxtStksrc.pop_front();
				cxtStkdst.pop_front();
				if(cxtStkdst.empty() || cxtStksrc.empty())
					break;
			}
			if(cxtStkLoop.empty() == false){
				if(dep->iterRel[cxtStkLoop.size()-1] == M){
					newDep64_e.kind = 1;
					depVecReal.push_back(newDep64_e);
					newDep64_e.kind = 2;
					depVecReal.push_back(newDep64_e);
				}
				else if(dep->iterRel[cxtStkLoop.size()-1] == X){
					newDep64_e.kind = 2;
					depVecReal.push_back(newDep64_e);
				}
				else if(dep->iterRel[cxtStkLoop.size()-1] == I){
					newDep64_e.kind = 1;
					depVecReal.push_back(newDep64_e);
				}
				else{
					newDep64_e.kind = 0;
					depVecReal.push_back(newDep64_e);	
				}
			}
			else{
				newDep64_e.kind = 0;
				depVecReal.push_back(newDep64_e);	
			}
			cxtStksrc.clear();
			cxtStkdst.clear();
			delete dep;
			//////////////////////////

		// else{
		// 	std::cout<<"Found Duplication "<<"!!("<< std::hex << found->depKey; found->printIterRel();
		// 	std::cout<<"), ("<< std::hex << newDep.depKey; newDep.printIterRel();
		// 	std::cout<<"\n";
		// 	assert(0 && "WTF22");
		// }


	}
	fpDepTbReal.close();

	
	

	// cout<<"SAMPLED##############\n";
	// 	for(auto dep : depSet){
	// 		cout<<"  ["<<dep.getDepKey()<<": ("<<dep.ucIDsrc<<"("<<dep.instrIDsrc<<")"<<"=>"<<dep.ucIDdst<<"("<<dep.instrIDdst<<")"<<") ::";
	// 		dep.printIterRel();
	// 		cout<<"]";
	// 		cout<<"\n";
	// 	}
	// cout<<"SAMPLED END##############\n\n";
	// cout<<"REAL##############\n";
	// 	for(auto dep : depSetReal){
	// 		cout<<"  ["<<dep.getDepKey()<<": ("<<dep.ucIDsrc<<"("<<dep.instrIDsrc<<")"<<"=>"<<dep.ucIDdst<<"("<<dep.instrIDdst<<")"<<") ::";
	// 		dep.printIterRel();
	// 		cout<<"]";
	// 		cout<<"\n";
	// 	}
	// cout<<"REAL END##############\n\n";

	// cout<<"\n";
	for(auto e : depSet){
		// auto found = std::find(depSetReal.begin(), depSetReal.end(), e);
		auto found = depSetReal.find(e);
		if(found != depSetReal.end())
			truePositive++;
		else{
			falsePositive++;
			// cout<<"  ["<<e.getDepKey()<<": ("<<e.ucIDsrc<<"("<<e.instrIDsrc<<")"<<"=>"<<e.ucIDdst<<"("<<e.instrIDdst<<")"<<") ::";
			// e.printIterRel();
			// cout<<"] \n";
			
		}
	}

	for(auto e : depSetReal){
		// auto found = std::find(depSet.begin(), depSet.end(), e);
		auto found = depSet.find(e);
		if(found != depSet.end())
			truePositive2++;
		else
			falseNegative++;
	}

	unsigned truePositive_vec = 0;
	unsigned truePositive2_vec = 0;
	unsigned falsePositive_vec = 0;
	unsigned falseNegative_vec = 0;

	for(auto e : depVec){
		auto found = std::find(depVecReal.begin(), depVecReal.end(), e);
		// auto found = depSetReal.find(e);
		if(found != depVecReal.end())
			truePositive_vec++;
		else{
			falsePositive_vec++;
			// cout<<"  ["<<e.getDepKey()<<": ("<<e.ucIDsrc<<"("<<e.instrIDsrc<<")"<<"=>"<<e.ucIDdst<<"("<<e.instrIDdst<<")"<<") ::";
			// e.printIterRel();
			// cout<<"] \n";

			
			// DepElem ee;
			// ee.depKey = e.depKey;
			// ee.kind = 2;
			// DepElem eee;
			// eee.depKey = e.depKey;
			// eee.kind = 0;
			// bool found2 = (std::find(depVecReal.begin(), depVecReal.end(), ee) != depVecReal.end());
			// bool found3 = (std::find(depVecReal.begin(), depVecReal.end(), eee) != depVecReal.end());

			// uint16_t instrIDdst = (uint16_t)(e.depKey & 0x000000000000ffff);
			// uint16_t ctxtIDdst = (uint16_t)((e.depKey & 0x00000000ffffffff) >> 16);
			// uint16_t instrIDsrc = (uint16_t)((e.depKey >> 32) & 0x0000ffff);
			// uint16_t ctxtIDsrc = (uint16_t)(e.depKey >> 48);

			// cout<<" EEE:"<<e.depKey<<", kind:"<<((int)(e.kind))<<", "<<found2<<", "<<found3<<"\n";
			// cout<<"("<<ctxtIDsrc<<")"<<instrIDsrc<<"=>("<<ctxtIDdst<<")"<<instrIDdst<<" , kind:"<<((int)(e.kind))<<", "<<found2<<", "<<found3<<"\n";
			
		}
	}

	unsigned intraMissing =0;
	unsigned interMissing =0;
	for(auto e : depVecReal){
		auto found = std::find(depVec.begin(), depVec.end(), e);
		// auto found = std::find(depSet.begin(), depSet.end(), e);
		// auto found = depSet.find(e);
		if(found != depVec.end())
			truePositive2_vec++;
		else{
			if(e.kind == 1)
				intraMissing++;
			else if(e.kind == 2)
				interMissing++;
			falseNegative_vec++;
		}
	}


	assert(truePositive2_vec == truePositive_vec);
	assert(truePositive2 == truePositive);
	// std::cout<<"Total: Full :"<<depSetReal.size()<<", Sampled: "<<depSet.size()<<"\n";
	std::cout<<"Result Vec : "<<depVecReal.size()<<"\t"<<depVec.size()<<"\t";
	// std::cout<<"Result of Accuracy test :: TP: "<<truePositive<<", FN: "<<falseNegative<<", FP:"<<falsePositive<<"\n";
	std::cout<<truePositive_vec<<"\t"<<falseNegative_vec<<"\t"<<falsePositive_vec<<"\n";
	// std::cout<<"Missing:"<<intraMissing<<"\t"<<interMissing<<"\n";

	// std::cout<<"Total: Full :"<<depSetReal.size()<<", Sampled: "<<depSet.size()<<"\n";
	std::cout<<"Result Set : "<<depSetReal.size()<<"\t"<<depSet.size()<<"\t";
	// std::cout<<"Result of Accuracy test :: TP: "<<truePositive<<", FN: "<<falseNegative<<", FP:"<<falsePositive<<"\n";
	std::cout<<truePositive<<"\t"<<falseNegative<<"\t"<<falsePositive<<"\n";


}

