#include <iostream>
#include <fstream>
#include <assert.h>
#include <stdlib.h>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>

#include "PostProcess.hpp"

#define MAX_LINE_SIZE 4096

using namespace std;
using namespace corelab;

#define REGI_DEP_TEST

int main(int argc, char** argv){
	char line[MAX_LINE_SIZE];
	unsigned nNode = 0;
	unsigned cnt = 0;

	std::ifstream fpCtxTree ("ContextTree.data", std::ifstream::binary);
	assert(fpCtxTree);

	fpCtxTree.getline(line, MAX_LINE_SIZE);
	string startMsg("$$$$$ CONTEXT TREE IN PREORDER $$$$$");
	assert(startMsg.compare(line) == 0);
	fpCtxTree.getline(line, MAX_LINE_SIZE);
	nNode = (unsigned)(atoi(line));

	std::unordered_map<UniqueContextID, ContextTreeNode *> ucIDMap;
	std::unordered_map<LoopID, std::vector<UniqueContextID>> loopMap;

	char ucIDStr[64];
	char locIDStr[64];
	char kind[4];
	char funName[64];
	char loopIDStr[64];
	char tmp[128];

	//add root (main)
	fpCtxTree>>ucIDStr;
	fpCtxTree>>locIDStr;
	fpCtxTree>>kind;
	fpCtxTree>>tmp;
	fpCtxTree>>funName;
	assert(strcmp(kind, "CS") == 0 && strcmp(funName, "main") == 0);
	ContextTree *root = new ContextTree(true, NULL, 0, 0);
	root->setFunName(funName);
	ucIDMap[0] = root;

	//read ContextTree.data
	for (int i = 0; i < nNode-1; ++i){
		fpCtxTree>>ucIDStr;
		fpCtxTree>>locIDStr;
		UniqueContextID ucID = (UniqueContextID)(atoi(ucIDStr));
		LocalContextID locID = (LocalContextID)(atoi(locIDStr));
		ContextTree *curParent = ucIDMap[ ucID - locID ];

		fpCtxTree>>kind;
		if(strcmp(kind, "CS") == 0){
			fpCtxTree>>tmp; // recursive Fun? or normal?
			fpCtxTree>>funName;
			ContextTree *node = new ContextTree(true, curParent, ucID, (LocalContextID)(atoi(locIDStr)));
			node->setFunName(funName);
			curParent->addChild(node);
			ucIDMap[ucID] = node;
		}
		else if(strcmp(kind, "L") == 0){
			fpCtxTree>>loopIDStr;
			fpCtxTree>>tmp; // loop name;
			ContextTree *node = new ContextTree(false, curParent, ucID, (LocalContextID)(atoi(locIDStr)));
			LoopID loopID = (LoopID)(atoi(loopIDStr));
			node->setLoopID(loopID);
			curParent->addChild(node);

			ucIDMap[ucID] = node;
			loopMap[loopID].push_back(ucID);
		}
		else
			assert(0 &&"WTF?");
	}

	fpCtxTree.getline(line, MAX_LINE_SIZE); // for last char "\n" of last element Node
	fpCtxTree.getline(line, MAX_LINE_SIZE);
	string endMsg("$$$$$ CONTEXT TREE END $$$$$");
	assert(endMsg.compare(line) == 0);
	fpCtxTree.close();


	#ifdef REGI_DEP_TEST
	unsigned nNonDOALLableLoopByRegi = 0;

	std::ifstream fpNonDOALLableRegi ("nNonDOALLableLoopByRegi.data", std::ifstream::binary);
	assert(fpNonDOALLableRegi);
	fpNonDOALLableRegi.getline(line, MAX_LINE_SIZE);
	string startMsg2("$$$$$ NON DOALLABLE BY REGISTER $$$$$");
	assert(startMsg2.compare(line) == 0);
	fpNonDOALLableRegi.getline(line, MAX_LINE_SIZE);
	nNonDOALLableLoopByRegi = (unsigned)(atoi(line));

	std::unordered_set<LoopID> nonDOALLableSet;

	char loopIDStr2[64];
	for (int i = 0; i < nNonDOALLableLoopByRegi; ++i){
		fpNonDOALLableRegi >> loopIDStr2;
		LoopID loopID = (LoopID)(atoi(loopIDStr2));
		nonDOALLableSet.insert(loopID);
	}
	if(nNonDOALLableLoopByRegi != 0)
		fpNonDOALLableRegi.getline(line, MAX_LINE_SIZE); // for last char "\n" of last element Node
	fpNonDOALLableRegi.getline(line, MAX_LINE_SIZE);
	string endMsg2("$$$$$ NON DOALLABLE BY REGISTER END $$$$$");
	assert(endMsg2.compare(line) == 0);
	fpNonDOALLableRegi.close();
	#endif

	//read DependenceTable.data
	std::ifstream fpDepTb ("DependenceTable.data", std::ifstream::binary);
	assert(fpDepTb);

	std::unordered_map<DepKey, std::vector<Dependence *>> depMap;
	std::vector<Dependence *> depList;

	char depStr[128];
	while(fpDepTb >> depStr){ // Attempt read into depStr, return false if it fails
		uint32_t campIDsrc=0;
		uint32_t campIDdst=0;
		uint32_t iterRel=0;
		if(sscanf (depStr,"%x>%x:%x",&campIDsrc,&campIDdst, &iterRel) != 3) assert(0 && "ERROR: read fail");
		Dependence *newDep = new Dependence(campIDsrc>>16, campIDdst>>16, campIDsrc & 0xffff, campIDdst & 0xffff);
		newDep->addIterRel(iterRel);

		depList.push_back(newDep);
		depMap[newDep->getDepKey()].push_back(newDep);
	}
	#ifdef REGI_DEP_TEST
	// cout<<"nonDOALLableSet size:"<<nonDOALLableSet.size()<<"\n";
	cout<<nonDOALLableSet.size()<<"\n";
	#endif
	// cout<<"DependenceTable.data (# deps : "<<depList.size()<<", # of edges to distinct ctxt: "<<depMap.size()<<")\n";
	cout<<depList.size()<<"\t"<<depMap.size()<<"\n";



	std::unordered_map<UniqueContextID, unsigned> nInterDepOfLoop_camp;
	std::unordered_map<LoopID, unsigned> nInterDepOfLoop_lamp;


	for(auto deps : depMap){
		for(Dependence *dep : deps.second){
			std::list<ContextTreeNode *> cxtStksrc;
			std::list<ContextTreeNode *> cxtStkdst;
			ucIDMap[dep->ucIDsrc]->getContextStack(&cxtStksrc); assert(!cxtStksrc.empty());
			ucIDMap[dep->ucIDdst]->getContextStack(&cxtStkdst); assert(!cxtStkdst.empty());
			std::list<ContextTreeNode *> cxtStkLoop;
			while(cxtStksrc.front()->getUCID() == cxtStkdst.front()->getUCID() && !cxtStkdst.empty() && !cxtStksrc.empty()){
				assert(cxtStksrc.front() == cxtStkdst.front());
				if(cxtStksrc.front()->isCallSite == false)
					cxtStkLoop.push_back(cxtStksrc.front()); //only push loop node
				cxtStksrc.pop_front();
				cxtStkdst.pop_front();
			}
			if(cxtStkLoop.empty() == false){
				if(dep->iterRel[cxtStkLoop.size()-1] == X || dep->iterRel[cxtStkLoop.size()-1] == M){
					nInterDepOfLoop_camp[cxtStkLoop.back()->getUCID()]++;
					nInterDepOfLoop_lamp[cxtStkLoop.back()->loopID]++;
				}
			}
			cxtStksrc.clear();
			cxtStkdst.clear();
		}
	}

	std::unordered_map<UniqueContextID, unsigned> nInterDepOfLoop_lamp_false;
	for(auto p : nInterDepOfLoop_lamp){
		for (UniqueContextID id : loopMap[p.first]){
			nInterDepOfLoop_lamp_false[id] = p.second;
		}
	}

	std::vector<LoopID> alwaysDOALL;
	std::vector<LoopID> alwaysNOT_DOALL;
	std::vector<LoopID> somethimesDOALL;

	// # Always DOALL static # Not DOALL static
	for(auto p : loopMap){
		bool DOALLable = true;
		bool NOT_DOALLable = true;
		unsigned nInterDep=0;
		unsigned nCxt=0;

		for(UniqueContextID id : p.second){
			nCxt++;
			auto found = nInterDepOfLoop_camp.find(id);
			if(found != nInterDepOfLoop_camp.end()){
				if(found->second > 0){
					DOALLable = DOALLable && false;
					nInterDep++;
				}
				else if(found->second == 0){
					NOT_DOALLable = NOT_DOALLable && false;
				}
			}
			else{
				NOT_DOALLable = NOT_DOALLable && false;
			}
		}

		if(DOALLable){
			assert(nInterDep == 0);
			alwaysDOALL.push_back(p.first);

			#ifdef REGI_DEP_TEST
			if(nonDOALLableSet.end() != nonDOALLableSet.find(p.first)){
				alwaysNOT_DOALL.push_back(p.first);	
				alwaysDOALL.pop_back();
			}
			#endif
		}
		else if(nInterDep > 0 && nInterDep < nCxt){
			somethimesDOALL.push_back(p.first);

			#ifdef REGI_DEP_TEST
			if(nonDOALLableSet.end() != nonDOALLableSet.find(p.first)){
				alwaysNOT_DOALL.push_back(p.first);	
				somethimesDOALL.pop_back();
			}
			#endif
		}
		else if(NOT_DOALLable){
			assert(nInterDep == nCxt);
			alwaysNOT_DOALL.push_back(p.first);
		}
		else{
			#ifdef REGI_DEP_TEST
			if(nonDOALLableSet.end() != nonDOALLableSet.find(p.first))
				alwaysNOT_DOALL.push_back(p.first);	
			#endif
		}
		
	}// # Always DOALL static == alwaysDOALL.size()

	//# Always DOALL ctxt
	unsigned nAlwaysDOALLctxt = 0;
	for(LoopID lid : alwaysDOALL)
		nAlwaysDOALLctxt += loopMap[lid].size();

	//# sometimes DOALL ctxt
	std::vector<UniqueContextID> somethimesDOALLableCtxtList;
	unsigned nSometimesDOALLctxt = 0;
	unsigned nNotDOALLctxtInSometimesDOALL = 0;
	unsigned totalnSometimesCtxt =0;
	for(LoopID lid : somethimesDOALL){
		totalnSometimesCtxt+= loopMap[lid].size();
		for(UniqueContextID id: loopMap[lid]){
			auto found = nInterDepOfLoop_camp.find(id);
			if(found != nInterDepOfLoop_camp.end()){
				if(found->second > 0) nNotDOALLctxtInSometimesDOALL++;
				else if(found->second == 0){
					nSometimesDOALLctxt++;
					somethimesDOALLableCtxtList.push_back(id);
				}
			}
			else{
				nSometimesDOALLctxt++;
				somethimesDOALLableCtxtList.push_back(id);
			}
		}
	}
	assert(totalnSometimesCtxt == (nSometimesDOALLctxt+nNotDOALLctxtInSometimesDOALL));
	assert(nSometimesDOALLctxt == somethimesDOALLableCtxtList.size());


	#ifdef REGI_DEP_TEST
	unsigned nNotFoundedNonDoallable_camp = 0;
	unsigned nNoCxtLoop_camp = 0;
	for(auto e: nonDOALLableSet){
		if(find(alwaysNOT_DOALL.begin(), alwaysNOT_DOALL.end(), e) == alwaysNOT_DOALL.end()){
			nNotFoundedNonDoallable_camp++;
			alwaysNOT_DOALL.push_back(e);

			if(loopMap[e].size() == 0)
				nNoCxtLoop_camp++;
		}
	}
	// cout<<"\nnNotFoundedNonDoallable_camp: "<<nNotFoundedNonDoallable_camp<<", nNoCxtLoop_camp: "<<nNoCxtLoop_camp<<"\n";
	#endif

	//# Not DOALL static
	unsigned nNotDOALLctxt = 0;
	for(LoopID lid : alwaysNOT_DOALL){
		nNotDOALLctxt += loopMap[lid].size();
	}

	// CAMP
	cout<< alwaysDOALL.size()<<"\t"<<nAlwaysDOALLctxt<<"\t";
	cout<< somethimesDOALL.size()<<"\t"<<nSometimesDOALLctxt<<"\t"<<nNotDOALLctxtInSometimesDOALL<<"\t";
	// cout<< somethimesDOALL.size()<<"\t"<<nSometimesDOALLctxt<<"\t"<<nNotDOALLctxtInSometimesDOALL<<"\tTOTAL("<<totalnSometimesCtxt<<")\t";
	cout<< alwaysNOT_DOALL.size()<<"\t"<<nNotDOALLctxt<<"\t";

	std::vector<LoopID> alwaysDOALL_lamp;
	unsigned nCtxt_alwaysDOALL_lamp =0;
	std::vector<LoopID> alwaysNOT_DOALL_lamp;
	unsigned nCtxt_alwaysNOT_DOALL_lamp =0;
	// LAMP
	for(auto p : loopMap){
		auto found = nInterDepOfLoop_lamp.find(p.first);
		if(found != nInterDepOfLoop_lamp.end()){
			if(found->second>0){
				alwaysNOT_DOALL_lamp.push_back(p.first);
			}
			else if(found->second == 0){
				alwaysDOALL_lamp.push_back(p.first);
				#ifdef REGI_DEP_TEST
				if(nonDOALLableSet.end() != nonDOALLableSet.find(p.first)){
					alwaysDOALL_lamp.pop_back();	
					alwaysNOT_DOALL_lamp.push_back(p.first);	
				}
				#endif
			}
		}
		else{
			alwaysDOALL_lamp.push_back(p.first);
			#ifdef REGI_DEP_TEST
			if(nonDOALLableSet.end() != nonDOALLableSet.find(p.first)){
				alwaysDOALL_lamp.pop_back();	
				alwaysNOT_DOALL_lamp.push_back(p.first);	
			}
			#endif
		}
	}

	#ifdef REGI_DEP_TEST
	unsigned nNotFoundedNonDoallable_lamp = 0;
	unsigned nNoCxtLoop_lamp = 0;
	for(auto e: nonDOALLableSet){
		if(find(alwaysNOT_DOALL_lamp.begin(), alwaysNOT_DOALL_lamp.end(), e) == alwaysNOT_DOALL_lamp.end()){
			nNotFoundedNonDoallable_lamp++;
			alwaysNOT_DOALL_lamp.push_back(e);

			if(loopMap[e].size() == 0)
				nNoCxtLoop_lamp++;
		}
	}
	// cout<<"\nnNotFoundedNonDoallable_lamp: "<<nNotFoundedNonDoallable_lamp<<", nNoCxtLoop_lamp: "<<nNoCxtLoop_lamp<<"\n";
	#endif

	


	for(LoopID lid : alwaysDOALL_lamp) nCtxt_alwaysDOALL_lamp += loopMap[lid].size();
	for(LoopID lid : alwaysNOT_DOALL_lamp) nCtxt_alwaysNOT_DOALL_lamp += loopMap[lid].size();
	
	cout<< alwaysDOALL_lamp.size()<<"\t"<<nCtxt_alwaysDOALL_lamp<<"\t";
	cout<< alwaysNOT_DOALL_lamp.size()<<"\t"<<nCtxt_alwaysNOT_DOALL_lamp<<"\n";


	std::ofstream fpSometime("SometimesDOALLCtxtList.data", std::ios::out | std::ofstream::binary);

	if(fpSometime.is_open()){
		fpSometime<<"$$$$$ SometimesDOALLCtxtList $$$$$\n";
		fpSometime<<somethimesDOALLableCtxtList.size()<<"\n";
		//std::copy (cxtTree.begin(), cxtTree.end(),std::ostream_iterator<ContextTreeNode>(fpSometime, "\n"));
		for ( auto it = somethimesDOALLableCtxtList.begin(); it != somethimesDOALLableCtxtList.end(); ++it ){
			fpSometime<<*it<<"\n";
		}
		fpSometime<<"$$$$$ SometimesDOALLCtxtList END $$$$$\n";
	}
	fpSometime.close();


	//LAMP
	// # DOALLable static
	// # DOALL ctxt
	// # Not DOALL static
	// # Not DOALL ctxt


	// cout<<"#CAMP , (NOT DOALL-able: "<<nInterDepOfLoop_camp.size()<<")";
	// cout<<", LAMP(amplified) (NOT DOALL-able: "<<nInterDepOfLoop_lamp_false.size()<<"), ";
	// cout<<"LAMP (static NOT DOALL-able: "<<nInterDepOfLoop_lamp.size()<<"), false positive ratio (compared with camp):"
	// 	<<100.0 - (((double)nInterDepOfLoop_camp.size())/((double)nInterDepOfLoop_lamp_false.size()))*100<<" ########\n\n";



	// cout<<"##### CAMP (size: "<<nInterDepOfLoop_camp.size()<<")########\n";
	// for(auto p : nInterDepOfLoop_camp){
	// 	cout<<" Loop ucID:"<<p.first<<", # of InterDep: "<<p.second<<"\n";
	// }
	

	// cout<<"\n##### LAMP ########\n";
	// for(auto p : nInterDepOfLoop_lamp){
	// 	cout<<" LoopID:"<<p.first<<", # of InterDep: "<<p.second<<"\n";
	// }


	// cout<<"\n##### LAMP(2) (size: "<<nInterDepOfLoop_lamp_false.size()<<")########\n";
	// for(auto p : nInterDepOfLoop_lamp_false){
	// 	cout<<" LoopID:"<<p.first<<", # of InterDep: "<<p.second<<"\n";
	// }


	// cout<<"size of DepMap:"<<depMap.size()<<"\n";
	// for(auto deps : depMap){
	// 	cout<<"["<<deps.first<<":::"<<deps.second.size()<<"\n";
	// 	for(Dependence *dep : deps.second){
	// 		cout<<"  ["<<dep->getDepKey()<<": ("<<dep->ucIDsrc<<"("<<dep->instrIDsrc<<")"<<"=>"<<dep->ucIDdst<<"("<<dep->instrIDdst<<")"<<") ::";
	// 		dep->printIterRel();
	// 		cout<<"]";
	// 		cout<<"\n";
	
	// 		std::list<ContextTreeNode *> cxtStksrc;
	// 		std::list<ContextTreeNode *> cxtStkdst;
	// 		ucIDMap[dep->ucIDsrc]->getContextStack(&cxtStksrc);
	// 		ucIDMap[dep->ucIDdst]->getContextStack(&cxtStkdst);
	// 		cout<<"    (CtxStksrc size:"<<cxtStksrc.size()<<")";
	// 		std::for_each(cxtStksrc.begin(), cxtStksrc.end(), [](ContextTreeNode *n){if(n->isCallSite) cout<<(string(n->funName)+", "); else cout<<"L("<<n->loopID<<"), ";});
	// 		cout<<"\n";
	// 		cout<<"    (CtxStkdst size:"<<cxtStksrc.size()<<")";
	// 		std::for_each(cxtStkdst.begin(), cxtStkdst.end(), [](ContextTreeNode *n){if(n->isCallSite) cout<<(string(n->funName)+", "); else cout<<"L("<<n->loopID<<"), ";});
	// 		cout<<"\n";
	// 	}
	// 	cout<<"]\n";
	// }
	// cout<<"\n\n";
	// cout<<"size of DepList:"<<depList.size()<<"\n";
	// for(auto dep : depList){
	// 	cout<<"["<<dep->getDepKey()<<": ("<<dep->instrIDsrc<<"=>"<<dep->instrIDdst<<") ::";
	// 	dep->printIterRel();
	// 	cout<<"]\n";
	// }

	fpDepTb.close();
		
}




//std::for_each(cxtStk.begin(), cxtStk.end(), [](ContextTreeNode *n){if(n->isCallSite) cout<<(string(n->funName)+", "); else cout<<"L("<<n->loopID<<"), ";});

// cout<<"size of DepMap:"<<depMap.size()<<"\n";
// for(auto dep : depMap){
// 	cout<<"["<<dep.first<<": ("<<dep.second->instrIDsrc<<"=>"<<dep.second->instrIDdst<<") ::";
// 	dep.second->printIterRel();
// 	cout<<"]\n";
// }
// cout<<"\n\n";
// cout<<"size of DepList:"<<depList.size()<<"\n";
// for(auto dep : depList){
// 	cout<<"["<<dep->getDepKey()<<": ("<<dep->instrIDsrc<<"=>"<<dep->instrIDdst<<") ::";
// 	dep->printIterRel();
// 	cout<<"]\n";
// }



	// for(auto n : ucIDMap){
	// 	cout<<"=("<<n.first<<")=";
	// 	n.second->printPathToRoot();
	// 	cout<<"\n";
	// }