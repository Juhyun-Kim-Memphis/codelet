#ifndef CORELAB_CAMP_CTXT_OBLI_RUNTIME_H
#define CORELAB_CAMP_CTXT_OBLI_RUNTIME_H
#include <inttypes.h>
#include <set>

typedef uint16_t InstrID;
typedef uint32_t DepID;

// for Load History Element
typedef std::set<InstrID> LoadHistorySet;

// for Store History Element
typedef struct StoreHistoryElem {
	InstrID instrID;
} StoreHistoryElem;

typedef struct HistoryElem {
	LoadHistorySet *pLoadSet;
	StoreHistoryElem storeElem;
	char padding[6];
} HistoryElem;

// Initializer/Finalizer
extern "C" void ctxtobliInitialize (size_t ldrCnt, size_t strCnt, size_t callCnt,
		size_t loopCnt, size_t maxLoopDepth);

extern "C" void ctxtobliFinalize ();
		
// Memory Event
extern "C" void ctxtobliLoadInstr (void* addr, InstrID instrID);
extern "C" void ctxtobliStoreInstr (void* addr, InstrID instrID);


extern "C" void* ctxtobliMalloc (size_t size);
extern "C" void* ctxtobliCalloc (size_t num, size_t size);
extern "C" void* ctxtobliRealloc (void* addr, size_t size);
extern "C" void ctxtobliFree (void* addr);

// For debug
// extern "C" void dumpStoreHistoryTable();
// extern "C" void dumpLoadHistoryTable();
extern "C" void dumpDependenceTable();

#endif
//CORELAB_CAMP_CTXT_OBLI_RUNTIME_H
