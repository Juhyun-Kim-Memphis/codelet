#include <stdio.h>
#include <iostream>
#include <malloc.h>
#include <unordered_set>

#include <fstream> //to file IO
#include <bitset> //to output binary format
#include <iomanip> //to output hex format
#include <cstring>

#include "campCtxtObliRuntime.h"
#include "ShadowMemory.hpp"

struct sigaction ShadowMemoryManager::segvAction; //Page Fault hooking mechanism

static std::unordered_set<DepID> *depTable=NULL;

// Initializer/Finalizer
extern "C"
void ctxtobliInitialize (size_t ldrCnt, size_t strCnt, size_t callCnt, size_t loopCnt, size_t maxLoopDepth) {
	ShadowMemoryManager::initialize();
	printf("ctxtobliInitialize!! maxLoopDepth: %zu, sizeof StoreHistoryElem %lu, size of HistoryElem %lu \n", maxLoopDepth, sizeof(StoreHistoryElem), sizeof(HistoryElem));
	printf("sizeof void* %lu \n", sizeof(void*) );
	depTable = new std::unordered_set<DepID>;
}

extern "C"
void ctxtobliFinalize () {
	dumpDependenceTable();
	delete depTable;
}

static void insertDep(InstrID srcInstrID, InstrID dstInstrID){
	DepID depId = (((DepID) srcInstrID) << 16) | ((DepID) dstInstrID) ;
	depTable->insert(depId);
}

// Memory Event
extern "C"
void ctxtobliLoadInstr (void* addr, InstrID instrID) {
	HistoryElem *pHisElem = (HistoryElem *)(GET_SHADOW_ADDR_HISTORY_TB(addr));
	// fprintf(stderr, "LD %p ==> %p\n", addr, (void*)pHisElem);

	if(pHisElem->pLoadSet == NULL) //because we memset(0) for newly allocated page.
		pHisElem->pLoadSet = new LoadHistorySet;
	LoadHistorySet &loadHistorySet = *pHisElem->pLoadSet;

	// update dependence table (shadow memory version)
	if(pHisElem->storeElem.instrID != 0)
		insertDep(pHisElem->storeElem.instrID, instrID);

	// add history table (shadow memory version)
	loadHistorySet.insert(instrID);
}
 
extern "C"
void ctxtobliStoreInstr (void* addr, InstrID instrID) {
	HistoryElem *pHisElem = (HistoryElem *)(GET_SHADOW_ADDR_HISTORY_TB(addr));

	// update dependence table (shadow memory version)
	if(pHisElem->pLoadSet != NULL){
		LoadHistorySet &loadHistorySet = *pHisElem->pLoadSet;
		for (LoadHistorySet::iterator ii=loadHistorySet.begin(); ii!=loadHistorySet.end(); ++ii)
			insertDep(*ii, instrID);
	}
	if(pHisElem->storeElem.instrID != 0){
		insertDep(pHisElem->storeElem.instrID, instrID);
	}
	// update store history table (shadow memory version)
	pHisElem->storeElem.instrID = instrID;

	// remove load history element (shadow memory version)
	if(pHisElem->pLoadSet != NULL)
		pHisElem->pLoadSet->clear();

	// dumpStoreHistoryTable();
	// dumpDependenceTable();
}


extern "C" void*
ctxtobliMalloc (size_t size){
	void* addr = malloc (size);
	size_t *pElemInMallocMap = (size_t *)GET_SHADOW_ADDR_MALLOC_MAP(addr);
	*pElemInMallocMap = size;
	return addr;
}

extern "C" void*
ctxtobliCalloc (size_t size, size_t num){
	void* addr = calloc (size, num);
	size_t *pElemInMallocMap = (size_t *)GET_SHADOW_ADDR_MALLOC_MAP(addr);
	*pElemInMallocMap = size * num;
	return addr;
}

extern "C" void*
ctxtobliRealloc (void* addr, size_t size){
	void* paddr = addr;
	void* naddr = NULL;

	size_t *pElemInMallocMap = (size_t *)GET_SHADOW_ADDR_MALLOC_MAP(paddr);
	size_t pSize = *pElemInMallocMap;

	//free
	HistoryElem *pHisElem = (HistoryElem *)(GET_SHADOW_ADDR_HISTORY_TB(paddr));
	for (size_t i = 0; i < pSize; ++i, pHisElem = pHisElem+1){
		if(pHisElem->pLoadSet != NULL)
			pHisElem->pLoadSet->clear();
	}
	HistoryElem *pHisElemStart = (HistoryElem *)(GET_SHADOW_ADDR_HISTORY_TB(paddr));
	memset ((void *)pHisElemStart, 0, SIZE_ELEM * pSize);
	*pElemInMallocMap = 0;

	naddr = realloc (paddr, size);

	size_t *pNewElemInMallocMap = (size_t *)GET_SHADOW_ADDR_MALLOC_MAP(naddr);
	*pNewElemInMallocMap = size;
	return naddr;
}

extern "C" void
ctxtobliFree (void* addr){
	free (addr);

	size_t *pElemInMallocMap = (size_t *)GET_SHADOW_ADDR_MALLOC_MAP(addr);
	size_t pSize = *pElemInMallocMap;

	HistoryElem *pHisElem = (HistoryElem *)(GET_SHADOW_ADDR_HISTORY_TB(addr));
	for (size_t i = 0; i < pSize; ++i, pHisElem = pHisElem+1){
		if(pHisElem->pLoadSet != NULL)
			pHisElem->pLoadSet->clear();
	}
	HistoryElem *pHisElemStart = (HistoryElem *)(GET_SHADOW_ADDR_HISTORY_TB(addr));
	memset ((void *)pHisElemStart, 0, SIZE_ELEM * pSize);

	*pElemInMallocMap = 0;
}

		
extern "C"
void dumpDependenceTable() {
	// printf("=-=-=-=-= Dependence Table =-=-=-=-=\n");
	// for (std::unordered_map<DepID, IterRelation>::iterator it=(*depTable).begin();
	// 		it!=(*depTable).end(); ++it) {
	// 	CampID src = (CampID) (it->first >> 32);
	// 	CampID dst = (CampID) (it->first & 0xffffffff);
	// 	CntxID srcCtx = (CntxID) (src>>16);
	// 	InstrID srcInst = (InstrID) (src & 0xffff);
	// 	CntxID dstCtx = (CntxID) (dst>>16);
	// 	InstrID dstInst = (InstrID) (dst & 0xffff);
	// 	//human-readable form
	// 	std::cout<<srcCtx<<", "<<srcInst<<" => "<<dstCtx<<", "<<dstInst<<" : ";
	// 	std::cout<<std::bitset<STK_MAX_SIZE*2>(it->second)<<"\n";

	// 	//compressed form
	// 	// std::cout<< std::hex << src << ">" << dst << ":";
	// 	// std::cout<< std::hex << it->second << "\n";
	// }

	// // ########## C fopen style
	FILE *fp;
	fp = fopen("DependenceTable.obli.data", "a+");
	for ( std::unordered_set<DepID>::iterator it = (*depTable).begin(), itE = (*depTable).end(); it != itE ; ++it ){
		InstrID src = (InstrID) ((*it) >> 16);
		InstrID dst = (InstrID) ((*it) & 0xffff);
		fprintf(fp, "%x>%x\n", src, dst);
	}
	fclose(fp);
	//(*depTable).clear();
}