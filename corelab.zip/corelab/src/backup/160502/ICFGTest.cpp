#include "llvm/Analysis/CallGraph.h"
#include "llvm/IR/CFG.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/Support/raw_ostream.h"

#include "ICFGBuilder.hpp"
#include "DataFlowGraph.hpp"
#include "CallSiteSensitive.hpp"
#include "util.hpp"
#include "BGLutils.hpp"

void dumpICFG_toDOTFile(std::string, ICFG::Graph &g, ICFG::VidToMBB &vidToMBB);
void dumpDFG_toDOTFile(std::string path, DFG &dfg, DFGWithMemDataFlows::MemDataFlowEdgeSet *memDataFlowEdges = nullptr);

using namespace corelab;
using namespace llvm;

void ICFGTest::getAnalysisUsage(AnalysisUsage &AU) const {
	// AU.addRequired< LoopInfoWrapperPass >();
	// AU.addRequired< LoopTraverse >();
	// AU.addRequired< RecursiveFuncAnal >();
	AU.addRequired< CSSICFGBuilder >();
	// AU.addRequired< ICFGBuilder >();
	// AU.addRequired< DataFlowGraphBuilder >();
	// AU.addRequired< AliasAnalysis >();
	AU.setPreservesAll();
}

bool ICFGTest::runOnModule(Module &M) {
	errs() << "\nSTART [ICFGTest::runOnModule]  #######\n";

	// ******* ICFG Test ********//
	icfg = &getAnalysis<CSSICFGBuilder>();
	// icfg = &getAnalysis<ICFGBuilder>();
	errs() << "numNodes: "<< num_vertices(icfg->getBGLGraph()) << ", numEdges: "<<num_edges(icfg->getBGLGraph())<<"\n";

	// dumpICFG_toDOTFile("test.dot", icfg->getBGLGraph(), icfg->getVidToMBB());

	// // copy ICFG graph
	// ICFG::Graph copyG;
	// ICFG::VidToMBB copyVidToMBB;
	// copyGraph(icfg->getBGLGraph(), copyG);
	// copyVidToMBB.insert(icfg->getVidToMBB().begin(), icfg->getVidToMBB().end());
	
	// // merge on vertex and print it
	// // merge_test(copyG, copyVidToMBB);
	// // dumpICFG_toDOTFile("test2.dot", copyG, copyVidToMBB);

	// std::vector<ICFG::SCCID> sccIDVec(num_vertices(copyG));//(num_vertices(g))  
	// int nSCC = SCC::getSCCIDVector<ICFG::Graph>(copyG, sccIDVec);
	// errs()<<"nSCC:"<<nSCC<<"\n";

	// DAGSCC<ICFG::Graph> dagscc(&copyG);
	// errs()<< "nSCC@@: "<< dagscc.getNumSCC()<<"\n";
	// // boost::print_graph(dagscc.getDAG(), get(&ICFG::Graph::vertex_property_type::id, dagscc.getDAG()));
	// dumpICFG_toDOTFile("ICFG_DAG.dot", dagscc.getDAG(), copyVidToMBB);

	// // errs()<<"isReachable??: "<<bgl_isReachable(0, 5, dagscc.getDAG())<<"\n";


	// //******* DFG Test ********//
	// DataFlowGraphBuilder *dfgBuilder = &getAnalysis<DataFlowGraphBuilder>();
	// dfgBuilder->makeCallSiteInsensitiveDataflowGraph();
	// // dfgBuilder->makeCallSiteSensitiveDataflowGraph();
	// dumpICFG_toDOTFile("icfg.dot", dfgBuilder->getICFG()->getBGLGraph(), dfgBuilder->getICFG()->getVidToMBB());
	// dumpDFG_toDOTFile("dfg.dot", dfgBuilder->getDFG());

	// DFGWithMemDataFlows dfgMem;
	// dfgBuilder->AddAllConservativeMemoryDataFlow(dfgMem);
	// dumpDFG_toDOTFile("dfgMem.dot", dfgMem, &dfgMem.getMemDataFlowEdges());	

	errs() << "\nEND [ICFGTest::runOnModule]	#######\n";
	return false;
}


void ICFGTest::copyGraph(ICFG::Graph &source, ICFG::Graph &target){
	ICFG::VertexIDMap idMap = get(&ICFG::ICFGVertexProp::id, source);
	copy_graph(source, target, vertex_index_map(idMap));
}

void ICFGTest::merge_test(ICFG::Graph &g, ICFG::VidToMBB &vidToMBB){
	ICFG::VertexIDMap idMap = get(&ICFG::ICFGVertexProp::id, g);

	graph_traits<ICFG::Graph>::vertex_iterator start, end;
	graph_traits<ICFG::Graph>::vertex_iterator i1, i2;
	boost::tie(start,end) = vertices(g);
	i1 = start;
	i2 = ++start;
	// errs()<< idMap[*i1] << ", " << idMap[*i2] << "\n";

	bgl_merge_vertex(*i1, *i2, g);
	vidToMBB.erase(idMap[*i2]);
}

static RegisterPass<ICFGTest> Y("icfg-test", "ICFG Test", false, false);
char ICFGTest::ID = 0;





// unsigned ICFGTest::getNumSCC(){
// 	using namespace boost;
// 	int nSCC = 0;

// 	typedef ICFG Graph;
// 	typedef graph_traits<Graph>::vertex_descriptor Vertex;
// 	typedef graph_traits<Graph>::edge_descriptor Edge;
// 	typedef graph_traits<Graph>::vertices_size_type ComponentType;

// 	Graph& g(*icfg);  
// 	typedef typename property_map<Graph, vertex_index_t>::type VertexIndexMap;
// 	VertexIndexMap vIdxMap = get(vertex_index, g);

// 	typedef typename std::vector<ComponentType> MapImplType;

// 	MapImplType sccMapImpl(num_vertices(g));//(num_vertices(g))  

// 	typedef typename boost::iterator_property_map <MapImplType::iterator, VertexIndexMap> SCCMap;

// 	SCCMap sccMap(sccMapImpl.begin(), vIdxMap);

// 	BOOST_CONCEPT_ASSERT(( ReadWritePropertyMapConcept<SCCMap, Vertex> ));

// 	nSCC = strong_components(g, sccMap);

// 	errs()<< "# of nodes" << num_vertices(g) << ", # of SCC" << nSCC << "\n";

// 	typedef typename graph_traits<Graph>::vertex_iterator vertex_iter;
// 	vertex_iter vi, vi_end;
// 	for (boost::tie(vi, vi_end) = vertices(g); vi != vi_end ; ++vi) {
// 		Vertex v = *vi;
// 		errs() <<vIdxMap[v]<<"\t[";
// 		v->print(errs());
// 		errs() << "]\n";
// 	}

// 	for (auto i = sccMapImpl.begin(); i != sccMapImpl.end(); ++i){
// 		errs() << "Vertex " << i - sccMapImpl.begin()
// 		<< " is in component " << *i << "\n";
// 	}

// 	return nSCC;
// }



// unsigned ICFG::getNumSCC(){
//   using namespace boost;

//   typedef ICFG Graph;
//   typedef graph_traits<Graph>::vertex_descriptor Vertex;
//   typedef graph_traits<Graph>::edge_descriptor Edge;
//   typedef graph_traits<Graph>::vertices_size_type ComponentType;

//   // BOOST_CONCEPT_ASSERT(( GraphConcept<Graph> ));
//   // BOOST_CONCEPT_ASSERT(( MultiPassInputIteratorConcept<graph_traits<Graph>::out_edge_iterator> ));
//   // BOOST_CONCEPT_ASSERT(( IncidenceGraphConcept<Graph> ));
//   // BOOST_CONCEPT_ASSERT(( VertexListGraphConcept<Graph> ));
//   // BOOST_CONCEPT_ASSERT(( AdjacencyGraphConcept<Graph> ));
//   // BOOST_CONCEPT_ASSERT(( BidirectionalGraphConcept<Graph> ));
//   // BOOST_CONCEPT_ASSERT(( AdjacencyGraphConcept<Graph> ));
//   // BOOST_CONCEPT_ASSERT(( VertexMutableGraphConcept<Graph> ));
//   // BOOST_CONCEPT_ASSERT(( EdgeMutableGraphConcept<Graph> ));
//   // BOOST_CONCEPT_ASSERT(( VertexMutablePropertyGraphConcept<Graph> ));
//   // BOOST_CONCEPT_ASSERT(( EdgeMutablePropertyGraphConcept<Graph> ));
//   // BOOST_CONCEPT_ASSERT(( ReadablePropertyGraphConcept<Graph, Vertex, vertex_index_t> ));
//   // BOOST_CONCEPT_ASSERT(( ReadablePropertyGraphConcept<Graph, Edge, edge_index_t> ));

//   Graph& g(*this);  
//   typedef typename property_map<Graph, vertex_index_t>::type VertexIndexMap;
//   VertexIndexMap vIdxMap = get(vertex_index, g);

//   // //std::vector Impl version
//   typedef typename std::vector<ComponentType> MapImplType;
//   // MapImplType componentMapImpl(num_vertices(g));//(num_vertices(g))  
//   // typedef typename boost::iterator_property_map <MapImplType::iterator, VertexIndexMap> ComponentMap;
//   // ComponentMap componentMap(componentMapImpl.begin(), vIdxMap);
//   MapImplType sccMapImpl(num_vertices(g));//(num_vertices(g))  
//   typedef typename boost::iterator_property_map <MapImplType::iterator, VertexIndexMap> SCCMap;
//   SCCMap sccMap(sccMapImpl.begin(), vIdxMap);

//   // //std::map Impl version
//   // typedef typename std::map<Vertex, ComponentType> MapImplType;
//   // typedef associative_property_map< MapImplType > ComponentMap;
//   // MapImplType componentMapImpl;
//   // ComponentMap componentMap(componentMapImpl);
//   // typedef associative_property_map< MapImplType > SCCMap;
//   // MapImplType sccMapImpl;
//   // SCCMap sccMap(sccMapImpl);

//   // BOOST_CONCEPT_ASSERT(( ReadWritePropertyMapConcept<ComponentMap, Vertex> ));
//   BOOST_CONCEPT_ASSERT(( ReadWritePropertyMapConcept<SCCMap, Vertex> ));

//   //int nCC = connected_components(g, componentMap);
//   int nSCC = strong_components(g, sccMap);
//   errs()<< "# of nodes" << num_vertices(g) << ", # of CC: " << nCC 
//         << ", # of SCC" << nSCC << "\n";
//   typedef typename graph_traits<Graph>::vertex_iterator vertex_iter;
//   vertex_iter vi, vi_end;
//   for (boost::tie(vi, vi_end) = vertices(g); vi != vi_end ; ++vi) {
//     Vertex v = *vi;
//     errs() <<vIdxMap[v]<<"\t[";
//     v->print(errs());
//     errs() << "]\n";
//   }

  // std::vector Impl version
  // errs() << "\n";
  // for (auto i = componentMapImpl.begin(); i != componentMapImpl.end(); ++i)
  // {
  //    errs() << "Vertex " << i - componentMapImpl.begin()
  //     << " is in component " << *i << "\n";
  // }
  // errs() << "\n";
  // for (auto i = sccMapImpl.begin(); i != sccMapImpl.end(); ++i)
  // {
  //    errs() << "Vertex " << i - sccMapImpl.begin()
  //     << " is in component " << *i << "\n";
  // }

  // std::map Impl version
  // errs() << "\n";
  // for (auto i = componentMapImpl.begin(); i != componentMapImpl.end(); ++i)
  // {
  //    errs() << "Vertex " << vIdxMap[i->first]
  //     << " is in component " << i->second << "\n";
  // }
  // errs() << "\n";
  // for (auto i = sccMapImpl.begin(); i != sccMapImpl.end(); ++i)
  // {
  //    errs() << "Vertex " << vIdxMap[i->first]
  //     << " is in component " << i->second  << "\n";
  // }

//   return nSCC;
// }

// unsigned ICFGTest::getNumSCC(){
//   using namespace boost;
//   int nSCC = 0;

//   typedef ICFG Graph;
//   typedef graph_traits<Graph>::vertex_descriptor Vertex;
//   typedef graph_traits<Graph>::edge_descriptor Edge;
//   typedef graph_traits<Graph>::vertices_size_type ComponentType;

//   Graph& g(*icfg);  
//   typedef typename property_map<Graph, vertex_index_t>::type VertexIndexMap;
//   VertexIndexMap vIdxMap = get(vertex_index, g);

//   typedef typename std::vector<ComponentType> MapImplType;

//   MapImplType sccMapImpl(num_vertices(g));//(num_vertices(g))  

//   typedef typename boost::iterator_property_map <MapImplType::iterator, VertexIndexMap> SCCMap;

//   SCCMap sccMap(sccMapImpl.begin(), vIdxMap);

//   BOOST_CONCEPT_ASSERT(( ReadWritePropertyMapConcept<SCCMap, Vertex> ));

//   nSCC = strong_components(g, sccMap);

//   errs()<< "# of nodes" << num_vertices(g) << ", # of SCC" << nSCC << "\n";

//   typedef typename graph_traits<Graph>::vertex_iterator vertex_iter;
//   vertex_iter vi, vi_end;
//   for (boost::tie(vi, vi_end) = vertices(g); vi != vi_end ; ++vi) {
//     Vertex v = *vi;
//     errs() <<vIdxMap[v]<<"\t[";
//     v->print(errs());
//     errs() << "]\n";
//   }