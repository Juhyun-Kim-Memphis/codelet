#include "llvm/IR/InstIterator.h"
#include "llvm/Support/raw_ostream.h"

#include "DataFlowGraph.hpp"
#include "ICFGBuilder.hpp"
#include "CallSiteSensitive.hpp"
#include "util.hpp"

using namespace corelab;
using namespace llvm;
using namespace boost;

Function *getCalledFunction_aux(Instruction* indCall);

void DataFlowGraphBuilder::getAnalysisUsage(AnalysisUsage &AU) const {
	// AU.addRequired< LoopInfoWrapperPass >();
	// AU.addRequired< LoopTraverse >();
	// AU.addRequired< RecursiveFuncAnal >();
	AU.addRequired< CSSICFGBuilder >();
	AU.addRequired< ICFGBuilder >();
	// AU.addRequired< AliasAnalysisWrapper >();
	// AU.addRequired< AliasAnalysis >();
	AU.setPreservesAll();
}

bool DataFlowGraphBuilder::runOnModule(Module &M) {
	errs() << "\nSTART [DataFlowGraphBuilder::runOnModule]  #######\n";
	module = &M;
	icfg = NULL;
	// Do Nothing !! 
	// client pass should choose to call whether 
	// makeCallSiteInSensitiveDataflowGraph
	// or makeCallSiteSensitiveDataflowGraph.
	errs() << "\nEND [DataFlowGraphBuilder::runOnModule]  #######\n";
	return false;
}

void DataFlowGraphBuilder::AddAllConservativeMemoryDataFlow(DFGWithMemDataFlows &inOutDFG){
	//Graph copy
	assert((num_vertices(inOutDFG.getBGLGraph()) == 0 && inOutDFG.getVidToValue().size() == 0 && inOutDFG.getMemDataFlowEdges().size() == 0));
	DFG::Graph& g = inOutDFG.getBGLGraph(); //copied DFG
	DFG::VidToValue &vidToVal = inOutDFG.getVidToValue();
	DFG::VertexIDMap vidMapOri = get(&DFG::VertexProp::id, dfg.getBGLGraph());
	copy_graph(dfg.getBGLGraph(), g, vertex_index_map(vidMapOri));
	vidToVal.insert(dfg.getVidToValue().begin(), dfg.getVidToValue().end());
	DFG::VertexIDMap vidMap = get(&DFG::VertexProp::id, g);
	
	auto &memDataFlowEdges = inOutDFG.getMemDataFlowEdges();//set of RAW(Store -> Load) edges by memory data flow.

	//Add edges
	//1. find edge Store->Load Pairs in DFG
	std::unordered_set<DFG::VID> loadSet;
	std::unordered_set<DFG::VID> storeSet;
	for(auto e: vidToVal){
		// errs()<<".. "<<*e.second<<"\n";
		if(isa<LoadInst>(e.second))
			loadSet.insert(e.first);
		else if(isa<StoreInst>(e.second))
			storeSet.insert(e.first);
	}
	// errs()<<"nLoad: "<<loadSet.size()<<", nStore: "<<storeSet.size()<<", nStoreLoadPairs: "<<loadSet.size()*storeSet.size()<<"\n";

	//2. Add edges
	assert(num_edges(g) != 0);
	DFG::EID eidCnt = num_edges(g);
	for(auto vidSt : storeSet){
		for(auto vidLd : loadSet){
			add_edge(vertex(vidSt, g), vertex(vidLd, g), DFG::EdgeProp(eidCnt), g);
			memDataFlowEdges.insert(eidCnt);
			eidCnt++;
		}
	}
}

void DataFlowGraphBuilder::makeCallSiteInsensitiveDataflowGraph(){
	DFG::Graph &g = dfg.getBGLGraph();
	DFG::VidToValue &vidToVal = dfg.getVidToValue();

	//check whether the makeGraph method have called or not.
	assert(num_vertices(g) == 0 && "ERROR: makeGraph method have called already!");

	if(icfg) delete icfg;
	icfg = &getAnalysis<ICFGBuilder>();

	DFG::VID vidCnt = 0;
	for(auto vi = icfg->begin(), viE= icfg->end(); vi != viE; ++vi){
		MicroBasicBlock *mbb = vi->getMBB();
		
		for(BasicBlock::iterator ii=mbb->begin(), ie=mbb->end(); ii!=ie; ++ii){
			Value *val = &*ii;
			add_vertex(DFG::VertexProp(vidCnt), g);
			vidToVal[vidCnt] = val;
			vIDListOfVal[val].push_back(vidCnt);
			assert(vIDListOfVal[val].size() == 1 && "ERROR: CallSiteInsensitive ICFG has two node with same value");
			vidCnt++;
		}
	}

	DFG::VertexIDMap idMap = get(&DFG::VertexProp::id, g);

	// Connect by Use-def pairs of LLVM
	assert(num_edges(g) == 0);
	DFG::EID eidCnt = 0;
	for(Module::iterator fi = module->begin(), fe = module->end(); fi != fe; ++fi) {
		if (fi->isDeclaration()) continue;
		for (inst_iterator I = inst_begin(*fi), E = inst_end(*fi); I != E; ++I){
			for(auto ui = I->user_begin(), uiE = I->user_end(); ui != uiE; ++ui){
				assert(vIDListOfVal[&*I].size() == 1 && vIDListOfVal[*ui].size() == 1);
				DFG::VID vid1 = vIDListOfVal[&*I].front();
				DFG::VID vid2 = vIDListOfVal[*ui].front();
				add_edge(vertex(vid1, g), vertex(vid2, g), DFG::EdgeProp(eidCnt), g);
				eidCnt++;
				// Iterate for every use-def pairs
			}
		}
	}

	// Connect Function Formal Arguments to Callsite actual argument
	for(auto p: icfg->getCallsiteAndCalleePairs())
		handleCallInstCalleePair(p.first, p.second, false);
}

void DataFlowGraphBuilder::makeCallSiteSensitiveDataflowGraph(){
	DFG::Graph &g = dfg.getBGLGraph();
	DFG::VidToValue &vidToVal = dfg.getVidToValue();

	//check whether the makeGraph method have called or not.
	assert(num_vertices(g) == 0 && "ERROR: makeGraph method have called already!");

	// give CallSite-awareness
	if(icfg) delete icfg;
	icfg = &getAnalysis<CSSICFGBuilder>();
	CSSICFGBuilder *cssICFG = static_cast<CSSICFGBuilder *>(icfg);
	assert(cssICFG);
	CSSICFGBuilder::CallSiteIdxMap &callSiteIdxMap = *cssICFG->getCallSiteIdxMap();

	DFG::VID vidCnt = 0;
	for(auto vi = icfg->begin(), viE= icfg->end(); vi != viE; ++vi){
		MicroBasicBlock *mbb = vi->getMBB();
		int32_t csid = callSiteIdxMap[(*icfg)[mbb]];
		
		for(BasicBlock::iterator ii=mbb->begin(), ie=mbb->end(); ii!=ie; ++ii){
			Value *val = &*ii;
			add_vertex(DFG::VertexProp(vidCnt), g);
			vidToVal[vidCnt] = val;
			vidToCSID[vidCnt] = csid;

			vIDListOfVal[val].push_back(vidCnt);
			vidCnt++;
		}
	}

	DFG::VertexIDMap idMap = get(&DFG::VertexProp::id, g);

	// Connect by Use-def pairs of LLVM
	// It only connect use-dep pairs of same call-site
	assert(num_edges(g) == 0);
	DFG::EID eidCnt = 0;
	for(Module::iterator fi = module->begin(), fe = module->end(); fi != fe; ++fi) {
		if (fi->isDeclaration()) continue;
		for (inst_iterator I = inst_begin(*fi), E = inst_end(*fi); I != E; ++I){
			for(auto ui = I->user_begin(), uiE = I->user_end(); ui != uiE; ++ui){
				// errs()<<**ui<<", ";
				for(DFG::VID vid1 : vIDListOfVal[&*I])
					for(DFG::VID vid2 : vIDListOfVal[*ui])
						if(vidToCSID[vid1] == vidToCSID[vid2]){ //dont allow cross dep b/w different callsites of same function.
							add_edge(vertex(vid1, g), vertex(vid2, g), DFG::EdgeProp(eidCnt), g);
							eidCnt++;
						}
				// Iterate for every use-def pairs
			}
		}
	}


	// Connect Function Formal Arguments to Callsite actual argument
	for(auto p: icfg->getCallsiteAndCalleePairs())
		handleCallInstCalleePair(p.first, p.second, true);
}

void DataFlowGraphBuilder::handleCallInstCalleePair(MicroBasicBlock *callInstMBB, MicroBasicBlock *calleeMBB, bool isCallSiteSensitive){
	DFG::Graph &g = dfg.getBGLGraph();

	CSSICFGBuilder *cssICFG = isCallSiteSensitive ? static_cast<CSSICFGBuilder *>(icfg) : nullptr; 

	int32_t csidOfCallee = isCallSiteSensitive ? (*cssICFG->getCallSiteIdxMap())[(*icfg)[calleeMBB]] : -1;
	int32_t csidOfCallInst = isCallSiteSensitive ? (*cssICFG->getCallSiteIdxMap())[(*icfg)[callInstMBB]] : -1;
	Function *calleeFun = calleeMBB->getParent()->getParent();

	assert((isa<InvokeInst>(&callInstMBB->back()) == false)&& "NOT_IMPLEMENTED: InvokeInst.");
	CallInst *callInst = dyn_cast<CallInst>(&callInstMBB->back());
	assert(callInst && "ERROR: callInst convert fails");

	// connect Actual argument to formal argument
	assert(num_edges(g) != 0);
	DFG::EID eidCnt = num_edges(g);
	unsigned argIdx = 0;
	for (Function::arg_iterator AI = calleeFun->arg_begin(), E = calleeFun->arg_end(); AI != E; ++AI, ++argIdx){
		Value *arg = &*AI;
		for(auto ui = arg->user_begin(), uiE = arg->user_end(); ui != uiE; ++ui){
			for(DFG::VID vidFormal : vIDListOfVal[*ui]){
				if((vidToCSID[vidFormal] == csidOfCallee) || (isCallSiteSensitive == false)){
					for(DFG::VID vidActual : vIDListOfVal[callInst->getArgOperand(argIdx)]){
						if((vidToCSID[vidActual] == csidOfCallInst) || (isCallSiteSensitive == false)){
							// errs()<<"vidFormal: "<<vidFormal<<", csidOfCallee:"<< csidOfCallee<<", vidActual: "<<vidActual<<", csidOfCallInst: "<<csidOfCallInst<<"\n";
							add_edge(vertex(vidActual, g), vertex(vidFormal, g), DFG::EdgeProp(eidCnt), g);
							eidCnt++;
						}
					}
				}
			}
		}
	}

	// connect return value to all use of return value receivers
	inst_iterator retFound = std::find_if(inst_begin(calleeFun), inst_end(calleeFun), [](Instruction &I){return isRetInst(&I);});
	ReturnInst *retInst;
	if(retFound != inst_end(calleeFun)){
		retInst = dyn_cast<ReturnInst>(&*retFound);
		assert(retInst && "ERROR or NOT_IMPLEMENTED: ResumeInst or converting error");
		assert(retInst->getNumOperands() == 1);
	}
	
	//eidCnt = num_edges(g);
	for(auto ui = callInst->user_begin(), uiE = callInst->user_end(); ui != uiE; ++ui){
		Value *retVal = retInst->getOperand(0);//Should I use Return Inst? or Return Value?
		assert(vIDListOfVal[retVal].size() != 0 && "ERROR: retVal is not materialized as node, maybe it is argument");
		// errs()<<" ret "<<**ui<<"  "<<*retInst<<" "<<*retVal<<"\n";
		for(DFG::VID vidRetValUser : vIDListOfVal[*ui]){
			if((vidToCSID[vidRetValUser] == csidOfCallInst) || (isCallSiteSensitive == false)){
				for(DFG::VID vidRetVal : vIDListOfVal[retVal]){
					if((vidToCSID[vidRetVal] == csidOfCallee) || (isCallSiteSensitive == false)){
						// errs()<<"vidRetVal: "<<vidRetVal<<", csidOfCallee:"<< csidOfCallee<<", vidRetValUser: "<<vidRetValUser<<", csidOfCallInst: "<<csidOfCallInst<<"\n";
						add_edge(vertex(vidRetVal, g), vertex(vidRetValUser, g), DFG::EdgeProp(eidCnt), g);
						eidCnt++;
					}
				}
			}
		}
	}


}


static RegisterPass<DataFlowGraphBuilder> Y("dataflow-graph", "Draw dataflow graph for whole program", false, true);
char DataFlowGraphBuilder::ID = 0;


//deprecated

// for(Module::iterator fi = module->begin(), fe = module->end(); fi != fe; ++fi) {
// 	if (fi->isDeclaration()) continue;
// 	unsigned nUserOfFun = fi->getNumUses();//TODO:: what about bitcasted CallInst?
// 	if(nUserOfFun > 1){
// 		for(auto ui = fi->user_begin(), uiE = fi->user_end(); ui != uiE; ++ui){
// 			for(auto ui2 = ui; ++ui2 != fi->user_end(); ){
// 				Instruction *callA = dyn_cast<Instruction>(*ui);
// 				Instruction *callB = dyn_cast<Instruction>(*ui2);
// 				assert(callA && callB);
// 				assert(isa<CallInst>(callA) || isa<InvokeInst>(callA));
// 				assert(isa<CallInst>(callB) || isa<InvokeInst>(callB));
// 				assert(getCalledFunction_aux(callA) == getCalledFunction_aux(callB));
				
// 				cutEdgesCrossingPairOfCallSite(pDFG, callA, callB);
// 			}
// 		}
// 	}
// }


// void DataFlowGraphBuilder::cutEdgesCrossingPairOfCallSite(DFG *g, Instruction *callSiteA, Instruction *callSiteB){
// 	CSSICFGBuilder *cssICFG = static_cast<CSSICFGBuilder *>(icfg);
// 	assert(cssICFG);

// 	CSSICFGBuilder::EntryAndExitMBBMap &inOutMBBMap = *cssICFG->getEntryAndExitMBBOfCallSites();
// 	assert(inOutMBBMap[callSiteA].size() == inOutMBBMap[callSiteB].size());

// 	for(std::tuple<ICFGNode*, ICFGNode*> funA : inOutMBBMap[callSiteA]){
// 		for(std::tuple<ICFGNode*, ICFGNode*> funB : inOutMBBMap[callSiteB]){
// 			ICFGNode *entryA, *exitA;
// 			ICFGNode *entryB, *exitB;
// 			std::tie(entryA, exitA) = funA;
// 			std::tie(entryB, exitB) = funB;

// 			//TODO:: make this continue
// 			assert(entryA->getMBB()->getParent() == entryB->getMBB()->getParent() && "ERROR: trying to distinguish two callsite to different Functions");

// 			// traverse all possible pairs of subgraphA, subgraphB
// 			// and cut edges connecting them.
// 		}
// 	}
// }
