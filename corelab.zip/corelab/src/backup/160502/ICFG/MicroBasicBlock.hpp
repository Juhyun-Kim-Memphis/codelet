//Copyright (c) 2012, Jingyue Wu 
//https://github.com/wujingyue/rcs
#ifndef __MICRO_BASIC_BLOCK_H
#define __MICRO_BASIC_BLOCK_H

#include "llvm/IR/Module.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/Pass.h"
#include "llvm/ADT/DenseMap.h"
using namespace llvm;

namespace corelab {
/**
 * An MBB ends with a TerminatorInst or a CallInst. 
 * Note that an InvokeInst is a TerminatorInst. 
 *
 * begin = the first instruction in the MBB. 
 * end = the successor of its last instruction. 
 *
 * e.g. The following BB has two MBBs. 
 * MBB1: %3 = %1 + %2
 *       call foo()
 * MBB2: invoke bar(%3)
 *
 * MBB1.begin() == %3, MBB1.end() == invoke
 * MBB2.begin() == invoke, MBB2.end() == BB.end()
 */
struct MicroBasicBlock: public ilist_node<MicroBasicBlock> {
  typedef BasicBlock::iterator iterator;
  typedef BasicBlock::const_iterator const_iterator;

  BasicBlock* parent;
  iterator b, e;

  MicroBasicBlock(): parent(NULL) {}
  MicroBasicBlock(BasicBlock* p, iterator bb, iterator ee):
      parent(p), b(bb), e(ee)
  {
    assert(p && b != e);
  }

  iterator begin() { return b; }
  iterator end() { return e; }
  const_iterator begin() const { return b; }
  const_iterator end() const { return e; }
  Instruction &front() { return *b; }
  const Instruction &front() const { return *b; }
  Instruction &back() {
    iterator i = e;
    return *(--i);
  }
  const Instruction &back() const {
    const_iterator i = e;
    return *(--i);
  }

  BasicBlock *getParent() { return parent; }
  const BasicBlock *getParent() const { return parent; }

  iterator getFirstNonPHI();
};

struct MicroBasicBlockBuilder: public ModulePass {
  static char ID;

  typedef iplist<MicroBasicBlock> MBBListType;
  typedef DenseMap<BasicBlock*, MBBListType*> mbbmap_t;

  MicroBasicBlockBuilder();
  virtual void getAnalysisUsage(AnalysisUsage &AU) const { 
    AU.setPreservesAll(); 
  }
  virtual bool runOnModule(Module &M);

  MBBListType::iterator begin(BasicBlock *bb);
  MBBListType::iterator end(BasicBlock *bb);
  MBBListType::iterator parent(const Instruction *ins) {
    MBBListType::iterator it(parent_mbb.lookup(ins));
    return it;
  }

  //### for CallSite-Sensitive ICFG ###
  void getMBBMapForFunction(Function *fun, mbbmap_t &map);

 private:
  mbbmap_t mbbmap; //bb ---> many mbbs 
  DenseMap<const Instruction *, MicroBasicBlock *> parent_mbb;
};

typedef MicroBasicBlockBuilder::MBBListType::iterator mbb_iterator;
}

#endif //__MICRO_BASIC_BLOCK_H
