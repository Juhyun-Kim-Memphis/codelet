// It's not context-sensitive.
#include "llvm/Analysis/CallGraph.h"
#include "llvm/IR/CFG.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/Support/raw_ostream.h"
//#include "FPCallGraph.h"

#include "ICFGBuilder.hpp"
#include "util.hpp"
using namespace corelab;
using namespace llvm;


bool ICFGBuilder::runOnModule(Module &M) {
  errs() << "\nSTART [ICFGBuilder::runOnModule]  #######\n";

  findFunctionExitBB = &getAnalysis<FindFunctionExitBB>();

  IndirectCallAnal &indCallAnal = getAnalysis<IndirectCallAnal>();
  indCallAnal.getTypeBasedMatching(possibleTargetOf);

  MBBB = &getAnalysis<MicroBasicBlockBuilder>();

  assert((ignoredCalls.empty()) && "ERROR: runOnModule must be called twice");//ret2cs.clear();

  // coustruct All Vertces.
  forallbb(M, bb) {
    for (mbb_iterator mi = MBBB->begin(&*bb), E = MBBB->end(&*bb); mi != E; ++mi)
      getOrInsertMBB(&*mi);
  }
  
  for(Module::iterator fi = M.begin(), fe = M.end(); fi != fe; ++fi) {
    Function &F = *fi;
    if (F.isDeclaration()) continue;
    for(Function::iterator bb=F.begin(), be=F.end(); bb!=be; ++bb){
      for (mbb_iterator mi = MBBB->begin(&*bb), E = MBBB->end(&*bb); mi != E; ++mi) {
        // The ICFG will not contain any inter-thread edge. 
        // It's also difficult to handle them. How to deal with the return
        // edges? They are supposed to go to the pthread_join sites. 
        if (mi->end() != bb->end() && !is_pthread_create(&mi->back())) {
          CallInst *call = dyn_cast<CallInst>(&mi->back());
          assert(call && "mi->back() is not CallInst!!");
          Function* callee = call->getCalledFunction();

          if(!callee) {//indirect call
            int numTargetCandidate = possibleTargetOf[call].size();

            if(numTargetCandidate == 0){
              errs()<<"WARNING: Indirect Call doesnt have any expected target!\n"<<*call<<"\n";
              ignoreCall(call, mi);
            }

            for(Function *oneOfCallees : possibleTargetOf[call])
              linkCallSite(call, oneOfCallees, mi);
            
          }//TODO : indirect call
          else if (callee->isDeclaration()) //external function definition?
            ignoreCall(call, mi);
          else 
            linkCallSite(call, callee, mi);
        }
        else if(mi->end() == bb->end()){
          for (succ_iterator si = succ_begin(&*bb); si != succ_end(&*bb); ++si) {
            MicroBasicBlock *succ_mbb = &*MBBB->begin(*si);
            addEdge(&*mi, &*succ_mbb);
          }
        }
        else if(is_pthread_create(&mi->back())) assert_not_implemented();
        else assert_unreachable();
      }
    }

  }

  errs() << "\nEND [ICFGBuilder::runOnModule]  #######\n";
  return false;
}

void ICFGBuilder::linkCallSite(Instruction *callOrInvoke, Function *fun, mbb_iterator &mi){
  MicroBasicBlock *entry_mbb = &*MBBB->begin(&*(fun->begin()));
  addEdge(&*mi, &*entry_mbb);

  //ICFG:: remember this edge it's callsite-callee edge.
  getCallsiteAndCalleePairs().push_back(std::make_pair(&*mi, entry_mbb));

  auto exitBBs = findFunctionExitBB->getExitBB(fun);

  assert(exitBBs.first && "ERROR : No return inst !");
  assert(exitBBs.second.size() == 0 && "ERROR: There is UnreachableInst!");

  ReturnInst *retInst = exitBBs.first;

  MicroBasicBlock *ret_mbb = &*MBBB->begin(&*(retInst->getParent()));
  mbb_iterator mi_next = mi;
  ++mi_next;
  addEdge(&*ret_mbb, &*mi_next); 
}

void ICFGBuilder::ignoreCall(Instruction *callOrInvoke, mbb_iterator &mbbi){
  ignoredCalls.push_back(callOrInvoke); //add to external function call list.
  mbb_iterator next_mbb = mbbi; ++next_mbb;
  addEdge(&*mbbi, &*next_mbb);
}

static RegisterPass<ICFGBuilder> X("icfg", "Build inter-procedural control flow graph", false, true);
char ICFGBuilder::ID = 0;



