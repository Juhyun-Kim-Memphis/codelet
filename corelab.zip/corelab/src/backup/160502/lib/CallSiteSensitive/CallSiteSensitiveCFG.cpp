
#include "llvm/Analysis/CallGraph.h"
#include "llvm/IR/CFG.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/Support/raw_ostream.h"

#include "CallSiteSensitiveCFG.hpp"
#include "corelab/ICFG/util.hpp"

#define DO_NOTHING 0

using namespace corelab;
using namespace llvm;

Function *getCalledFunction_aux(Instruction* indCall);

bool CSSICFGBuilder::runOnModule(Module &M) {
  	errs() << "\nSTART [CSSICFGBuilder::runOnModule]  #######\n";
  	assert(ignoredCalls.empty() && "runOnModule must be called twice");//ret2cs.clear();
	
	MBBB = &getAnalysis<MicroBasicBlockBuilder>();

	findFunctionExitBB = &getAnalysis<FindFunctionExitBB>();

  	IndirectCallAnal &indCallAnal = getAnalysis<IndirectCallAnal>();
	indCallAnal.getTypeBasedMatching(possibleTargetOf);
	
	RecursiveFuncAnal2 &recFunAnal = getAnalysis<RecursiveFuncAnal2>();
	recFunAndRecCalls = recFunAnal.getRecFuncsAndCallsList();

	//deprecated code
	// RecursiveFuncAnal &recFunAnal = getAnalysis<RecursiveFuncAnal>();
	// recFunAnal.printAllRecursiveFunction();
	// recFuncList.insert(recFunAnal.begin(), recFunAnal.end());
	// trueRecCallList = recFunAnal.getTrueRecursiveCallList();

	Function *mainFcn = &*std::find_if(M.begin(), M.end(), [](Function &fi){return (fi.getName() == "main" && !fi.hasLocalLinkage());});
	assert(recFuncList.find(mainFcn) == recFuncList.end() && "ERROR: main is Recursive Function. Impossible!!");

	MbbMap mbbMapForMain;
	MBBB->getMBBMapForFunction(mainFcn, mbbMapForMain);

	// printStats(errs());
	makeEdges(mbbMapForMain);
	errs() << "\nEND [CSSICFGBuilder::runOnModule]  #######\n";
	return false;
}

void CSSICFGBuilder::makeEdges(MbbMap mbbMap){
	for(auto p: mbbMap) {
		BasicBlock *bb = p.first;
		for(auto mbbi = p.second->begin(), mbbiE = p.second->end(); mbbi != mbbiE ; ++mbbi) {
			// The ICFG will not contain any inter-thread edge. 
			// It's also difficult to handle them. How to deal with the return
			// edges? They are supposed to go to the pthread_join sites. 
			if (mbbi->end() != bb->end() && !is_pthread_create(&mbbi->back())) {
				Instruction *callOrInvoke = &mbbi->back();
				assert(isa<CallInst>(callOrInvoke) || isa<InvokeInst>(callOrInvoke));

				bool isRecCall = std::any_of(recFunAndRecCalls.begin(), recFunAndRecCalls.end(), 
					[callOrInvoke](std::pair<std::unordered_set<const Instruction *>, std::unordered_set<const Function *>> p){
						return p.first.find(callOrInvoke) != p.first.end();
					});

				if(isRecCall)
					ignoreCall(callOrInvoke, mbbi);
				else{
					Function *callee = getCalledFunction_aux(callOrInvoke);
					if(callee == NULL){//Indirect call
						int numTargetCandidate = possibleTargetOf[callOrInvoke].size();
						
						if(numTargetCandidate == 0){
							//TODO..
							// errs()<<"WARNING: Indirect Call doesnt have any expected target!\n"<<*callOrInvoke<<"\n";
							// assert(numTargetCandidate != 0 && "ERROR: Indirect Call doesnt have any expected target!");
							//handle this as Declaration only function (external function)
							ignoreCall(callOrInvoke, mbbi);
						}

						for(Function *oneOfCallees : possibleTargetOf[callOrInvoke])
							connectCallWithFunctionEntryAndExit(callOrInvoke, oneOfCallees, mbbi);
						
					}
					else if(callee->isDeclaration())
						ignoreCall(callOrInvoke, mbbi);
					else
						connectCallWithFunctionEntryAndExit(callOrInvoke, callee, mbbi);
				}
			}
			else if(mbbi->end() == bb->end()){
				for (succ_iterator si = succ_begin(&*bb); si != succ_end(&*bb); ++si) {
					MicroBasicBlock *succ_mbb = &*mbbMap[*si]->begin();
					addEdge(&*mbbi, &*succ_mbb);
				}
			}
			else if(is_pthread_create(&mbbi->back())) assert_not_implemented();
			else assert_unreachable();
		}
	}
}

CSSICFGBuilder::EntryExitOfFunc CSSICFGBuilder::buildGraphOfFunction(Function *fun){
	MicroBasicBlock *entry_mbb;

	MbbMap mbbMap;
	MBBB->getMBBMapForFunction(fun, mbbMap);

	//For Counting How many CallSites exist in a program
	callSiteCounter++;

	//Assigning callSite Index for each node of ICFG. (Just for user's convenience)
	//Current callSiteCounter value denote the callSite Index
	for(auto p: mbbMap){
		for(auto mbbi = p.second->begin(), mbbiE = p.second->end(); mbbi != mbbiE ; ++mbbi){
			ICFGNode *node = getOrInsertMBB(&*mbbi);
			callSiteIdxMap[node] = callSiteCounter;
		}
	}
	makeEdges(mbbMap);

	entry_mbb = &*mbbMap[&*fun->begin()]->begin();

	//constructing a set of Returning MicroBasicBlock 
	auto exitBBs = findFunctionExitBB->getExitBB(fun);
	std::vector<MicroBasicBlock*> return_mbbs;
	for(ReturnInst *retInst : exitBBs.first){
		MicroBasicBlock *ret_mbb = &*MBBB->getContainingMBB(retInst);
		return_mbbs.push_back(ret_mbb);
	}

	return make_tuple(entry_mbb, return_mbbs);
}

void CSSICFGBuilder::ignoreCall(Instruction *callOrInvoke, mbb_iterator &mbbi){
	ignoredCalls.push_back(callOrInvoke); //add to external function call list.
	mbb_iterator next_mbb = mbbi; ++next_mbb;
	addEdge(&*mbbi, &*next_mbb);
}

void CSSICFGBuilder::connectCallWithFunctionEntryAndExit(Instruction *callOrInvoke, Function *callee, mbb_iterator &mbbi){
	MicroBasicBlock *entry_mbb;
	std::vector<MicroBasicBlock*> return_mbbs;
	std::tie(entry_mbb, return_mbbs) = buildGraphOfFunction(callee);
	addEdge(&*mbbi, entry_mbb);

	//class ICFG feature:: remember this edge it's callsite-callee edge.
	getCallsiteAndCalleePairs().push_back(std::make_pair(&*mbbi, entry_mbb));

	if(isa<InvokeInst>(callOrInvoke)) assert_not_implemented();

	mbb_iterator mi_next = mbbi;
	++mi_next; //next consecutive mbb of callInst mbb

	for(MicroBasicBlock *mbb : return_mbbs){
		addEdge(&*mbb, &*mi_next); 
	}

	// Just for Checking mbbi_next is the one that we thought of
	Instruction *next = callOrInvoke->getNextNode();
	assert(next);
	auto mbbi_next(mbbi);
	++mbbi_next;
	assert((&*mbbi_next->begin()) == next);
	assert((&*mi_next) == (&*mbbi_next));

	// deprecated
	// subGraphOfCallSite[callOrInvoke].push_back(make_tuple((*this)[entry_mbb], (*this)[return_mbb]));
}

static RegisterPass<CSSICFGBuilder> X("cssicfg", "Build CallSite-Sensitive inter-procedural control flow graph", false, true);
char CSSICFGBuilder::ID = 0;



// for(auto p: mbbmap){
// 	errs()<< "\n"<<*p.first<<"\n ~~";
// 	std::for_each(p.second->begin(), p.second->end(), [](MicroBasicBlock mbbi){
// 		errs()<<" <<<<<<<<<<<<<\n";
// 		std::for_each(mbbi.begin(), mbbi.end(), [](Instruction &i){ errs()<<" @@"<<i<<"\n";});
// 		errs()<<" >>>>>>>>>>>>>\n";
// 	});
// }