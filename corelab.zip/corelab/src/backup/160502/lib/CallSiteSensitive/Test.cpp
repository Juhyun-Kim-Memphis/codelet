#include "llvm/Analysis/CallGraph.h"
#include "llvm/IR/CFG.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/Support/raw_ostream.h"

#include "corelab/CallSiteSensitive/CallSiteSensitiveCFG.hpp"
#include "corelab/ICFG/util.hpp"
#include "corelab/ICFG/BGLutils.hpp"

void dumpICFG_toDOTFile(std::string, ICFG::Graph &g, ICFG::VidToMBB &vidToMBB);

using namespace corelab;
using namespace llvm;

namespace corelab {
	class CSSTest: public ModulePass {
		public:
			static char ID;
			CSSTest(): ModulePass(ID) {}
			void getAnalysisUsage(AnalysisUsage &AU) const;
			virtual bool runOnModule(Module &M);

			ICFG *icfg;

	};
}

void CSSTest::getAnalysisUsage(AnalysisUsage &AU) const {
	AU.addRequired< CSSICFGBuilder >();
	AU.setPreservesAll();
}

bool CSSTest::runOnModule(Module &M) {
	errs() << "\nSTART [CSSTest::runOnModule]  #######\n";

	icfg = &getAnalysis<CSSICFGBuilder>();
	errs() << "numNodes: "<< num_vertices(icfg->getBGLGraph()) << ", numEdges: "<<num_edges(icfg->getBGLGraph())<<"\n";

	errs() << "\nEND [CSSTest::runOnModule]	#######\n";
	return false;
}

static RegisterPass<CSSTest> Y("cssicfg-test", "CSS-ICFG Test", false, false);
char CSSTest::ID = 0;



