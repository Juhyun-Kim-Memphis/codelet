// Builds a conservative ICFG.
// This is callsite-sensitive.

#ifndef __CALLSITE_SENSITIVE_ICFG_BUILDER_H
#define __CALLSITE_SENSITIVE_ICFG_BUILDER_H

#include <tuple>
#include <map>
#include <unordered_map>
#include <unordered_set>

#include "llvm/Pass.h"
#include "llvm/IR/CallSite.h"

#include "corelab/Utilities/FindFunctionExitBB.hpp"
#include "corelab/AliasAnalysis/IndirectCallAnal.hpp"
// #include "corelab/AliasAnalysis/RecursiveFuncAnal.hpp"
#include "corelab/RecursiveAnal/RecursiveFuncAnal2.hpp"

using namespace llvm;

#include "corelab/ICFG/ICFG.hpp"

namespace corelab {
	struct CSSICFGBuilder: public ModulePass, public ICFG {
		typedef std::vector<const Instruction *> CSList; //CallSite : CallInstruction = 1 : 1 mathching
		typedef DenseMap<const Instruction *, CSList> RetToCallSites;
		
		typedef iplist<MicroBasicBlock> MBBListType;
		typedef DenseMap<BasicBlock*, MBBListType*> MbbMap;
		typedef typename std::tuple<MicroBasicBlock*, std::vector<MicroBasicBlock*> > EntryExitOfFunc; // Entry MBB is one, Exit MBB can be multiple
		// typedef typename std::map<const Instruction *, std::vector<EntryExitOfFunc>> EntryAndExitMBBMap;
		typedef typename std::unordered_map<const ICFGNode *, int32_t> CallSiteIdxMap;

		public:
			static char ID;
			CSSICFGBuilder(): ModulePass(ID) { callSiteCounter = 0; }
			virtual bool runOnModule(Module &M);

			EntryExitOfFunc buildGraphOfFunction(Function *fun);

			void getAnalysisUsage(AnalysisUsage &AU) const {
				AU.setPreservesAll();
				AU.addRequired< MicroBasicBlockBuilder >();
				AU.addRequired< FindFunctionExitBB >();
				AU.addRequired< IndirectCallAnal >();
				// AU.addRequired< RecursiveFuncAnal >();
				AU.addRequired< RecursiveFuncAnal2 >();
			}
			// EntryAndExitMBBMap *getEntryAndExitMBBOfCallSites(){ return &subGraphOfCallSite; }
			CallSiteIdxMap *getCallSiteIdxMap(){ return &callSiteIdxMap; }

		private:
			void makeEdges(MbbMap mbbMapForMain);

			//ignore call instruction. so does NOT build graph for that called function. 
			//just connect current mbb(that have this call) with next mbb(having the following instruction).
			//(e.g. External Function call, Recurisive Call)
			void ignoreCall(Instruction *callOrInvoke, mbb_iterator &mbbi);

			void connectCallWithFunctionEntryAndExit(Instruction *callOrInvoke, Function *callee, mbb_iterator &mbbi);

			std::vector<const Instruction *> ignoredCalls;
			IndirectCallAnal::Matching possibleTargetOf;

			std::unordered_set<const Function *> recFuncList;
			// RecursiveFuncAnal::RecursiveCallList trueRecCallList;

			// std::vector<std::pair<std::unordered_set<const Instruction *>, std::unordered_set<const Function *>>> == RecursiveFuncAndCallList;
			RecursiveFuncAnal2::RecursiveFuncAndCallList recFunAndRecCalls;

			MicroBasicBlockBuilder *MBBB;
			FindFunctionExitBB *findFunctionExitBB;

			// EntryAndExitMBBMap subGraphOfCallSite;
			CallSiteIdxMap callSiteIdxMap;
			unsigned callSiteCounter;

	};
}

#endif //__CALLSITE_SENSITIVE_ICFG_BUILDER_H