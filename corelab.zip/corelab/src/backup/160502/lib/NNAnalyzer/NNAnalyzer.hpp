#ifndef LLVM_CORELAB_WEIGHT_SEEKER_H
#define LLVM_CORELAB_WEIGHT_SEEKER_H
#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Constants.h"
// #include "llvm/Analysis/LibCallSemantics.h"
#include "llvm/IR/Instructions.h"


#include <assert.h>
#include <set>
#include <string>

#ifndef DEBUG_TYPE
  #define DEBUG_TYPE "nn-analyzer"
#endif

#define SET std::set
#define UNIMPLEMENTED(s)                             \
do {                                                 \
    printf("UNIMPLEMENTED: %s\n", s);				 \
    assert(0);                               		 \
} while (0)

namespace corelab 
{	
	class FirstOrderValManager;

	using namespace llvm;
	class NNAnalyzer : public ModulePass
	{
		public:
			static char ID;
			NNAnalyzer() : ModulePass(ID) {}
			const char *getPassName() const { return "NNAnalyzer"; }

			bool runOnModule(Module& M);
			void getAnalysisUsage(AnalysisUsage &au) const {
		        au.setPreservesAll();
		    }

		private:
			void setIniFini(Module& M);
			void setFunctions(Module& M);
			void trackArgv(Value* argv);
			void findAllStaticVal(); //this should be call after trackArgv
			bool isStatic(Value *);
			bool isAliased(Value *); 
			Instruction * getLastStoreOrCall(LoadInst *ldInst);	//among all previous instruction(in BB) of the LoadInst,
																//return most closest store inst(that use some pointer Operand as this LoadInst) or call inst

			Constant* Initialize;
			Constant* Finalize;
			SET<Value *> staticValSet;
			void showStaticValSet();
			SET<uint64_t> staticArgIdxs;
			std::vector< std::shared_ptr< FirstOrderValManager > > firstOrderValues;

			//Value* argv;
	};

	// class StandardCLib : public LibCallInfo //deprecated
	// class StandardCLib
	// {
	// 	public:
	// 		StandardCLib() : LibCallInfo() { init();};
	// 		unsigned getLocationInfo(const LibCallLocationInfo *&Array) const; //UNUSED
	// 		const LibCallFunctionInfo * getFunctionInfoArray() const; //UNUSED
	// 		const LibCallFunctionInfo * getFunctionInfo(const Function *F);
	// 	private:
	// 		void init();
	// 		StringMap<const LibCallFunctionInfo*> myMap;
	// 		std::vector< StringRef > standLibFuncList;
	// };

	class AssigningStore {

		private:
			std::vector< LoadInst * > ldInst;//std::vector< LoadInst * > uncondtional;
			//std::vector< LoadInst * > conditional;//
			//condtions;
	};

	class FirstOrderValManager {
		public:
			StringRef Name;
			std::vector< Value * > synonyms; // either LoadInst or Argument

			FirstOrderValManager(CallInst *malloc, Module &M);
			CallInst * getMallocCall(){ return mallocCall; }
		private:
			CallInst *mallocCall;//initial memory allocation for this First-Order Value.
			std::vector< AssigningStore * > assigningStores;

			void trackSynonyms(std::vector<Value*> &synonyms, Module& M);//synonyms is input & output argument
			void setName();

			AllocaInst * getAlloca(CallInst *malloc); //Auxiliary helper function.
	};

}

#endif  // LLVM_CORELAB_WEIGHT_SEEKER_H
