#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/Support/Compiler.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Support/Debug.h"
#include "llvm/Support/CommandLine.h"

#include "llvm/ADT/SmallVector.h"
#include "llvm/Analysis/Passes.h"
#include "llvm/IR/DataLayout.h"

#include "corelab/Utilities/InstInsertPt.h"
#include "corelab/Utilities/GlobalCtors.h"
#include "corelab/Utilities/LiveValues.h"
#include "corelab/NNAnalyzer/NNAnalyzer.hpp"

#include <iostream>
#include <list>
#include <cstdlib>
#include <algorithm>

using namespace llvm;
using namespace corelab;

char NNAnalyzer::ID = 0;
static RegisterPass<NNAnalyzer> X("nn-anal", "find set of weights which belong to a same neuron and group them.", false, false);

bool NNAnalyzer::runOnModule(Module& M) {
	errs() << "\nSTART [NNAnalyzer::runOnModule]\n#######\n";
	
	staticArgIdxs.insert(2);//ni
	staticArgIdxs.insert(3);//nj
	staticArgIdxs.insert(4);//nk
	//staticArgIdxs.insert(5);
	
	setFunctions(M);
	LLVMContext &gctx = getGlobalContext();

	for(Module::iterator fi = M.begin(), fe = M.end(); fi != fe; ++fi) {
		Function &F = *fi;
		if (F.isDeclaration()) continue;
		//errs()<< F.getName()<<"\n";
		if ( F.getName() == "main" && F.arg_size() == 2 ){ // if F is main
			Type *i32 = Type::getInt32Ty(gctx);
			assert((F.getArgumentList().front().getType() == i32) && "ERROR: argc is not integer \n");
			assert((F.getArgumentList().back().getNumUses() == 1) && "ERROR: argv is used more than once.\n");
			if(Value* argv = dyn_cast<Value>(&F.getArgumentList().back()))
				trackArgv(argv);
		}
	}
	//TODO:Should I include Every Constant Value to StaticValueSet before Start Algorithm?
	findAllStaticVal();

	setIniFini(M);

	errs() << "#######\nEND [NNAnalyzer::runOnModule]\n\n";
	return false;
}

void NNAnalyzer::trackArgv(Value* argv) {
	LLVMContext &gctx = getGlobalContext();
	Type *i8 = Type::getInt8Ty(gctx);
	Type *pi8 = PointerType::getUnqual(i8);
	Type *ppi8 = PointerType::getUnqual(pi8);
	assert((argv->getType() == ppi8) && "ERROR: argv is not **i \n");

	for(User *U_argv : argv->users()){
		if(StoreInst* stInst = dyn_cast<StoreInst>(U_argv)){
			DEBUG(errs()<< "argv is used in Store Instruction:" << *stInst <<"\n");
			assert(stInst->getValueOperand() == argv && "ERROR: StoreInst doesn't store argv!!\n");
			
			Value *argvAddr = stInst->getPointerOperand();
			for(User *U_argvAddr : argvAddr->users()){
				if(dyn_cast<User>(U_argvAddr) == stInst) continue;
				else if(LoadInst* ldInst = dyn_cast<LoadInst>(U_argvAddr)){
					DEBUG(errs()<< "argv is used in Load Instruction:" << *ldInst <<"\n");
					trackArgv(ldInst); //recursive call because ldInst is argv
				}
				else
					UNIMPLEMENTED("other than Load Inst");
			}
		}
		else if(GetElementPtrInst* GEPInst = dyn_cast<GetElementPtrInst>(U_argv)){
			assert(GEPInst->getPointerAddressSpace() == 0 && "ERROR: Unexpected Address Space\n");
			assert(GEPInst->getNumIndices() == 1 && "ERROR: Multiple Indices!?\n");
			assert(isa<ConstantInt>(GEPInst->idx_begin()) && "ERROR: The index is not Static Integer.\n");
			if(ConstantInt *idx = cast<ConstantInt>(GEPInst->idx_begin())){
				uint64_t idx_ = idx->getValue().getZExtValue();
				if(staticArgIdxs.count(idx_) != 0){//Exist?
					DEBUG(errs()<<"Inserting ["<<*GEPInst<<"] to Static Value Set.\n");
					staticValSet.insert(GEPInst);//TODO: convert to Value*??
				} 
				else
					DEBUG(errs()<<"["<<*GEPInst<<"] is Dynamic Value\n");
			}
		}
		else			
			UNIMPLEMENTED("other than storeInst");
	}	
}
//Instruction* errVal = dyn_cast<Instruction>(U_argvAddr);assert(errVal);errVal->print(errs());

void NNAnalyzer::findAllStaticVal(){
	assert(!staticValSet.empty() && "ERROR: There is no initial Static Value.\n");
	bool newStaticAdded = true;
	
	showStaticValSet();

	errs() << "\nALGO START:\n";
	while(newStaticAdded){
		showStaticValSet();
		newStaticAdded = false;
		for (SET<Value *>::iterator it=staticValSet.begin(); it!=staticValSet.end(); ++it){
    		Value *staticVal = *it;
    		for(User *user : staticVal->users()){
    			if(staticValSet.count(user) != 0) continue; //already include to static set
    			//errs()<<"EXAMINING ["<<*user<<" ] ..";
    			int nOperands = user->getNumOperands();
    			int nStaticOperands = 0;

    			for (Use &operand : user->operands()) {
    				Value *operandVal = dyn_cast<Value>(operand);
    				//errs()<<" <"<<*operandVal<<"> ";

    				//TODO:verify
    				if(operand.get() == staticVal) //Itself
    					nStaticOperands++;
    				else if(staticValSet.count(operandVal) != 0)//Exist?
    					nStaticOperands++;
    				else if(isStatic(operandVal))
    					nStaticOperands++;
    			}

    			//errs()<<"nDynOperands : "<< (nOperands - nStaticOperands) <<"\n";
    			if(nOperands == nStaticOperands){
    				staticValSet.insert(user);//TODO: convert to Value*??
    				newStaticAdded = true;
    			}
    			else if(StoreInst *stInst = dyn_cast<StoreInst>(user)){
    				if(staticValSet.count(stInst->getValueOperand()) != 0 && !isAliased(stInst->getPointerOperand())){//store some static value 
    					
						for(User *ldInst_ : stInst->getPointerOperand()->users()){
							if(stInst == ldInst_) continue;
							if(staticValSet.count(ldInst_) != 0) continue;
							else if(LoadInst *ldInst = dyn_cast<LoadInst>(ldInst_)){
								Instruction *storeOrCall = getLastStoreOrCall(ldInst);
								errs()<<" =>[ "<< *storeOrCall<< " ]<= \n";
								if(isa<StoreInst>(storeOrCall) && storeOrCall == stInst){
									//errs()<<"INSERTING ["<<*ldInst<<" ] ..";
									staticValSet.insert(ldInst);
									newStaticAdded = true;
								}

								//else if(isa<CallInst>(storeOrCall)){
									//if the contents that this pointerOperand refers are modified in this fcn call,
									 	// then this is load is not static.
								//}
							}
							else
								UNIMPLEMENTED(" other than store and load.. 22");
						}

    				}
    			}
    		}
  		}
	}//while(newStaticAdded)
	std::for_each(	firstOrderValues.begin(), firstOrderValues.end(),
				 	[](std::shared_ptr< FirstOrderValManager > p){
				 		errs()<< p->Name<<"\n";
				 		std::for_each((p->synonyms).begin(), (p->synonyms).end(),[](Value *synonym){ errs()<< *synonym <<"\n"; });
				 		errs()<<"========================\n";
				 	});
  	showStaticValSet();
}

//analyze Value *v without using staticValSet.
bool NNAnalyzer::isStatic(Value * v){
	if(isa<Constant>(v)) return true;
	else if(isa<BasicBlock>(v)) return true; //TODO:verify
	else if(isa<Argument>(v)) return false; //TODO: this isStatic(Value * v) function simply doesn't assume arg is static
	else if(isa<AllocaInst>(v)) return false; //AllocaInst should be never Static (because it's memory space)
	else if(User *user = dyn_cast<User>(v)){
		bool isStaticOperands = true;
		for (Use &operand : user->operands()){
			if(Value *operandVal = dyn_cast<Value>(operand)){
				isStaticOperands &= isStatic(operandVal);
			}
			else
				UNIMPLEMENTED("operand is not value.");
		}
		return isStaticOperands;
	}
	else{
		errs()<<"in ISSTATIC:: val: "<<*v<<" \n";
		UNIMPLEMENTED("Value is not User nor Constant");
	}
}


//TODO
bool NNAnalyzer::isAliased(Value *){
	return false;
}


//among all previous instruction(in BB) of the LoadInst,
//return most closest store inst(that use some pointer Operand as this LoadInst) or call inst
Instruction * NNAnalyzer::getLastStoreOrCall(LoadInst *ldInst){
	
	// ## TODO:FIXME: deprecated
	// StandardCLib lci; //StandardCLib

	if(&ldInst->getParent()->front() == ldInst) return ldInst;//TODO: what if last store is in other BB?
	Instruction *prev = ldInst->getPrevNode();
	while(prev){
		if(StoreInst *stInst = dyn_cast<StoreInst>(prev)){
			if(stInst->getPointerOperand() == ldInst->getPointerOperand()) 
				return prev;
		}
		//shoud ignore if that call dont touch the contents at (ldInst->getPointerOperand()) at all.
		else if(CallInst *callInst = dyn_cast<CallInst>(prev)){ 
			Function *f = callInst->getCalledFunction();

			if(f->getAttributes().hasAttrSomewhere (Attribute::ReadOnly)){
				DEBUG();//doing nothing
			}
			//################### TODO:FIXME: deprecated  ################
			// else if(lci.getFunctionInfo(f)){
			// 	DEBUG(errs()<<" ###lci###"<< f->getName()<< (f->getName() == "malloc" ? " malloc" : " Not malloc") <<"\n");	
				
			// 	if(f->getName() == "malloc" 
			// 	   && !std::any_of(	firstOrderValues.begin(), firstOrderValues.end(), 
			// 	   				 	[callInst](std::shared_ptr< FirstOrderValManager > p){return p->getMallocCall() == callInst;})) {
			// 		std::shared_ptr< FirstOrderValManager > sp(new FirstOrderValManager(callInst, *(callInst->getModule())));
			// 		firstOrderValues.push_back(sp);
			// 	}
			// }
			else
				return prev;
			
		}
		prev=prev->getPrevNode();
	}
	UNIMPLEMENTED("reaching this code region.. Could this even possible?");
	return NULL;
}


void NNAnalyzer::showStaticValSet(){
	errs()<<"\n[ ======= SET contains ====== ]\n";
	for (SET<Value *>::iterator it=staticValSet.begin(); it!=staticValSet.end(); ++it){
		if(isa<Function>(*it)) {
			errs()<<" [ Function:: name:" << (*it)->getName()<<", ";
			errs()<<"  type:" << *((*it)->getType())<<" ]\n";
		}
		else if(isa<BasicBlock>(*it))
			errs()<<" [ BasicBlock:: name:" << (*it)->getName()<<" ]\n";
		else
			errs()<<" ["<<**it<<" ] "<<"\n";
	}
	errs() << "[ =========================== ]\n\n";
}


void FirstOrderValManager::trackSynonyms(std::vector<Value*> &synonymList, Module& M){
	AllocaInst *alloca = getAlloca(mallocCall);

	//validate alloca of mallocCall
	unsigned nStore = std::count_if (alloca->user_begin(), alloca->user_end(), [](User *u){return isa< StoreInst >(u);});
	unsigned nLoad = std::count_if (alloca->user_begin(), alloca->user_end(), [](User *u){return isa< LoadInst >(u);});
	assert(nStore == 1 && "Alloca containing mallocCall should def(store) only once because it's First-order\n");
	assert(alloca->getNumUses() == 1 + nLoad && "All user of Alloca must be load except on Store.\n");
	
	for(User *ldInst_ : alloca->users()){
		if(isa<StoreInst>(ldInst_)) continue;
		else if(LoadInst *ldInst = dyn_cast<LoadInst>(ldInst_)){
			synonymList.push_back(ldInst);
		}
	}
}

FirstOrderValManager::FirstOrderValManager(CallInst *mc, Module &M){
	mallocCall = mc;
	synonyms.push_back(mallocCall);
	setName();
	FirstOrderValManager::trackSynonyms(synonyms, M);
}


void FirstOrderValManager::setName(){
	AllocaInst *alloca = getAlloca(mallocCall);
	Name = alloca->getName();
}

AllocaInst * FirstOrderValManager::getAlloca(CallInst *malloc){
	assert(mallocCall->hasOneUse() && "malloc call must be used once!! (probably by bitcast)\n");
	if(BitCastInst *bcInst = dyn_cast< BitCastInst >(mallocCall->user_back())){
		assert(bcInst->hasOneUse() && "bitcast call must be used once!! (probably by store)\n");
		if(StoreInst *stInst = dyn_cast< StoreInst >(bcInst->user_back())){
			if(AllocaInst *ret = dyn_cast< AllocaInst >(stInst->getPointerOperand()))
				return ret;
			else
				UNIMPLEMENTED("Not Alloca Inst 3211");
		}	
		else
			UNIMPLEMENTED("Store following bitcast 2345");
	}
	else
		UNIMPLEMENTED("BitCastInst 4572");
}



void NNAnalyzer::setIniFini(Module& M) {
	LLVMContext &Context = getGlobalContext();

	std::vector<Type*> formals(0);
	std::vector<Value*> actuals(0);
	FunctionType *voidFcnVoidType = FunctionType::get(Type::getVoidTy(Context), formals, false);

	/* initialize */
	Function *initForCtr = Function::Create( 
			voidFcnVoidType, GlobalValue::InternalLinkage, "__constructor__", &M); 
	BasicBlock *entry = BasicBlock::Create(Context,"entry", initForCtr); 
	BasicBlock *initBB = BasicBlock::Create(Context, "init", initForCtr); 
	actuals.resize(1);

	Value *zero = ConstantInt::get(Type::getInt32Ty(Context), 0);
	actuals[0] = zero;
	
	CallInst::Create(Initialize, actuals, "", entry); 
	BranchInst::Create(initBB, entry); 
	ReturnInst::Create(Context, 0, initBB);
	callBeforeMain(initForCtr);
	
	/* finalize */
	Function *finiForDtr = Function::Create(voidFcnVoidType, GlobalValue::InternalLinkage, "__destructor__",&M);
	BasicBlock *finiBB = BasicBlock::Create(Context, "entry", finiForDtr);
	BasicBlock *fini = BasicBlock::Create(Context, "fini", finiForDtr);
	actuals.resize(0);
	CallInst::Create(Finalize, actuals, "", fini);
	BranchInst::Create(fini, finiBB);
	ReturnInst::Create(Context, 0, fini);
	callAfterMain(finiForDtr);
}

void NNAnalyzer::setFunctions(Module &M){
	LLVMContext &Context = getGlobalContext();

	// Declare profiler runtime functions
	Initialize = M.getOrInsertFunction(
			"nn_initialize",
			Type::getVoidTy(Context),
			Type::getInt32Ty(Context),
			(Type*)0);

	Finalize = M.getOrInsertFunction(
			"nn_finalize",
			Type::getVoidTy(Context),
			(Type*)0);
	

	/*
	beginFunction = M.getOrInsertFunction( 
			"hotFunction_beginFunction",
			Type::getVoidTy(Context),
			Type::getInt32Ty(Context),
			(Type*)0);

	endFunction = M.getOrInsertFunction(
			"hotFunction_endFunction",
			Type::getVoidTy(Context),
			Type::getInt32Ty(Context),
			(Type*)0);
	*/
	return;
}


/*
else if(StoreInst *stInst = dyn_cast<StoreInst>(user)){
	if(staticValSet.count(stInst->getValueOperand()) != 0 
		TODO && isNotAliased(stInst->getPointerOperand())   ){//store some static value 
		for(User *ldInst_ : stInst->getPointerOperand()->users()){ 
		// these ldInst are candidate of this static value. (now flow-insensitive)
		// TODO: Guarantee this PointerOperand is not aliased.(or if aliased, let's take it as identical)
		// TODO: pick one ldInst that really has this static value by using control flow info.
			if(const LoadInst *ldInst = dyn_cast<LoadInst>(ldInst_)){
				LiveValues lva(*ldInst->getParent()->getParent());
				LiveValues::ValueList liveVals;
				lva.findLiveValuesAfterInst(ldInst, liveVals);
				errs() << "\n@@@liveVals contains: ";
				  for (LiveValues::ValueList::iterator lvi=liveVals.begin(); lvi<liveVals.end(); lvi++)
				    errs() << '{' << **lvi<<"} ";
				errs() << '\n';
				errs() << '\n';

				errs()<<" (("<<*ldInst<<")) ";
			}
		}
	}
}

for(User *ldInst_ : stInst->getPointerOperand()->users()){
	if(stInst == ldInst_) continue;
	else if(LoadInst *ldInst = dyn_cast<LoadInst>(ldInst_)){
		Instruction* prev = ldInst->getPrevNode();
		errs()<<" st: "<<*stInst<<", load:"<<*ldInst<<"\n";
		while(prev){
			errs()<<" prev: "<<*prev<<"\n";
			if(isa<StoreInst>(prev)){

				break;
			}
			prev = prev->getPrevNode();
		}
	}
	else
		UNIMPLEMENTED(" other than store and load.. 22");
}


*/