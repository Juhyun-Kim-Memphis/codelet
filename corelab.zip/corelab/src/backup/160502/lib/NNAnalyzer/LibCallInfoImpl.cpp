// #include "llvm/Support/raw_ostream.h"

// #include "corelab/NNAnalyzer/NNAnalyzer.hpp"

// #include <iostream>
// #include <cstdlib>
// #include <vector>

// using namespace llvm;
// using namespace corelab;






// //list every stand lib function here
// void StandardCLib::init(){

// 	StringRef atoi_sf("atoi");
// 	standLibFuncList.push_back(atoi_sf);

// 	StringRef malloc_sf("malloc");
// 	standLibFuncList.push_back(malloc_sf);

	    
//     const LibCallFunctionInfo *Array = getFunctionInfoArray();


//     myMap.insert(StringMapEntry<const LibCallFunctionInfo*>::Create(atoi_sf, Array+0));
//     myMap.insert(StringMapEntry<const LibCallFunctionInfo*>::Create(malloc_sf, Array+1));

    	
  	
// }	



// /// Return the LibCallFunctionInfo object corresponding to
// /// the specified function if we have it.  If not, return null.
// const LibCallFunctionInfo * StandardCLib::getFunctionInfo(const Function *F){  
// 	/// If this is the first time we are querying for this info, lazily construct
// 	/// the StringMap to index it.

// 	// Look up this function in the string map.
// 	//errs()<<"getNumBuckets() : "<< myMap->getNumBuckets()<<"\n";
// 	return myMap.lookup(F->getName());
// }











// /// getLocationInfo - Return information about the specified LocationID.
// unsigned StandardCLib::getLocationInfo(const LibCallLocationInfo *&Array) const {//UNUSED
// 	//assert(0 && "Not Using this llvm interface fcn because it dosen't work.\n");
// 	return 0;
// }

// /// getFunctionInfoArray - Return an array of descriptors that describe the
// /// set of libcalls represented by this LibCallInfo object.  This array is
// /// terminated by an entry with a NULL name.
// const LibCallFunctionInfo * StandardCLib::getFunctionInfoArray() const {//UNUSED
// 	//assert(0 && "Not Using this llvm interface fcn because it dosen't work.\n");
	
// 	LibCallFunctionInfo * lcfi = new LibCallFunctionInfo[2];
	
// 	lcfi[0].Name = standLibFuncList[0].data();
// 	lcfi[0].UniversalBehavior = llvm::AliasAnalysis::Ref;
// 	//lcfi[0].UniversalBehavior = MRI_Ref;

// 	lcfi[1].Name = standLibFuncList[1].data();
// 	lcfi[1].UniversalBehavior = llvm::AliasAnalysis::Ref;

// 	return lcfi;
// }