#ifndef CORELAB_CAMP_META_H
#define CORELAB_CAMP_META_H

#include "corelab/Profilers/campCommon.h"
#include <inttypes.h>

#endif	
