#ifndef LLVM_CORELAB_CTXT_OBLI_PROF_H
#define LLVM_CORELAB_CTXT_OBLI_PROF_H

#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Constants.h"

#include "corelab/Profilers/campMeta.h"


#include <fstream>
#include <map>

#ifndef DEBUG_TYPE
  #define DEBUG_TYPE "ctxt-obli-prof"
#endif


namespace corelab
{
	using namespace llvm;
	using namespace std;
	using namespace corelab::CAMP;


	class CtxtObliProf : public ModulePass
	{
		public:
			bool runOnModule(Module& M);

			// Utility
			Value* castTo(Value* from, Value* to, InstInsertPt &out, const DataLayout *dl);

			virtual void getAnalysisUsage(AnalysisUsage &AU) const
			{
				AU.addRequired< Namer >();
				AU.addRequired< LoadNamer >();
				AU.setPreservesAll();
			}

			const char *getPassName() const { return "ctxt-obli-prof"; }

			static char ID;
			CtxtObliProf() : ModulePass(ID) {}

			bool isUseOfGetElementPtrInst(LoadInst *ld);
			void hookMallocFree();

			private:
			
			Module *module;
			LoadNamer *pLoadNamer;


			/* Functions */

			// initialize, finalize functions
			Constant *ctxtobliInitialize;
			Constant *ctxtobliFinalize;

			// functions for load, store instructions
			Constant *ctxtobliLoadInstr;
			Constant *ctxtobliStoreInstr;

			// functio for memory management
			Constant *ctxtobliMalloc;
			Constant *ctxtobliCalloc;
			Constant *ctxtobliRealloc;
			Constant *ctxtobliFree;


			void setFunctions(Module &M);
			void setIniFini(Module &M);
			bool loadMetadata();
	};
}

#endif
