#ifndef CORELAB_CAMP_IDENTIFY_TARGET_CAMP_ID_HPP
#define CORELAB_CAMP_IDENTIFY_TARGET_CAMP_ID_HPP

#include <inttypes.h>
#include <vector>
#include <list>
#include <cstring>
#include <unordered_set>

#include "../campPostProc/PostProcess.hpp"

namespace corelab
{
	using namespace std;
	class IdentifyTargetCampID{
		public:
			typedef std::unordered_set<UniqueContextID> UcIDSetForOneCallSiteOfTarget;

			IdentifyTargetCampID(std::string tar, ContextTree *r){
				target.assign(tar);
				root = r;
				csNodesOfTarget = getAllCallSiteNodesOfTarget(root);
				constructUcIDSetList();
			}


			std::vector<UcIDSetForOneCallSiteOfTarget> &getUcIDSetList(){return ucIDSetList;}


		private:
			ContextTree *root;
			std::string target;

			std::vector<ContextTree *> csNodesOfTarget;
			std::vector<UcIDSetForOneCallSiteOfTarget> ucIDSetList;

			void constructUcIDSetList();
			std::vector<ContextTree *> getAllCallSiteNodesOfTarget(ContextTree *root);
	};

	class IdentifyTargetInstID{
		public:
			IdentifyTargetInstID(const std::vector<Dependence *> *depList_,
								 const std::vector<std::unordered_set<UniqueContextID>> *ucIDSet_){
				depList = depList_;
				ucIDSet = ucIDSet_;
				constructInstrIDSet();
			}

			std::unordered_set<InstrID> &getInstrIDSet(){return instrIDSet;}

		private:
			std::unordered_set<InstrID> instrIDSet;

			void constructInstrIDSet();
			const std::vector<Dependence *> *depList;
			const std::vector<std::unordered_set<UniqueContextID>> *ucIDSet;
	};
}

#endif //CORELAB_CAMP_IDENTIFY_TARGET_CAMP_ID_HPP
