#include <iostream>
#include <fstream>
#include <assert.h>
#include <stdlib.h>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>

#include "../campPostProc/PostProcess.hpp"
#include "IdentifyTargetCampID.hpp"

#define MAX_LINE_SIZE 4096

using namespace std;
using namespace corelab;

int main(int argc, char** argv){
	char line[MAX_LINE_SIZE];

	//################ read NativeOffloaderTargetFuncList
	std::ifstream notfl_fp ("NativeOffloaderTargetFuncList.data", std::ifstream::binary);
	assert(notfl_fp);
	notfl_fp.getline(line, MAX_LINE_SIZE);
	string notfl_fp_startMsg("$$$$$ NativeOffloaderTargetFuncList START $$$$$");
	assert(notfl_fp_startMsg.compare(line) == 0);
	notfl_fp.getline(line, MAX_LINE_SIZE); //assume one target for now (16/5/15)
	string natoff_target(line);
	notfl_fp.close();
	//################ read NativeOffloaderTargetFuncList END

	unsigned nNode = 0;
	unsigned cnt = 0;

	std::ifstream fpCtxTree ("ContextTree.data", std::ifstream::binary);
	assert(fpCtxTree);

	fpCtxTree.getline(line, MAX_LINE_SIZE);
	string startMsg("$$$$$ CONTEXT TREE IN PREORDER $$$$$");
	assert(startMsg.compare(line) == 0);
	fpCtxTree.getline(line, MAX_LINE_SIZE);
	nNode = (unsigned)(atoi(line));

	std::unordered_map<UniqueContextID, ContextTreeNode *> ucIDMap;
	std::unordered_map<LoopID, std::vector<UniqueContextID>> loopMap;

	char ucIDStr[64];
	char locIDStr[64];
	char kind[4];
	char funName[64];
	char loopIDStr[64];
	char tmp[128];

	//add root (main)
	fpCtxTree>>ucIDStr;
	fpCtxTree>>locIDStr;
	fpCtxTree>>kind;
	fpCtxTree>>tmp;
	fpCtxTree>>funName;
	assert(strcmp(kind, "CS") == 0 && strcmp(funName, "main") == 0);
	ContextTree *root = new ContextTree(true, NULL, 0, 0);
	root->setFunName(funName);
	ucIDMap[0] = root;

	//read ContextTree.data
	for (int i = 0; i < nNode-1; ++i){
		fpCtxTree>>ucIDStr;
		fpCtxTree>>locIDStr;
		UniqueContextID ucID = (UniqueContextID)(atoi(ucIDStr));
		LocalContextID locID = (LocalContextID)(atoi(locIDStr));
		ContextTree *curParent = ucIDMap[ ucID - locID ];

		fpCtxTree>>kind;
		if(strcmp(kind, "CS") == 0){
			fpCtxTree>>tmp; // recursive Fun? or normal?
			fpCtxTree>>funName;
			ContextTree *node = new ContextTree(true, curParent, ucID, (LocalContextID)(atoi(locIDStr)));
			node->setFunName(funName);
			curParent->addChild(node);
			ucIDMap[ucID] = node;
		}
		else if(strcmp(kind, "L") == 0){
			fpCtxTree>>loopIDStr;
			fpCtxTree>>tmp; // loop name;
			ContextTree *node = new ContextTree(false, curParent, ucID, (LocalContextID)(atoi(locIDStr)));
			LoopID loopID = (LoopID)(atoi(loopIDStr));
			node->setLoopID(loopID);
			curParent->addChild(node);

			ucIDMap[ucID] = node;
			loopMap[loopID].push_back(ucID);
		}
		else
			assert(0 &&"WTF?");
	}

	fpCtxTree.getline(line, MAX_LINE_SIZE); // for last char "\n" of last element Node
	fpCtxTree.getline(line, MAX_LINE_SIZE);
	string endMsg("$$$$$ CONTEXT TREE END $$$$$");
	assert(endMsg.compare(line) == 0);
	fpCtxTree.close();

	// ##################################################################### //
	// ####################### read DependenceTable.data ################### //
	// ##################################################################### //
	std::ifstream fpDepTb ("DependenceTable.real.data", std::ifstream::binary);
	assert(fpDepTb);

	std::unordered_map<DepKey, std::vector<Dependence *>> depMap;
	std::vector<Dependence *> depList;

	char depStr[128];
	while(fpDepTb >> depStr){ // Attempt read into depStr, return false if it fails
		uint32_t campIDsrc=0;
		uint32_t campIDdst=0;
		uint32_t iterRel=0;
		if(sscanf (depStr,"%x>%x:%x",&campIDsrc,&campIDdst, &iterRel) != 3) assert(0 && "ERROR: read fail");
		Dependence *newDep = new Dependence(campIDsrc>>16, campIDdst>>16, campIDsrc & 0xffff, campIDdst & 0xffff);
		newDep->addIterRel(iterRel);

		depList.push_back(newDep);
		depMap[newDep->getDepKey()].push_back(newDep);
	}
	// cout<<"DependenceTable.data (# deps : "<<depList.size()<<", # of edges to distinct ctxt: "<<depMap.size()<<")\n";
	cout<<depList.size()<<"\t"<<depMap.size()<<"\n";
	fpDepTb.close();

	// ##################################################################### //
	// ####################### identify all campID belongs to target ################### //
	// ##################################################################### //
	IdentifyTargetCampID *targetAnalyzer = new IdentifyTargetCampID(natoff_target, root);
	std::vector<std::unordered_set<UniqueContextID>> ucIDSetLi = targetAnalyzer->getUcIDSetList();
	for(auto e : ucIDSetLi){
		std::cout<<"==> "<< e.size()<<"\n";
		// for(auto eUcID: e)
		// 	std::cout<<"> "<< eUcID<<"\n";
	}

	//##########################
	// ############ Context-Sensitive Ins Outs for Native Offloader target
	//##########################
	int invoIdx = 0;
	std::vector<std::unordered_set<Dependence *>> csInDeps;
	std::vector<std::unordered_set<Dependence *>> csOutDeps;
	for(auto ucIDSet : ucIDSetLi){
		std::unordered_set<Dependence *> newSetIn;
		std::unordered_set<Dependence *> newSetOut;
		csInDeps.push_back(newSetIn);
		csOutDeps.push_back(newSetOut);
		for(Dependence *d : depList){
			bool isSrcIn = ucIDSet.find(d->ucIDsrc) != ucIDSet.end();
			bool isDstIn = ucIDSet.find(d->ucIDdst) != ucIDSet.end();
			if(isSrcIn != isDstIn){ //XOR
				if(isDstIn && !(isSrcIn))
					csInDeps[invoIdx].insert(d);
				if(isSrcIn && !(isDstIn))
					csOutDeps[invoIdx].insert(d);
			}
		}
		invoIdx++;
	}
	std::cout<<"Context-Sensitive \n";
	for (int i = 0; i < csInDeps.size(); ++i)
		cout<<"<"<<i<<">: (nIns: "<<csInDeps[i].size()<<", nOuts: "<<csOutDeps[i].size()<<")\n";


	// ##################################################################### //
	// ####################### identify all InstrID belongs to target ################### //
	// ##################################################################### //

	IdentifyTargetInstID *targetAnalyzer_CSIgorant = new IdentifyTargetInstID(&depList, &ucIDSetLi);
	std::unordered_set<InstrID> instrIDSet = targetAnalyzer_CSIgorant->getInstrIDSet();
	std::cout<<"@@+> "<< instrIDSet.size()<<"\n";
	
	//##########################
	// ############ Context-Ignorant Ins Outs for Native Offloader target
	//##########################
	std::unordered_set<Dependence *> ciInDeps;
	std::unordered_set<Dependence *> ciOutDeps;
	for(Dependence *d : depList){
		bool isSrcIn = instrIDSet.find(d->instrIDsrc) != instrIDSet.end();
		bool isDstIn = instrIDSet.find(d->instrIDdst) != instrIDSet.end();
		
		if(isSrcIn && isDstIn){ // TODO is it OK?
			ciInDeps.insert(d);
			ciOutDeps.insert(d);
		}
		if(isDstIn && !(isSrcIn))
			ciInDeps.insert(d);
		if(isSrcIn && !(isDstIn))
			ciOutDeps.insert(d);
		
	}

	std::cout<<"Context-Ignorant \n";
	cout<< "(nIns: "<<ciInDeps.size()<<", nOuts: "<<ciOutDeps.size()<<")\n";



	
		
}

