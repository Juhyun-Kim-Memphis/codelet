#include "IdentifyTargetCampID.hpp"
#include <list>
#include <algorithm>


#define MAX_LINE_SIZE 4096

using namespace std;
using namespace corelab;

std::vector<ContextTree *> IdentifyTargetCampID::getAllCallSiteNodesOfTarget(ContextTree *root){
	std::vector<ContextTree *> res;
	if(target.compare(root->getFunName()) == 0)
		res.push_back(root);

	for(ContextTree *c : root->children){
		for(ContextTree *node : getAllCallSiteNodesOfTarget(c))
			res.push_back(node);
	}

	return res;
}

void IdentifyTargetCampID::constructUcIDSetList(){
	assert(csNodesOfTarget.size() != 0);

	for(ContextTree *csNode : csNodesOfTarget){
		std::unordered_set<UniqueContextID> set;

		std::list<ContextTree *> searchQueue;
		searchQueue.push_back(csNode);
		while(!searchQueue.empty()){
			ContextTree *node = searchQueue.front();
			searchQueue.pop_front();

			set.insert(node->getUCID());

			for(ContextTree *c : node->children)
				searchQueue.push_back(c);
		}
		ucIDSetList.push_back(set);
	}
}

void IdentifyTargetInstID::constructInstrIDSet(){
	for(Dependence *dep: *depList){
		UniqueContextID ucIDsrc = dep->ucIDsrc;
		UniqueContextID ucIDdst = dep->ucIDdst;

		if(std::any_of(ucIDSet->begin(), ucIDSet->end(), [ucIDsrc](std::unordered_set<UniqueContextID> set){return set.find(ucIDsrc)!=set.end();}))
			instrIDSet.insert(dep->instrIDsrc);
		if(std::any_of(ucIDSet->begin(), ucIDSet->end(), [ucIDdst](std::unordered_set<UniqueContextID> set){return set.find(ucIDdst)!=set.end();}))
			instrIDSet.insert(dep->instrIDdst);
	}
}
